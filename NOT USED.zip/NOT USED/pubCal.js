var sendEmails = false;
var usersResourceList = [];
var allEvents =[];

myCalendar = FullCalendar;
myCalendarAlt = FullCalendar;


var toggleSelfCheck = false;
var toggleDisplay_check = false; // if false = myCalendarAlt cal if true = mycalendar
var currentField = "";
var foiList = ["hypnosis", "nlp", "breath"];
var sourceCal = "alt";

var modal = "";
var span = "";

// const queryString = window.location.search;
// console.log(queryString);


// if (queryString){
//   const urlParams = new URLSearchParams(queryString);  
//   let requestKeyMessage = urlParams.get('key')
//   console.log(requestKeyMessage);

// }

document.addEventListener('click', function(e) {
    e = e || window.event;
    var target = e.target || e.srcElement,
        text = target.textContent || target.innerText; 
        console.log(e.srcElement); 
        
        if(e.srcElement.className == "selectr-label"){
            activateSelectUser();
        }
        if(e.srcElement.id == "emailToInvite"){
            activateEmail()            
        }

}, false);

document.addEventListener('DOMContentLoaded', function() {
    console.log("allUsersSnapShot after DOM load: ",allUsersSnapShot);
    // buildFOISelector();
    // buildLangSelecorPC();
    document.getElementById('btn_week').style.backgroundColor = 'lightblue';
    var mySelect = document.getElementById("foiSelector1");
    mySelect.onchange = (event) => {
       var fieldName = event.target.value;
       console.log(fieldName);
   
        if (fieldName == "All_as_geusts"){
        
        }
        else{   
            //TODO: find solution to call here not on every change or add a bool
            // console.log("call FOI filter ");                              
            // filterResourcesFOI(fieldName);
        }
    } 

    document.addEventListener('click', function(e) {
    e = e || window.event;
    var target = e.target || e.srcElement,
        text = target.textContent || target.innerText;   
    }, false);

    modal = document.getElementById("textArea");  
    span = document.getElementsByClassName("closeText")[0];
    
    document.getElementById("calendarSingle").style.visibility = "hidden"; 
    document.getElementById("calendar").style.visibility = "visible"; 
    document.getElementById('label_AG').style.display = "";
    document.getElementById('acceptGuest_default').style.display = "";

    document.getElementById('label_AG_singlePage').style.display = "none";
    document.getElementById('acceptGuest_singlePage').style.display = "none"; 
    
    document.getElementById('trimB').style.display = "none"; 
    document.getElementById('confirmB').style.display = "none"; 
    document.getElementById('declineB').style.display = "none"; 

    const button = document.querySelector('#openEventsToConfirm');
    tippy(button,{
            content: 'My tooltip!',
            trigger: 'click',
            allowHTML: true,
            interactive: true,
        });
        tippyInstance = button._tippy;        
    });

var instance ='';
//------------ INIT FUNCTIONS --------------//
var initRun = true;
var passedInit = false;
function InitCal(){ 
    document.getElementById('myself').innerHTML = currentUser.name + " " + currentUser.lastName;
    console.log("initCal");
    buildresources();
    makeCal();
    makeCalAlt();
    makeCalSingle();
    document.getElementById('currentDate').innerHTML = myCalendarAlt.view.title;
    // buildEvents();
    
    console.log("call FOI filter ");

    filterResourcesFOI("hypnosis");  
    passedInit = true;
    // buildFavs();
    //if there is a key sent mimic the event open to confirm.  

    // }
}

function UpdateCalendars(){
    console.log("update calendars");
    if (passedInit == true){
        filterResourcesFOI("hypnosis"); 
    }
}

function filterResourcesFOI(currentField){
    console.log("filterResourcesFOI");
    // tempUsersResourcesByInterestArray = [];
    tempEventsFromResources = [];
    eventsToConfirm = [];
     
    console.log(myCalendar);
    var allResources = myCalendar.getResources();
    for(e in allResources) {
      allResources[e].remove();
    }
    var allResources = myCalendarAlt.getResources();
    for(e in allResources) {
      allResources[e].remove();
    }
    var allCalendarEvents = myCalendarAlt.getEvents();
    for (e in allCalendarEvents) {
        allCalendarEvents[e].remove();
    }
    var allCalendarEvents = myCalendar.getEvents();
    for (e in allCalendarEvents) {
        allCalendarEvents[e].remove();
    }

    var localUsersArray = allUsersSnapShot.toJSON();
    allUsersSnapShot.forEach(function(child) 
    {
        var tempFieldsArray = child.val().fieldsOfinterest;

        if (tempFieldsArray === undefined){ 
            //  console.log("field array not defined");

        }        
        else
        {
            //check if the current user has the same filed of interest 
            if (Object.values(tempFieldsArray).includes(currentField)) 
            {                
                if(child.val().calArray){
                    for (var i = 0; i < child.val().calArray.length; i++) {
                        
                        //add the event to array later pass to clendars
                        let tempEvent = JSON.parse(child.val().calArray[i]);
                        tempEventsFromResources.push(JSON.parse(child.val().calArray[i]));

                        //Add tippy info
                        if(child.val().appId == currentUser.appId){
                            if(tempEvent.extendedProps.description.split("/")[0] == "pending"){
                                // tempEvent.editable = false;
                                //check that date hasnt pass
                                if(moment(tempEvent.start).isAfter()){ 
                                    eventsToConfirm.push(tempEvent);
                                }                        
                            }                            
                        }
                        else{                            
                            if(tempEvent.extendedProps.description.split("/")[0] == "invite"){
                                console.log("found event: ",tempEvent.extendedProps.appId);
                                console.log("found event: ",tempEvent.extendedProps.description);
                                let invitee = tempEvent.extendedProps.description.split("/")[2];
                                if(invitee == currentUser.luid){
                                    //check that date hasnt pass
                                    if(moment(tempEvent.start).isAfter()){ 
                                        eventsToConfirm.push(tempEvent);
                                    } 
                                }                                           
                            }                            
                        }  
                        // if(eventsToConfirm.length >0){
                        //     document.getElementById("openEventsToConfirm").style.background = 'red';
                        // }
                        // else{
                        //     document.getElementById("openEventsToConfirm").style.background = 'white';
                        // }              
                        // allEvents.push(tempEvent);
                    }
                }

                resource = 
                {
                    id:   child.val().appId,
                    title: child.val().name + " " + child.val().lastName
                }

                
                myCalendar.addResource(resource);
                // console.log(myCalendar.getResourceById(child.val().appId).getEvents().length)
            }             
        }            
    });
    console.log('call buildTippyEvents');
    buildTippyEvents();
    console.log("Adding this now: ",tempEventsFromResources.length);
    myCalendar.addEventSource(tempEventsFromResources);
    myCalendarAlt.addEventSource(tempEventsFromResources);
    // resetCalAlt(tempEventsFromResources); 
    // resetCal(tempEventsFromResources);

    
    // handle resize
    var element = document.getElementById('calendarAlt');
    var positionInfo = element.getBoundingClientRect();
    var height = positionInfo.height;
    var width_calendarAlt = positionInfo.width; 
    console.log("width cal: ",width_calendarAlt);
    var element = document.getElementById('topnav');
    var positionInfo = element.getBoundingClientRect();
    var height = positionInfo.height;
    var width_body = positionInfo.width; 
    
    

    var calendarArea = document.getElementById('calendarAlt');    
    var element = document.getElementsByClassName('fc-datagrid-cell-frame')[0];
    
    
    new ResizeSensor(element, function() {
        
        console.log('Changed to ' + element.clientWidth);
        
        var positionInfo = calendarArea.getBoundingClientRect();
        var width1 = positionInfo.width;
        console.log(width1);
        var newwidth = width_body - element.clientWidth;
        calendarArea.style.visibility = 'hidden';
        calendarArea.setAttribute("style","width:"+ newwidth+"px");
        // document.getElementsByClassName('fc-timegrid-slots')[0].setAttribute("style","width:"+ newwidth+"px");
        // document.getElementsByClassName('fc-timegrid-cols')[0].setAttribute("style","width:"+ newwidth+"px");
        // document.getElementsByClassName('fc-timegrid-body')[0].setAttribute("style","width:"+ newwidth+"px");
        var tables = document.getElementsByTagName("table")[0].style.width = newwidth;
        var tables = document.getElementsByTagName("table")[1].style.width = newwidth;
        // var tables = document.getElementsByTagName("table")[0].style.left = element.clientWidth;
        // var tables = document.getElementsByTagName("table")[1].style.left = element.clientWidth;
        document.getElementsByClassName('fc-col-header')[0].setAttribute("style","width:"+ newwidth +"px");
        
        // document.getElementById('calendarAlt').setAttribute("style","left:"+ (element.clientWidth+6)+"px"); 
        // document.getElementById('calendarAlt').style.left = element.clientWidth;
        // console.log('Changed to ' + calendarArea.getBoundingClientRect().width);
        // myCalendarAlt.updateSize()
        // return fireNewFunctionWhenComplete()
        week();
        if(allowInit == true){
            allowInit = false;
            
        }
    });

    
    
    
        //checking this here becasue if outsideit loads the calendar :(
            // better to find a better solution!
            const queryString = window.location.search;
    console.log(queryString);
    if (queryString){
        const urlParams = new URLSearchParams(queryString);  
        let requestKeyMessage = urlParams.get('key')
        let inviteMessage = urlParams.get('invite')

        if (requestKeyMessage != null){
            console.log(requestKeyMessage);
            firebase.database().ref('/requests/'+requestKeyMessage).once('value').then(function(snapshot){            
                // let  originaleventToDelete = JSON.parse(snapshot.val().origEvent);            
                // let requestEventToDelete = JSON.parse(snapshot.val().requestedEvent);
                eventSingle = JSON.parse(snapshot.val().origEvent);
                loadEventToConfirm();
            });
        }

        if(inviteMessage != null) {
            console.log(inviteMessage);
            document.getElementById("calendarAlt").style.visibility = "hidden";
            respondTo_eventInviteThroughURL(inviteMessage);
            // loadInvitedEvent(inviteMessage);
        }
        

    }
    $('#loading').hide();
    // reSize();
    
    
    
  }

 

// function reSize(){    

//     var element = document.getElementById('calendarAlt');
//     var positionInfo = element.getBoundingClientRect();
//     var height = positionInfo.height;
//     var width_calendarAlt = positionInfo.width; 
//     console.log("width cal: ",width_calendarAlt);
//     var element = document.getElementById('topnav');
//     var positionInfo = element.getBoundingClientRect();
//     var height = positionInfo.height;
//     var width_body = positionInfo.width; 
//     // console.log("width top: ",width_body);   
//     // handle resize

//     var calendarArea = document.getElementById('calendarAlt');
//     // var positionInfo = calendarArea.getBoundingClientRect();
//     // var width1 = positionInfo.width;

//     var ro = new ResizeObserver(entries => {
        
        
        
//         for (let entry of entries) {
//           cr = entry.contentRect;
//         //   console.log('Element:', entry.target);
//           console.log(`Element size: ${cr.width}px x ${cr.height}px`);
//         //   console.log(`Element padding: ${cr.top}px ; ${cr.left}px`);
//         }

//         newwidth = width_body - cr.width +1;
//         calendarArea.setAttribute("style","width:"+ newwidth+"px");

//       });
//       let myelem = document.getElementsByClassName('fc-datagrid-cell-frame')[0];
//       ro.observe(myelem);
// }

var forbidInit = false;
function buildresources(){
    usersResourceList = [];
    allUsersSnapShot.forEach(function(child) {
                  
        //create a list of all users with out myself!
        let userFullName = child.val().name + " " + child.val().lastName
        usersResourceList.push({
          
          id: child.val().appId,
          title: userFullName,          
        })
    });   
      
     
    
    //run only on init
    if(forbidInit == false){
        if (allowInit === true){
            console.log("running init cal from buildresources?!");
            // makeCal();
            // makeCalAlt();
            // makeCalSingle();
            // document.getElementById('currentDate').innerHTML = myCalendarAlt.view.title;
            
            forbidInit = true;
        }
    }      
}


 
function buildFOISelector(){
  
    console.log("buildFOISelector");  
    var dynamicSelect = document.getElementById("foiSelector1");
    let filtered=foiList.filter((a,i)=>i%2===1);
    foiList.forEach(function(item)
    {      
            var newOption = document.createElement("option");
            newOption.text = item;//item.whateverProperty
            dynamicSelect.appendChild(newOption);
    });  
    foiSelector = new Selectr(dynamicSelect, {
        multiple: false,
        // selectedValue: currentUser.foiList[0]
      });    
}

var eventsToConfirm = [];

// function buildEvents(){
//     console.log("+++++++++BUILD EVENTS HERE");
//     eventsToConfirm = [];
//     allUsersSnapShot.forEach(function(child) {
//         let calArray = child.val().calArray;
//         if(calArray){
//             for (e in calArray){
//                 // console.log(calArray[e]);
//                 // console.log(calArray[e]);
//                 let tempEvent = JSON.parse(calArray[e]);
//                 if(child.val().appId == currentUser.appId){
//                     if(tempEvent.extendedProps.description.split("/")[0] == "pending"){
//                         // tempEvent.editable = false;
//                         //check that date hasnt pass
//                         if(moment(tempEvent.start).isAfter()){ 
//                             eventsToConfirm.push(tempEvent);
//                         }                        
//                     }
                    
                    
//                     // tempEvent.droppable = true;
//                     //add the user events to seflEvents as JSON
                    
//                 }
//                 else{
//                     // console.log("+++++++++other users events: ",child.val().name);
//                     // console.log("another event: ",tempEvent.extendedProps.status);
//                     // 
//                     if(tempEvent.extendedProps.description.split("/")[0] == "invite"){
//                         console.log("found event: ",tempEvent.extendedProps.appId);
//                         console.log("found event: ",tempEvent.extendedProps.description);
//                         let invitee = tempEvent.extendedProps.description.split("/")[2];
//                         if(invitee == currentUser.luid){
//                             //check that date hasnt pass
//                             if(moment(tempEvent.start).isAfter()){ 
//                                 eventsToConfirm.push(tempEvent);
//                             } 
//                         }                                           
//                     }
//                     // tempEvent.editable = false;
//                     // tempEvent.droppable = false;
//                 }  
//                 if(eventsToConfirm.length >0){
//                     document.getElementById("openEventsToConfirm").style.background = 'red';
//                 }
//                 else{
//                     document.getElementById("openEventsToConfirm").style.background = 'white';
//                 }              
//                 allEvents.push(tempEvent);
//             }
//         }
//     });
    
    
//     buildTippyEvents();
//     myCalendar.addEventSource(allEvents);
//     myCalendarAlt.addEventSource(allEvents);
// }


function buildTippyEvents(){
    console.log('buildTippyEvents: ',eventsToConfirm.length);
    document.getElementById("eventToConfirmList").innerHTML = "";
    if (eventsToConfirm.length == 0){
        document.getElementById("eventToConfirmList").innerHTML = "No Events waiting";
    }
    for (var I = 0; I < eventsToConfirm.length; I++)
    {       
        console.log(eventsToConfirm[I].title + " " + eventsToConfirm[I].id); 
        let statusString = "Request: "        
        allUsersSnapShot.forEach(function(child) {
            if (child.key == eventsToConfirm[I].extendedProps.description.split("/")[1]){
                requestorName = child.val().name + " " + child.val().lastName;
            }
            if (eventsToConfirm[I].extendedProps.description.split("/")[0] == "invite"){
                statusString = "Invite: ";
            }

        });
                      
        // console.log(requestor);                
        // var requestorName = usersResourceList.find(x => x.id === requestor).title;                                                            
        let myString = statusString + moment(eventsToConfirm[I].start).format('DD/MM/YY HH:mm') + ' ' +  requestorName;
        let idString = '"'+ eventsToConfirm[I].id + '"';
        nameList = "<li onclick = 'loadFromList(" + idString + ")' style='cursor: pointer'>" + myString + "</li>";
        document.getElementById("eventToConfirmList").innerHTML += nameList;
    }    
    tippyInstance.setContent(document.getElementById('eventToConfirmList').innerHTML);
}

function buildFavs(){
    //build the fav array on load after initCallback
    for (var i = 0; i < myFavArray.length;i++) {
        let tempString = 'fav'+ myFavArray[i];
        let elemen = document.getElementById(tempString);
        elemen.className = "fa fa-star";        
    }
}
//load events from tippy request events list in the menu bar
function loadFromList(eventId){
    console.log(eventId);
    for (var i = 0; i <eventsToConfirm.length; i++) {
        if (eventsToConfirm[i].id == eventId){
            eventSingle = eventsToConfirm[i];            
            break;
        }
    }
    tippyInstance.hide();
    if(eventSingle.extendedProps.status == "invite"){
        console.log("load invite handle");
        loadInviteEvent();
    }
    else{
        loadEventToConfirm();
    }
}

//------ END INIT FUNCTIONS -----------------//
//------ BUILDING THE CALENDARS--------------//
function makeCal(){
    console.log("makecal");  
      
      var initView = 'resourceTimelineWeek';
      // var initView = 'resourceTimeline';
    //   if (myCalendar.view){
    //     initView = myCalendar.view.type;
    //     myCalendar.destroy();
    //   }
      
      var calendarEl = document.getElementById('calendar');      
      myCalendar = new FullCalendar.Calendar(calendarEl, {
        
        
        // filterResourcesWithEvents: true,
        // Calendar Option
       
        initialView: initView,
        allDaySlot: false,  
        // eventResizableFromStart: true,    
        firstDay: moment().format('e'),
        // dragScroll: false,
        now: moment().format(),
        nowIndicator: true,  
        // editable: false,
        // startEditable: true,
        selectMinDistance: 20,
        // resourceAreaWidth: 30,
        // droppable: false,           
        selectable: true,
        // selectOverlap: false,
        // eventOverlap: true,
        aspectRatio: 1.8,
        scrollTime: moment().format('HH:mm:ss'), // undo default 6am scrollTime
        headerToolbar: {
          left: 'today prev,next',
          center: 'title',
          right: 'resourceTimelineDay,resourceTimelineWeek,resourceTimelineMonth'
          // right: 'timeGridDay,timeGridWeek,dayGridMonth'
        },
        dayMaxEventRows: true,
        eventContent: { domNodes: [] },
        eventContent: function(arg) {
            let italicEl = document.createElement('p');
            
            italicEl.innerHTML = moment(arg.event.start).format('HH:mm')+" - " + moment(arg.event.end).format('HH:mm') + '<br/>' + arg.event.title;
            
           
            let arrayOfDomNodes = [ italicEl ]
            return { domNodes: arrayOfDomNodes }
        },
        resourceAreaHeaderDidMount: function(arg){
            console.log(arg.el);
        },

        eventDidMount: function(arg){
            console.log("call eventMount from calendar");
            eventMount(arg);  
                      
        },

        eventMouseEnter: function(arg){

        },
        resourceAreaColumns: [
            {
              field: 'title',
              headerContent: ' Users list',
              
            },            
        ],

        viewClassNames: function (info) {
            //this is called whenever the calendar changes view!                        
            // console.log(info)
        },
        

        resources: usersResourceList,
  
        dateClick: function(info) {
          //console.log('clicked ' + info.dateStr);
        },
        resourceLabelContent: function (arg)
        {   
            let htmlPart1 = "<i class='fa fa-eye-slash' id='select"+arg.resource.id+"' onclick='toggleSelect(&#039" + arg.resource.id  +"&#039)'></i>"
            let htmlText = "<i class='chatIcon fa fa-comment' onclick='openChat(&#039" + arg.resource.id + "&#039)'></i><i class='fa fa-star-o' id='fav"+arg.resource.id+"' onclick='toggleFavs(&#039" + arg.resource.id  +"&#039)'></i></div>";
            return { html: htmlPart1 + arg.resource.title + " " + htmlText };
        },
        resourceLabelDidMount: function(arg){
            console.log("resourceLabelDidMount: ",arg.resource.title + " " + arg.resource.getEvents().length)
            let userResources = arg.resource.getEvents()
            if(userResources.length >0){
                arg.el.style.backgroundColor = 'orange';
            }
            else{
                arg.el.style.backgroundColor = '#e6ae6f';
            }
            
            //make the row clickable if needed
          arg.el.addEventListener("click", function () { console.log('clicked:' + arg.resource.id); });        
        }, 
        
        eventClick: function(arg) {
            respondTo_eventClick(toggleDisplay_check, arg);            
        },

        select: function(info){
            console.log("select_______________");
            respondTo_EventSelect(info);            
        },

        eventResize: function(info) {
            // console.log("Resize event: " ,info);
            respondTo_EventResize(info);
          },

        eventDrop: function(arg) { // called when an event (already on the calendar) is moved
            console.log('eventDrop', arg.event);  
            respondTo_EventDrop(arg);     
        },
      });      
      myCalendar.render(); 
      console.log('finished cal');
}



function makeCalAlt(){
    console.log("makecalAlt");  
      
      var initView = 'timeGridWeek';
    //   if (myCalendarAlt.view){
    //     initView = myCalendarAlt.view.type;
    //     myCalendarAlt.destroy();
    //   }
      
      var calendarEl = document.getElementById('calendarAlt');      
      myCalendarAlt = new FullCalendar.Calendar(calendarEl, {
        
        // Calendar Option
        handleWindowResize: false,
        initialView: initView,
        allDaySlot: false,    
        eventResizableFromStart: true,   
        firstDay: moment().format('e'),
        // backgroundColor :'white',
        // dragScroll: false,
        now: moment().format(),
        nowIndicator: true,  
        // editable: false,
        // droppable: false,           
        selectable: true,
        // editable: false,
        // startEditable: true,
        selectMinDistance: 20,
        // selectOverlap: false,
        // eventOverlap: false,
        
        aspectRatio: 1.8,
        scrollTime: moment().format("HH:mm:ss"), // undo default 6am scrollTime
        headerToolbar: {
          left: 'today prev,next',
          center: 'title',
          right: 'timeGridDay,timeGridWeek,dayGridMonth'
          // right: 'timeGridDay,timeGridWeek,dayGridMonth'
        },
        
        
        dayMaxEventRows: true,
        eventContent: { domNodes: [] },
        eventContent: function(arg) {
            let italicEl = document.createElement('p')
            italicEl.innerHTML = moment(arg.event.start).format('HH:mm')+" - " + moment(arg.event.end).format('HH:mm') + '<br/>' + arg.event.title;
            let arrayOfDomNodes = [ italicEl ]
            return { domNodes: arrayOfDomNodes }
            
            
        },
        resources: usersResourceList,
  
        dateClick: function(info) {
          //console.log('clicked ' + info.dateStr);
        },
        eventDidMount: function(arg){
            // myCalendarAlt.setOption('editable',false);
            console.log("call eventMount from Alt");
            addEventTippyMouse(arg);
            eventMount(arg);            
        },
        
        // resourceLabelDidMount: function(arg){
        //   arg.el.style.backgroundColor = 'orange';
        // //   console.log(arg.resource);
        //   arg.el.addEventListener("click", function () { console.log('clicked:' + arg.resource.id); });
        // }, 
        
        eventClick: function(arg) {
            respondTo_eventClick(toggleDisplay_check, arg);            
        },

        select: function(info){
            console.log("select_______________");
            respondTo_EventSelect(info);            
        }, 

        eventDrop: function(arg) { // called when an event (already on the calendar) is moved        
            console.log('eventDrop', arg.event);  
            respondTo_EventDrop(arg);     
        },

        eventResize: function(info) {
            console.log("Resize event: " ,info);
            respondTo_EventResize(info);
        },
        // eventMouseEnter: function(arg){
        //     addEventTippyMouse(arg);
        // },
       
      });      
      myCalendarAlt.render(); 
}

function today(){
    myCalendar.today();
    myCalendarAlt.today();
    document.getElementById('currentDate').innerHTML = myCalendarAlt.view.title;
}
function nextDate(){
    myCalendar.next();
    myCalendarAlt.next();
    document.getElementById('currentDate').innerHTML = myCalendarAlt.view.title;
}
function prevDate(){
    myCalendar.prev();
    myCalendarAlt.prev();
    document.getElementById('currentDate').innerHTML = myCalendarAlt.view.title;
}

function day(){
    
    document.getElementById('btn_day').style.backgroundColor = 'lightblue';
    document.getElementById('btn_week').style.backgroundColor = 'lightGray';
    document.getElementById('btn_month').style.backgroundColor = 'lightGray';
    myCalendar.changeView('resourceTimelineDay');
    myCalendarAlt.changeView('timeGridDay');
    myCalendar.setOption('scrollTime',moment().format());
    myCalendarAlt.scrollTime = moment().format();
    // myCalendar.scrollTime = moment().format();
    document.getElementById('currentDate').innerHTML = myCalendarAlt.view.title;
}
function week(){
    document.getElementById('btn_day').style.backgroundColor = 'lightGray';
    document.getElementById('btn_week').style.backgroundColor = 'lightblue';
    document.getElementById('btn_month').style.backgroundColor = 'lightGray';
    
    myCalendar.changeView('resourceTimelineWeek');
    myCalendarAlt.changeView('timeGridWeek');
    myCalendarAlt.scrollTime = moment().format();
    myCalendar.scrollTime = moment().format();
    document.getElementById('currentDate').innerHTML = myCalendarAlt.view.title;
}
function month(){
    document.getElementById('btn_day').style.backgroundColor = 'lightGray';
    document.getElementById('btn_week').style.backgroundColor = 'lightGray';
    document.getElementById('btn_month').style.backgroundColor = 'lightblue';
    
    myCalendar.changeView('resourceTimelineMonth');
    myCalendarAlt.changeView('dayGridMonth');
    myCalendarAlt.scrollTime = moment().format();
    myCalendar.setOption('scrollTime',moment().format());
    // myCalendar.scrollTime = moment().format();
    document.getElementById('currentDate').innerHTML = myCalendarAlt.view.title;
}
//--------- Calendar options for alt and regular ---------//
var allowTippy = true;

function showTippy(instance){
    // console.log(instance);
    if(allowTippy == false){
        // instance.hide();
    }
    else{
        // instance.show(); 
    }
}

function deleteFromTippy(event){
    console.log("deleteFromTippy ",event);
    eventSingle = myCalendar.getEventById(event);
    console.log(eventSingle);
    // tippInstance.destroy();
    deleteEvent();
    
}
function addEventTippy(arg){

}


function addEventTippyMouse(arg){
    let r = Math.random().toString(36).substring(2);
    console.log('addEventTippy');
    allUsersSnapShot.forEach(function(child){
        if (child.key == arg.event.extendedProps.description.split("/")[1]){
            autherName = child.val().name + " " + child.val().lastName;
        }
    });
    console.log("autherName ",autherName);
    const template = document.getElementById('template');
    document.getElementById('tip_title').innerHTML = autherName;
    document.getElementById('tip_date').innerHTML = moment(arg.event.start).format('dddd DD.MM.YYYY');
    document.getElementById('tip_start').innerHTML = moment(arg.event.start).format('HH:mm') + "-" + moment(arg.event.end).format('HH:mm');
    document.getElementById('tip_cancelInvite').style.display = 'none';
    document.getElementById('tip_acceptInvite').style.display = 'none';
    document.getElementById('tip_declineInvite').style.display = 'none';
   
        console.log("props: " + arg.event.id + " " + arg.event.extendedProps.description)
    if(arg.event.extendedProps.appId == currentUser.appId){
        console.log("add trash");
        
        //Set the tippy header
        let elem = document.getElementById('tip_trash');
        document.getElementById('tip_trash').style.display = '';                    
        let currentStringValue = 'deleteFromTippy("'+arg.event.id+'")';
        // console.log(currentStringValue);
        elem.setAttribute('onclick',currentStringValue); 
        if(arg.event.extendedProps.description.split("/")[0] == "open"){
            console.log("add invite");
            let elem_invite = document.getElementById('tip_invite');
            document.getElementById('tip_invite').style.display = '';                    
            let currentInviteStringValue = 'openInviteUserModal("'+arg.event.id+'")';
            // console.log(currentStringValue);
            elem_invite.setAttribute('onclick',currentInviteStringValue);
        }
        else if(arg.event.extendedProps.description.split("/")[0] == "waiting"){

        }
        else if(arg.event.extendedProps.description.split("/")[0] == "booked"){

        }
        else{
            document.getElementById('tip_invite').style.display = 'none';
        }
    }
    else{
        console.log("add none");
        document.getElementById('tip_trash').style.display = 'none';
        document.getElementById('tip_invite').style.display = 'none';
        document.getElementById('tip_cancelInvite').style.display = 'none';
        document.getElementById('tip_acceptInvite').style.display = 'none';
        document.getElementById('tip_declineInvite').style.display = 'none';
        
    }
    // if(instance !== undefined){
    //     instance.destroy();
    // }
    
     new tippy(arg.el, {
        content: template.innerHTML,
        allowHTML: true,
        interactive: true,  
        theme: 'tomato',
              
        appendTo: function() {
            return document.querySelector('.calendarArea')
          },
        onShow(instance){
            if(allowTippy == false){
                instance.popper.style.display ='none';
            }
            else{
                instance.popper.style.display ='';
            }            
        }         
    });
    // const instance = tippy(document.querySelector('arg.el')); 
    // console.log(instance);
    
    
}


function eventMount(arg){
    console.log("eventDidmount");
    if( arg.view.type == 'resourceTimelineWeek'){
        arg.el.className +=" timeLineCell"
    }
            
    // const template = document.getElementById('template');
    // let tempId = arg.event.extendedProps.description.split("/")[1];
    allUsersSnapShot.forEach(function(child){

        if (child.key == arg.event.extendedProps.description.split("/")[1]){
            autherName = child.val().name + " " + child.val().lastName;
        }
    });
            
    //=================== USER EVENTS =====================//


        // console.log("checking on mount:",arg.event.extendedProps.description.split("/")[0]);
    if(arg.event.extendedProps.appId == currentUser.appId){
        console.log("found my event id: ",arg.event.id);
        arg.el.style.backgroundColor = color_normal_me;

        if(arg.event.extendedProps.description.split("/")[0] == "open"){
            // arg.event.setProp("editable" , true);
            arg.event.setProp("title" , autherName); 
            if(arg.event.extendedProps.acceptGuest == true){
                arg.el.style.backgroundColor = color_guest_me;
            }
            else{
                arg.el.style.backgroundColor = color_normal_me;
            }
            addEventTippy(arg);

        }

        else if(arg.event.extendedProps.description.split("/")[0] == "invite"){
            
            arg.el.style.backgroundColor = color_special; 
            let invitee = arg.event.extendedProps.description.split("/")[2]; 
            // console.log("invitee: ",invitee);
            allUsersSnapShot.forEach(function(child){
                if(child.key == invitee){
                    var inviteeName = child.val().name + " " + child.val().lastName;                                        
                    arg.event.setProp("title" , "Waiting acceptence from: " + inviteeName); 
                    
                }
            });
            addEventTippy(arg);
            // console.log(requestor);                
                                                                        
        }

            
        else if(arg.event.extendedProps.description.split("/")[0] == "waiting"){
            arg.el.style.backgroundColor = color_toBook;
            allUsersSnapShot.forEach(function(child) {
                if (child.key == arg.event.extendedProps.description.split("/")[1]){
                    requestorName = child.val().name + " " + child.val().lastName;
                }
    
            });                                    
            arg.event.setProp("editable" , false);
            addEventTippy(arg);

        }

        else if(arg.event.extendedProps.description.split("/")[0] == "pending"){
            arg.el.style.backgroundColor = color_toBook;
            allUsersSnapShot.forEach(function(child) {
                if (child.key == arg.event.extendedProps.description.split("/")[2]){
                    requestorName = child.val().name + " " + child.val().lastName;
                }
    
            }); 
            let ventObj = arg.event;
            // ventObj.setProp("title" , "Waiting for your approval from: " + requestorName);
            ventObj.setProp("editable" , false); 
            addEventTippy(arg);                                                                           

        }
        else if(arg.event.extendedProps.description.split("/")[0] == "booked"){
            arg.el.style.backgroundColor = color_booked;
            let newtitle = arg.event.title.replace('requested by: ',"");                     
            if(arg.event.title.includes('requested by')){
                arg.event.setProp("title" , "Confirmed with: " + newtitle);
            }  
            addEventTippy(arg);                                  
        }                            
    }
    else{
        console.log("found NOT my event id: ",arg.event.id);
        // console.log(typeof(arg.el.className));
        let classi = arg.el.className;
        if(classi.includes('fc-event-draggable')){
            classi.replace('fc-event-draggable',"");
            classi = classi.replace(/fc-event-draggable/, '');
        }
        if(classi.includes('fc-event-resizable')){
            classi = classi.replace(/fc-event-resizable/,'');
        }
        // console.log(classi);
        arg.el.className = classi;
        arg.el.style.backgroundColor = color_main;

        if(arg.event.extendedProps.description.split("/")[0] == "open"){
            let ventObj = arg.event;
            ventObj.setProp("title" , autherName);
            ventObj.setProp("editable" , false);                 
            if(arg.event.extendedProps.acceptGuest == true){
                arg.el.style.backgroundColor = color_guest;
            }
            else{
                arg.el.style.backgroundColor = color_main;
            }
            addEventTippy(arg);
            

        }
        else if(arg.event.extendedProps.description.split("/")[0] == "invite"){
            allUsersSnapShot.forEach(function(child){
                if(child.key == arg.event.extendedProps.description.split("/")[1]){
                    OriginalUser = child.val().name + " " + child.val().lastName;                            
                    arg.event.setProp("title" , "Invited by " + OriginalUser);
                }

            });
            // let invitee = arg.event.extendedProps.description.split("/")[2];
            if(arg.event.extendedProps.description.split("/")[2] == currentUser.luid){
                                        
                arg.el.style.backgroundColor = color_invite; 
                addEventTippy(arg);
            }
            else{
                arg.event.setProp('display','none');
            }
                                                                        
        }
        
        else if(arg.event.extendedProps.description.split("/")[0] == "waiting"){
            arg.event.setProp('display','none');

        }

        else if(arg.event.extendedProps.description.split("/")[0] == "pending"){
            arg.event.setProp('display','none');

        }
        else if(arg.event.extendedProps.description.split("/")[0] == "booked"){
            arg.event.setProp('display','none');
            
        }                        
    }   
}

var eventSingle = [];






function respondTo_EventDrop(arg){
        var eventObj = arg.event;
        if (eventObj.extendedProps.appId != currentUser.appId){
            //console.log("Not your event, can't touch this.");
            
            arg.revert();
            return;
        }
        else
        {
            var eventEnding = moment(eventObj.end);            
            //--check if the current time clicked is before the end of event, if so allow to click, else do nothing.
            var timeClickedDate = Date.parse(moment().format('YYYY-MM-DD'));
            let endDate = Date.parse(eventEnding.format('YYYY-MM-DD'));
            if (timeClickedDate>endDate){
            //console.log("event is in the past");
            alert("You can not move an event in the past!");
            arg.revert();
            return;
            }
            else if (timeClickedDate == endDate){
            var timeClickedTime = moment().format('HH:mm:ss');
            let endTime = eventEnding.format('HH:mm:ss');              
            str1 =  timeClickedTime.split(':');
            str2 =  endTime.split(':');
    
            //console.log(timeClickedTime + " " + endTime);
    
            totalSecondsTimeClicked = parseInt(str1[0] * 3600 + str1[1] * 60 + str1[0]);
            totalSecondsEndtime = parseInt(str2[0] * 3600 + str2[1] * 60 + str2[0]);
            //console.log(totalSecondsTimeClicked + " " + totalSecondsEndtime);
            if (totalSecondsTimeClicked > totalSecondsEndtime ){
                //console.log("event is in the past");
                alert("You can not move an event in the past!");
                return;
            }
            else{
                //console.log("event is in the future");
            }          
        } 
        for (let index = 0; index < currentUser.calArray.length; index++) {
            var element = JSON.parse(currentUser.calArray[index]);
            console.log(element.id + " / "  + eventObj.id);                
            if(element.id == eventObj.id){
                console.log("found event - ", element);
                console.log(eventObj.end);
                
                element.start = moment(eventObj.start);
                element.end = moment(eventObj.end);

                currentUser.calArray[index] = JSON.stringify(element);
                console.log(JSON.parse(currentUser.calArray[index]));                    
                break;
            }                
        }

        myCalendar.getEventById(arg.event.id).remove();
        myCalendarAlt.getEventById(arg.event.id).remove();
        
        myCalendar.addEvent(eventObj);
        myCalendarAlt.addEvent(eventObj);
        writeEventsP();
    }
}

function respondTo_eventClick(source, arg){
    console.clear();
    console.log('eventClick: ',source + " " ,JSON.stringify(arg.event.getResources()));
    
    // return;
    console.log("the clicked event is: ", JSON.stringify(arg.event));
    document.getElementById("toggleSelf").style.display = "none";
    document.getElementById("toggleDisplay").style.display = "none";
    document.getElementById("toggleResources").style.display = "none";
    document.getElementById('AddEventManually').style.display = "none";
    document.getElementById('openEventsToConfirm').style.display = "none";
    document.getElementById('btn_day').disabled = true;
    document.getElementById('btn_week').disabled = true;
    document.getElementById('btn_month').disabled = true;
    document.getElementById('label_AG_singlePage').style.display = "";
    document.getElementById('acceptGuest_singlePage').style.display = "";
    document.getElementById("inviteUserSingle").style.display = "inline-block";
    

    eventSingle = arg.event;
    console.log("eventSingle: ", eventSingle);
    let elements =calendarSingle.getEvents();
    for (e in elements){ 
        let element = elements[e];
        element.remove();
    }    
    
    if(eventSingle.extendedProps.description.split("/")[0] == "pending"){        
        console.log("loading pending event");
        loadEventToConfirm();
        return;        
    }

    else if(eventSingle.extendedProps.description.split("/")[0] == "waiting"){ 
        document.getElementById("inviteUserSingle").style.display = "none";  
        document.getElementById('label_AG_singlePage').style.display = "none";
        document.getElementById('acceptGuest_singlePage').style.display = "none";      
        console.log("loading waiting event");
    }

    else if(eventSingle.extendedProps.description.split("/")[0] == "booked"){        
        console.log("loading booked event");
        document.getElementById("inviteUserSingle").style.display = "none";  
        document.getElementById('label_AG_singlePage').style.display = "none";
        document.getElementById('acceptGuest_singlePage').style.display = "none"; 
    }

    else if(eventSingle.extendedProps.description.split("/")[0] == "invite"){ 
        document.getElementById("inviteUserSingle").style.display = "none"; 
        console.log("loading invite event");
        loadInviteEvent();
        return;
    }

    else if(eventSingle.extendedProps.description.split("/")[0] == "open"){
        console.log("loading open event");
    }
    
    
    calendarSingle.addEvent(eventSingle);
    sourceCal = "single";
    if(eventSingle.extendedProps.appId == currentUser.appId){
        
        document.getElementById("deleteEvent").style.display = "inline-block";
        
        calendarSingle.setOption("scrollTime", moment(eventSingle.start).format('HH:mm'));
        calendarSingle.setOption("slotMaxTime", "24:00:00");
        calendarSingle.setOption("slotMinTime", "00:00:00");         
        
    }
    else{
        document.getElementById("inviteUserSingle").style.display = "none";
        document.getElementById("requestEv").style.display = "inline-block";
        document.getElementById('label_AG_singlePage').style.display = "none";
        document.getElementById('acceptGuest_singlePage').style.display = "none";
        calendarSingle.setOption("slotMaxTime", moment(eventSingle.end).format('HH:mm'));
        calendarSingle.setOption("slotMinTime", moment(eventSingle.start).format('HH:mm'));
        // event.display =  'background';
    }

    document.getElementById("calendar").style.visibility = "hidden"; 
    document.getElementById("calendarAlt").style.visibility = "hidden";
    document.getElementById("calendarSingle").style.visibility = "visible";
    document.getElementById("backToCal").style.display = "";
    document.getElementById('label_AG').style.display = "none";
    document.getElementById('acceptGuest_default').style.display = "none";
    

    calendarSingle.addEvent(eventSingle);
    calendarSingle.render();
    calendarSingle.gotoDate(moment(eventSingle.start).format());

    //disable dragging
    var timeSlotArray =document.getElementsByClassName("fc-event-draggable");
    var timeSlot = timeSlotArray[timeSlotArray.length-1];
    if(timeSlot !== undefined){
        timeSlot.className = "fc-timegrid-event fc-v-event fc-event fc-event-resizable fc-event-start fc-event-end fc-event-today fc-event-future";
    }
    
    

    document.getElementById('acceptGuest_default').style.display = "none";
    if (eventSingle.extendedProps.acceptGuest == true){          
        document.getElementById('acceptGuest_singlePage').checked = true;
    }
    else{          
        document.getElementById('acceptGuest_singlePage').checked = false;
    }

    // listen for esc pressed to go back
    
    $(document).keyup(function(e) {
        if (e.key === "Escape") { // escape key maps to keycode `27`
            if (textModalOpen == false){
                backToCal()
            }
        }
    });
    
}

 


function makeCalSingle(){
    console.log("makeCalSingle");
    let calendarEl = document.getElementById('calendarSingle')
    calendarSingle = new FullCalendar.Calendar(calendarEl, {

      

        displayEventTime:true,
        initialView: 'timeGridDay',
        // initialView:'resourceTimeline',
        allDaySlot: false, 
        // allDay:false,
        // editable: false,
        selectable: true,
        // dragScroll:false,
        // editable: editable,
        // droppable: false, 
        eventResizableFromStart: true,
        slotDuration: ('00:15:00'), 
        dayMaxEventRows: true,                        
        // scrollTime: (scrollT), 
        eventContent: { domNodes: [] },            
        eventContent: function(arg) {
              let italicEl = document.createElement('p')                  
              italicEl.innerHTML = moment(arg.event.start).format('HH:mm')+" - " + moment(arg.event.end).format('HH:mm') + '<br/>' + arg.event.title;
            //   let id = arg.event.getResources().id;
            //   italicEl.innerHTML += "<i class='chatIcon fa fa-comment' onclick='openChat(&#039" + id + "&#039)'></i><i class='fa fa-star-o' id='toggleAllFavSelection' onclick='toggleAllFavsSelection(&#039" + id  +"&#039)'></i></div>";
              let arrayOfDomNodes = [ italicEl ]
              return { domNodes: arrayOfDomNodes }
        },

        resources: usersResourceList,             
        events: [
            {
                
            }
        ],
        eventDidMount: function(arg){
            console.log("call eventMount from single");
            eventMount(arg); 
            let event = arg.event;
            
            if(event.extendedProps.appId == currentUser.appId){
                // event.setProp('selectabe','false');
                calendarSingle.setOption('selectable','false');
                console.log(calendarSingle);

            }   
            else{
                calendarSingle.setOption('selectable','true');
                event.setProp('display','background');
            }        
        },

        select: function(info){
            
            if(calendarSingle.getEvents()[0].extendedProps.appId == currentUser.appId){
                return;
            }
            console.log(calendarSingle.getEvents().length);
            if (calendarSingle.getEvents().length > 1){
                calendarSingle.getEvents()[1].remove();
            }
            var eventObj = info.event;
            var eventEnding = moment(info.startStr);
            console.log(eventEnding);   
                                          
            // var allowGuest = false;
            // var bgColor = color_toBook;
            let r = Math.random().toString(36).substring(2);

            
            calendarSingle.addEvent({
              resourceId: currentUser.appId,
              id: r,
              title: currentUser.name +" " +currentUser.lastName,
              start: moment(info.start).format(),
              end: moment(info.end).format(),              
              editable: true,
              eventResizableFromStart: true,
            //   droppable: true,
              description :"",
              status: "open",
              backgroundColor: color_toBook,  
            //   draggable: false,            
              extendedProps:{
                acceptGuest : false,
                appId: currentUser.appId,
                // auther: currentUser.name + " " + currentUser.lastName,
                // droppable: false
              }              
            })
          },


          eventResize: function(info){
              console.log("Single eventResize: ")
              if (info.event.extendedProps.appId == currentUser.appId){
                // respondTo_EventResize(info);
              }
              else{
                info.revert()
              }
                

          }
                                    
    });
}




function writeEventsP(){
    console.log("writeEvent sP");             
    firebase.database().ref('users/' + currentUser.luid).update(
      {        
        calArray: currentUser.calArray        
      });    
}

//------ END BUILDING THE CALENDARS--------------//

function resetCalAlt(events){
    // console.log(events);
    let elements =myCalendarAlt.getEvents();
    for (e in elements){ 
        let element = elements[e];
        element.remove();
    }
    myCalendarAlt.addEventSource(events);
}

function resetCal(events){
    // console.log(events);
    let elements =myCalendar.getEvents();
    for (e in elements){ 
        let element = elements[e];
        element.remove();
    }
    myCalendar.addEventSource(events);
}


//---------- BUTTONS ACTIONS -----------//

function toggleFavs(id){
    console.log("toggleAffFavs ",id);
    event.stopPropagation(); 
    let tempFavIcon = document.getElementById('fav'+id);

    if (tempFavIcon.className == "fa fa-star-o"){ //not a fav yet
        tempFavIcon.className = "fa fa-star";
        if (typeof myFavArray === 'undefined' || myFavArray === null) {
          myFavArray = [];
        }


        // console.log(usersResourceList[id]);
        // var kvpair = { key: id, value: usersResourceList[id] };
        // console.log(kvpair);        
        myFavArray = myFavArray.concat(id); 
      }
      else{ //already a fav
        tempFavIcon.className = "fa fa-star-o";
        const index = myFavArray.indexOf(id);
        if (index > -1) {
          myFavArray.splice(index, 1);
        }
      }
      console.log(myFavArray);

      //--write Favs to seperate firebase database
      firebase.database().ref('/favs/'+ currentUser.appId).update({
        myFavArray: myFavArray
      });

}
var showOnlyFavs = false;

function toggleAllFavs(){
    var allResources = myCalendar.getResources();
    var allEventsAlt = myCalendarAlt.getEvents();
    event.stopPropagation(); 

    if (showOnlyFavs == false){ //show here only Favs
        showOnlyFavs = true;
        document.getElementById('btn_toggleFavs').innerHTML = ('Show All Users');
       
        for(e in allResources) {
            allResources[e].remove();
            }
        for(k in allEventsAlt) {
            allEventsAlt[k].remove();
            }

        var filteredResources = [];
        for(f in myFavArray){
            let key = myFavArray[f];            

            for (var i = 0; i <usersResourceList.length; i++){
                if (usersResourceList[i].id == key){
                    console.log('found user',usersResourceList[i])
                    myCalendar.addResource(usersResourceList[i]);

                    var resourceA = myCalendar.getResourceById(key);
                    console.log(resourceA);        
                    
                    filteredResources = filteredResources.concat(resourceA.getEvents());
                    // filteredResources.push(resourceA.getEvents()); 
                    console.log(filteredResources);                      
                    break;
                }                     
            }            
        }

        
        console.log(filteredResources);        
        resetCalAlt(filteredResources); 
        buildFavs();       
    }
    else{ //show all users
        showOnlyFavs = false;
        document.getElementById('btn_toggleFavs').innerHTML = ('Show Favorites');

        //Show all users according to selected field of interest
        for(e in allResources) {
            allResources[e].remove();
        };         
        for (e in usersResourceList){            
            myCalendar.addResource(usersResourceList[e]);   
        };  

        var mySelect = document.getElementById("foiSelector1");
        var fieldName = mySelect.value;  
        console.log("call FOI filter ");          
        filterResourcesFOI(fieldName); 

        buildFavs();
    }
    
}


function toggleSelect(id){
    console.log("toggleSelect ",id);
    event.stopPropagation(); 
    var allResources = myCalendar.getResources();
    console.log(allResources.length);
    let tempSelectIcon = document.getElementById('select'+id);

    if (tempSelectIcon.className == "fa fa-eye-slash"){ //not selected yet
        
        //remove all resources
        for(e in allResources) {
            allResources[e].remove();
        }

        //get the user selected
        for (var i = 0; i <usersResourceList.length; i++){
            if (usersResourceList[i].id == id){
                console.log('found user',usersResourceList[i])
                myCalendar.addResource(usersResourceList[i]);

                var resourceA = myCalendar.getResourceById(id);
                tempEventsFromResources = resourceA.getEvents();        
                resetCalAlt(tempEventsFromResources);
                resetCal(tempEventsFromResources);
                setSelectedIcon(id);
            }
        }                 
    }
    else{ //already a fav
        tempSelectIcon.className = "fa fa-eye-slash";
        // for(e in allResources) {
        //     allResources[e].remove();
        // };         
        // for (e in usersResourceList){            
        //     myCalendar.addResource(usersResourceList[e]);   
        // };  

        var mySelect = document.getElementById("foiSelector1");
        var fieldName = mySelect.value;   
        console.log("call FOI filter ");         
        filterResourcesFOI(fieldName); 
    }     
}

function setSelectedIcon(id){
    let tempSelectIcon = document.getElementById('select'+id);
    tempSelectIcon.className = "fa fa-eye";
}

var showOnlyFavs = false;

function toggleAllSelected(){
    var allResources = myCalendar.getResources();
    var allEventsAlt = myCalendarAlt.getEvents();
    event.stopPropagation(); 

    if (showOnlyFavs == false){ //show here only Favs
        showOnlyFavs = true;
        document.getElementById('btn_toggleFavs').innerHTML = ('Show All Users');
       
        for(e in allResources) {
            allResources[e].remove();
            }
        for(k in allEventsAlt) {
            allEventsAlt[k].remove();
            }

        var filteredResources = [];
        for(f in myFavArray){
            let key = myFavArray[f];            

            for (var i = 0; i <usersResourceList.length; i++){
                if (usersResourceList[i].id == key){
                    console.log('found user',usersResourceList[i])
                    myCalendar.addResource(usersResourceList[i]);

                    var resourceA = myCalendar.getResourceById(key);
                    console.log(resourceA);        
                    
                    filteredResources = filteredResources.concat(resourceA.getEvents());
                    // filteredResources.push(resourceA.getEvents()); 
                    console.log(filteredResources);                      
                    break;
                }                     
            }            
        }

        console.log(filteredResources);        
        resetCalAlt(filteredResources); 
        buildFavs();       
    }
    else{ //show all users
        showOnlyFavs = false;
        document.getElementById('btn_toggleFavs').innerHTML = ('Show Favorites');

        //Show all users according to selected field of interest
        for(e in allResources) {
            allResources[e].remove();
        };         
        for (e in usersResourceList){            
            myCalendar.addResource(usersResourceList[e]);   
        };  

        var mySelect = document.getElementById("foiSelector1");
        var fieldName = mySelect.value; 
        console.log("call FOI filter ");           
        filterResourcesFOI(fieldName); 

        buildFavs();
    }
    
}




function openChat(id){
    console.log("openChat ",id);
    event.stopPropagation(); 
    allowInit = false;
    
    // let tempChatIcon = document.getElementById(passedUserAppId.id).getElementsByClassName('fa-comment');
    // console.log(tempChatIcon[0]);
      
    // tempChatIcon[0].className = "chatIcon fa fa-comment";
  
    document.getElementById("singleUserPage").innerHTML='<object type="text/html" style="width:100vw; height:100vh;" data="../gse5/singleUser.html?id='+id+'"></object>';
  
    // let url="../gse5/singleUser.html?id="+passedUserAppId.id;
    // popupWindow = window.open(url,'popUpWindow','height=500,width=500,left=100,top=100,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no, status=yes').focus();
    var modal = document.getElementById("singleUser");  
    var span = document.getElementsByClassName("closeSingleUser")[0];
    
    modal.style.display = "block";
  
    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
      modal.style.display = "none";
    }
  
    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
      if (event.target == modal) {
        // modal.style.display = "none";
      }
    }
}


var onlyResourcesWithEventsCheck = false;
 
function showOnlyResourcesWithEvents(){
      console.log(onlyResourcesWithEventsCheck);
      if(onlyResourcesWithEventsCheck == false){
          onlyResourcesWithEventsCheck = true;
          myCalendar.setOption('filterResourcesWithEvents','true');
      }
      else{
        onlyResourcesWithEventsCheck = false;
        myCalendar.setOption('filterResourcesWithEvents','false');
        buildresources();
        var mySelect = document.getElementById("foiSelector1");
        var fieldName = mySelect.value;
        console.log(fieldName);
        console.log("call FOI filter ");
        filterResourcesFOI(fieldName);
                         
      }
     

    
    //filter only with events 

}
function buildLangSelecorPC(){

    
    var dynamicSelect = document.getElementById("langSelector");
    let filtered=countriesList.filter((a,i)=>i%2===1);
    filtered.forEach(function(item)
    {
            var newOption = document.createElement("option");
            newOption.text = item.toString();//item.whateverProperty
            dynamicSelect.add(newOption);
    });
    
    console.log(currentUser.mainLanguage);
    langSelector = new Selectr(dynamicSelect, {
        multiple: false,
        customClass: 'langSelectr',
        width: 100,
        placeeholder: 'Choose Language'
        // selectedValue: currentUser.mainLanguage
    });    
}

var langFilterOn = false;
function filterLanguages(){
    var allResources = myCalendar.getResources();

    if(langFilterOn == false){
        tempEventsFromResources = [];
        langFilterOn = true;
        var langToFilter = langSelector.getValue();
        console.log("filterLanguages: ", langToFilter);
        document.getElementById('btn_filterLang').innerText = "Show all";
   
        for(e in allResources) {
            allResources[e].remove();
        }

        for (u in allResources){
            
            let tempUserId = allResources[u].id;
            console.log(tempUserId)
            var localUsersArray = allUsersSnapShot.toJSON();
            allUsersSnapShot.forEach(function(child) 
            {
                

                if (child.val().appId == tempUserId){ 
                    console.log("found user here",child.val().name + "  " + child.val().appId);
                    if(child.val().mainLanguage.length >0){
                        let userLangugesArray = child.val().mainLanguage;
                        console.log(userLangugesArray);
                        for (l in userLangugesArray){
                            if(userLangugesArray[l] == langToFilter){
                                resource = 
                                {
                                    id:   child.val().appId,
                                    title: child.val().name + " " + child.val().lastName
                                }
                                myCalendar.addResource(resource);

                                if(child.val().calArray){
                                    for (var i = 0; i < child.val().calArray.length; i++) {
                                        // if (child.val().appId == currentUser.appId){
                                        //     child.val().calArray[i].editable = true;
                                        //     child.val().calArray[i].draggable = true;
                                        // }
                                        // else{
                                        //     child.val().calArray[i].editable = false;
                                        //     child.val().calArray[i].draggable =false;
                                        // }
                                        tempEventsFromResources.push(JSON.parse(child.val().calArray[i]));
                                    }
                                }
                            }
                        }
                    }
                }        
                           
            });


        }
        
        console.log(tempEventsFromResources);
        resetCalAlt(tempEventsFromResources); 
        resetCal(tempEventsFromResources);

    }
    else{
        langFilterOn = false;
        document.getElementById('btn_filterLang').innerText = "filter lang";
        for(e in allResources) {
            allResources[e].remove();
        };         
        for (e in usersResourceList){            
            myCalendar.addResource(usersResourceList[e]);   
        };  

        var mySelect = document.getElementById("foiSelector1");
        var fieldName = mySelect.value; 
        console.log("call FOI filter ");           
        filterResourcesFOI(fieldName);
    }
   
    
}

function filterCountry(){
    console.log("filterCountry");
    

}
function toggleDisplay(){
      if (toggleDisplay_check == true){
            toggleDisplay_check =false;
            // myCalendar.destroy();
            // myCalendarAlt.destroy();
            // myCalendarAlt.render();
            // myCalendarAlt.refetchEvents();
            sourceCal = "alt";
            // document.getElementById('calendar').style.visibility = 'hidden';
            document.getElementById('calendarAlt').style.visibility = 'visible';
            document.getElementById('myList').style.visibility = 'hidden';  
      }
      else{
            toggleDisplay_check = true;
            sourceCal = "source";
            // document.getElementById('calendar').style.visibility = 'visible';
            document.getElementById('calendarAlt').style.visibility = 'hidden';
            document.getElementById('myList').style.visibility = 'hidden';            
      }                
}


function toggleSelf(){
    console.log("toggleSelf");

    var allResources = myCalendar.getResources();
    //Show only myself and my events
    if (toggleSelfCheck === false){          
        toggleSelfCheck = true;
        for(e in allResources) {
            console.log(allResources[e].getEvents().length);
            allResources[e].remove();
        }

        resourceA = 
                {
                    id:   currentUser.appId,
                    title: currentUser.name + " " + currentUser.lastName
                }
        myCalendar.addResource(resourceA);

        var resourceA = myCalendar.getResourceById(currentUser.appId);        
        allEvents = resourceA.getEvents();

        tempEventsFromResources = resourceA.getEvents();        
        resetCalAlt(tempEventsFromResources);
        resetCal(tempEventsFromResources); 
                      
    }
    else{
        //Show all users according to selected field of interest
          toggleSelfCheck = false;
            // for(e in allResources) {
            //     allResources[e].remove();
            // };         
            // for (e in usersResourceList){            
            //     myCalendar.addResource(usersResourceList[e]);   
            // };  

            var mySelect = document.getElementById("foiSelector1");
            var fieldName = mySelect.value;  
            console.log("call FOI filter ");          
            filterResourcesFOI(fieldName);      
    }  
}

function backToCal(){
    
    //myCalendar
    console.log("backtoCal ", sourceCal);
    if(sourceCal == "singleInvite"){
        checkIfTimeChanged();
    }
    else if(sourceCal == "single"){
        calendarSingle.destroy();
    }
    else if(sourceCal == "singleConfirm"){        
        calendarConfirm.destroy();
    }
    document.getElementById("calendarSingle").style.visibility = "hidden";

    document.getElementById('btn_day').disabled = false;
    document.getElementById('btn_week').disabled = false;
    document.getElementById('btn_month').disabled = false;
    
    document.getElementById("requestEv").style.display = "none";
    document.getElementById("backToCal").style.display = "none";
    document.getElementById("deleteEvent").style.display = "none";
    document.getElementById("inviteUserSingle").style.display = "none";

    document.getElementById('trimB').style.display = "none"; 
    document.getElementById('confirmB').style.display = "none" 
    document.getElementById('declineB').style.display = "none"

    document.getElementById("toggleSelf").style.display = "";
    document.getElementById("toggleDisplay").style.display = "";
    document.getElementById("toggleResources").style.display = "";
    document.getElementById("openEventsToConfirm").style.display = "";

    document.getElementById('label_AG').style.display = "";
    document.getElementById('acceptGuest_default').style.display = "";

    document.getElementById('label_AG_singlePage').style.display = "none";
    document.getElementById('acceptGuest_singlePage').style.display = "none";
    document.getElementById('AddEventManually').style.display = "";

    document.getElementById("calendar").style.visibility = "visible"; 
    document.getElementById("calendarAlt").style.visibility = "visible";

    toggleDisplay();
    if (toggleSelfCheck === true){
        toggleSelfCheck = false;
        toggleDisplay();
    }
    else{
        toggleSelfCheck = true;
        toggleDisplay();
    }
    document.getElementById('currentDate').innerHTML = myCalendarAlt.view.title;
    // myCalendar.refetchEvents();
    // myCalendarAlt.refetchEvents();

}

function checkIfTimeChanged(){
    console.log("checkIfTimeChanged");
    console.log(eventSingle.start);
    let curEve = calendarConfirm.getEvents()[0];
    console.log(curEve.start);
    let sameStart = moment(curEve.start).isSame(moment(eventSingle.start));
    let sameEnd = moment(curEve.end).isSame(moment(eventSingle.end));
    if (sameStart == false || sameEnd == false){
        let r = confirm("The event time changed, do you want to keep the new time or revert to the original time?");
        if(r == true){
            console.log("write the new event!");

            //delete original event from user calArray & //add new event to the calArray
            for (i = 0; i < currentUser.calArray.length; i++){
                let tempEvent = JSON.parse(currentUser.calArray[i])
                console.log(tempEvent.id);
                console.log(eventSingle.id);
                if(tempEvent.id == eventSingle.id){
                    console.log(tempEvent);
                    currentUser.calArray.splice(i,1);


                    newEvent = {
                        resourceId: currentUser.appId,
                        title: curEve.title,
                        start: moment(curEve.start).format(),
                        end: moment(curEve.end).format(),
                        id: curEve.id,                              
                        backgroundColor: curEve.backgroundColor,
                        extendedProps:{
                          acceptGuest : false,
                          appId: currentUser.appId,          
                          description: curEve.extendedProps.description,
                          status : "invite",
                          auther: currentUser.name + " " + currentUser.lastName          
                        }
                    }; 
                    
                    curEve.resourceId = currentUser.appId;
                    currentUser.calArray.push(JSON.stringify(newEvent));
                    allowInit = false;
                    writeEventsP();
                    break;
                }
                
            }
            

            //delete origianl event from user calendars
            myCalendar.getEventById(eventSingle.id).remove();
            myCalendarAlt.getEventById(eventSingle.id).remove();
            // add new event to calendars
            myCalendar.addEvent(newEvent);
            myCalendarAlt.addEvent(newEvent);
            //send an update email to the invitee

            allUsersSnapShot.forEach(function(child) { 
                // console.log(child.val().appId + " : " + eventSingle.extendedProps.appId);
                let inviteeID = newEvent.extendedProps.description.split(":")[2];
                if(child.key == inviteeID){
                    userEmail = child.val().email;
                    nameTosend = child.val().name;
                    console.log(nameTosend + ' ' + child.key);
    
                    //open Text
                    let textAreaField = document.getElementById("textAreaField");
                    let eventDate = moment(eventSingle.start).format("dddd, MMMM Do YYYY, h:mm:ss a");
                
                    let mailBody = "Hello " + nameTosend + ".\n " + currentUser.name + " has changed invitation times for the event on "+ eventDate + 
                                    ". The request has been updated in your calendar";
                
                        if (textAreaField.value.length >0){
                        mailBody += "\n \n A message was sent as well: \n"+textAreaField.value;
                        textAreaField.value = "";
                        }
                    console.log(mailBody);
                    if(sendEmails == true)
                    {    Email.send({
                            Host: "smtp.ipage.com",
                            Username : "roi@roiwerner.com",
                            Password : "Roki868686",
                            To : userEmail,
                            From : "<roi@roiwerner.com>",
                            Subject : "Invitation time changed",
                            Body : mailBody,
                            }).then(
                            message => alert("mail sent successfully")
                        );
                    } 
                };
            });                        
        }
    }
    
}



function requestEvent(){
    textModalOpen = true;
    openTextModalPC();
}
  
var textModalOpen = false;

function openTextModalPC(message){
    console.log(sourceCal);
    textModalOpen = true;
    let headerString = "";
    
    var requestedEvents = calendarSingle.getEvents();    
    var requestedEve = [];
    var origianlEvent = eventSingle;
        
    if(requestedEvents.length == 1){
    requestedEve = requestedEvents[0];
        
    }
    else{
    requestedEve = requestedEvents[1];
    }
    headerString = "You are requesting an event on </br>" + moment(requestedEve.start).format('dddd') + " " + moment(requestedEve.start).format('DD.MM.YYYY') + " starting at: " + moment(requestedEve.start).format('HH:mm') + " ending at: " + moment(requestedEve.end).format('HH:mm') + "</br>From "+ eventSingle.title;
    

    document.getElementById('textAreaHeader').innerHTML = headerString;
    // var modal = document.getElementById("textArea");  
    // var span = document.getElementsByClassName("closeText")[0]; 
    modal.style.display = "block";
  
    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
        textModalOpen = false;
        modal.style.display = "none";
    }
  
    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
        // modal.style.display = "none";
        }
    }

    
    $(document).keyup(function(e) {
        console.log(textModalOpen);
        if (e.key === "Escape") { // escape key maps to keycode `27`
            if(textModalOpen == true){
                textModalOpen = false;
                modal.style.display = "none";
            }            
       }
   });
  
}
  
function clearTextPC(){  
    console.log("clearText");
    let textAreaField = document.getElementById("textAreaField");
    console.log(textAreaField.value);
    textAreaField.value = "";
}

function deleteEvent(){
    console.log("Delete event: ",eventSingle)
    
    if (eventSingle.extendedProps.description.split("/")[0] == "invite"){
        console.log("delete invite event");        
        let answer= confirm("This event is waiting confirmation, if you delete it, the invitation will be deleted.");      
        if (answer ==false){ //cancel deletion
            return;
        }
                        
        //get the request so i have the events ids:
        // requestKey = eventSingle.extendedProps.description.split(":")[0];
        // console.log(requestKey);
        
        myCalendar.getEventById(eventSingle.id).remove();
        myCalendarAlt.getEventById(eventSingle.id).remove();

        for(e in currentUser.calArray){
            let tempvar = JSON.parse(currentUser.calArray[e]);
            console.log(tempvar.id + " :: " + eventSingle.id );
            if (tempvar.id == eventSingle.id){
                console.log("event found at index: " + e);
                currentUser.calArray.splice(e ,1); 
                allowInit = false;
                firebase.database().ref('/users/' + currentUser.luid).update({
                    calArray: currentUser.calArray
                });   
                break;                
            }
        }

         
        
        allUsersSnapShot.forEach(function(child) { 
            // console.log(child.val().appId + " : " + eventSingle.extendedProps.appId);
            let inviteeID = eventSingle.extendedProps.description.split(":")[2];
            if(child.key == inviteeID){
                userEmail = child.val().email;
                nameTosend = child.val().name;
                console.log(nameTosend + ' ' + child.key);

                //open Text
                let textAreaField = document.getElementById("textAreaField");
                let eventDate = moment(eventSingle.start).format("dddd, MMMM Do YYYY, h:mm:ss a");
            
                let mailBody = "Hello " + nameTosend + ".\n " + currentUser.name + " has deleted the invite for the event on "+ eventDate + 
                                ". The request has been updated in your calendar";
            
                    if (textAreaField.value.length >0){
                    mailBody += "\n \n A message was sent as well: \n"+textAreaField.value;
                    textAreaField.value = "";
                    }
                if(sendEmails == true)
                {   
                    Email.send({
                        Host: "smtp.ipage.com",
                        Username : "roi@roiwerner.com",
                        Password : "Roki868686",
                        To : userEmail,
                        From : "<roi@roiwerner.com>",
                        Subject : "Invitation deleted",
                        Body : mailBody,
                        }).then(
                        message => alert("mail sent successfully")
                    );
                } 
            };
        });
    }   
    else if(eventSingle.extendedProps.description.split("/")[0] === "waiting"){
        console.log("delete waiting event");
        let answer= confirm("This event is waiting confirmation, if you delete it, the request will be deleted.");
      
        if (answer ==false){ //cancel deletion
            return;
        }
        //get the request so i have the events ids:
        requestKey = eventSingle.extendedProps.description.split(":")[0];
        console.log(requestKey);
        firebase.database().ref('/requests/'+requestKey).once('value').then(function(snapshot){            
            let  originaleventToDelete = JSON.parse(snapshot.val().origEvent);            
            let requestEventToDelete = JSON.parse(snapshot.val().requestedEvent);            

            //-delete the request
            firebase.database().ref('/requests/'+requestKey).remove();

            //-delete the request from the asking user
            for(e in currentUser.calArray){
                let tempvar = JSON.parse(currentUser.calArray[e]);
                // console.log(tempvar.id);
                if (tempvar.id == eventSingle.id){
                    console.log("event found at index: " + e);
                    currentUser.calArray.splice(e ,1); 
                    allowInit = false;
                    myCalendar.getEventById(requestEventToDelete.id).remove();
                    myCalendarAlt.getEventById(requestEventToDelete.id).remove();                        
                    myCalendar.getEventById(originaleventToDelete.id).remove();
                    myCalendarAlt.getEventById(originaleventToDelete.id).remove(); 

                    break;
                    
                }
            }  
            console.log(currentUser.calArray);
            allowInit = false;
            firebase.database().ref('users/' + currentUser.luid).update(
            {        
                calArray: currentUser.calArray            
            });
                        

            //-update the event on the original side
            let creatorId = originaleventToDelete.extendedProps.appId;
            console.log(creatorId);
            allUsersSnapShot.forEach(function(child) { 
                // console.log(child.val().appId + " : " + eventSingle.extendedProps.appId);
                
                if(child.val().appId == creatorId){

                    console.log(child.key);
                    firebase.database().ref('/users/' + child.key).once('value').then(function(snapshot){
                        let originalUser = snapshot.val();
                        console.log(originalUser.calArray);
                        let localTempArray = originalUser.calArray;
                        for (e in localTempArray){
                            let element = JSON.parse(localTempArray[e]);                            
                            if (element.id == originaleventToDelete.id){
                                element.extendedProps.status = "open";
                                console.log(element);
                                localTempArray[e] = JSON.stringify(element);
                                myCalendar.addEvent(element);
                                myCalendarAlt.addEvent(element);
                                break;                               
                                
                            }
                        }
                        console.log(localTempArray);
                        //update the Firebase array of the user with the new info
                        allowInit = false;
                        firebase.database().ref('/users/'+child.key).update({
                            calArray: localTempArray
                        });
                        
                    });
                }
            
            });                          
        });  
        // writeEventsP();       
    } 

     
    else if (eventSingle.extendedProps.description.split("/")[0] == "pending"){

        let question = "This is a requested event!\nAre you sure you want to delete this event?\nIf you do, the event will be cancelled \nand a message will be sent to the other person!";
        
        
        let answer= confirm(question);
      
        if (answer ==false){ //cancel deletion
        return;
        }
        else
        {
            requestKey = eventSingle.extendedProps.description.split(":")[0];
            console.log(requestKey);
            firebase.database().ref('/requests/'+requestKey).once('value').then(function(snapshot){            
                let  originaleventToDelete = JSON.parse(snapshot.val().origEvent);            
                let requestEventToDelete = JSON.parse(snapshot.val().requestedEvent);            

                //-delete the request
                firebase.database().ref('/requests/'+requestKey).remove();
                
                //GET REQUESTOR EMAIL
                let requestorId = requestEventToDelete.extendedProps.appId;
                console.log(requestorId);
                allUsersSnapShot.forEach(function(child) { 
                    // console.log(child.val().appId + " : " + eventSingle.extendedProps.appId);
                    
                    if(child.val().appId == requestorId){
                        userEmail = child.val().email;
                        nameTosend = child.val().name;
                        console.log(nameTosend + ' ' + child.key);

                        //open Text
                        let textAreaField = document.getElementById("textAreaField");
                        let eventDate = moment(eventSingle.start).format("dddd, MMMM Do YYYY, h:mm:ss a");
                    
                        let mailBody = "Hello " + nameTosend + ".\n " + currentUser.name + " has deleted the event on "+ eventDate + 
                                        ". The request has been updated in your calendar";
                    
                            if (textAreaField.value.length >0){
                            mailBody += "\n \n A message was sent as well: \n"+textAreaField.value;
                            textAreaField.value = "";
                            }
                            // console.log(mailBody);       
                            if(sendEmails == true)
                            {    
                                Email.send({
                                    Host: "smtp.ipage.com",
                                    Username : "roi@roiwerner.com",
                                    Password : "Roki868686",
                                    To : userEmail,
                                    From : "<roi@roiwerner.com>",
                                    Subject : "Session deleted",
                                    Body : mailBody,
                                    }).then(
                                    message => alert("mail sent successfully")
                                ); 
                            }

                            var tempArray = child.val().calArray
                            console.log(tempArray);
                                
                            for (e in tempArray){
                            let element = JSON.parse(tempArray[e])
                            console.log(element.id + ":" + eventSingle.id);
                                if(element.id == eventSingle.id){
                                // IN CASE I WANT TO CHNAGE THE EVENT FOR THE REQUESTER TO FREE TIME?
                                // element.title = "Confirmed by "+currentUser.name + " " + currentUser.lastName;
                                // element.backgroundColor = "red";
                                // element.extendedProps.acceptGuest = "booked";
                                // element.extendedProps.approvedBy = currentUser.luid;
                                // tempArray[e] = JSON.stringify(element);
                                    tempArray.splice(e,1);
                                    console.log("tempArray ",tempArray);
                                    console.log(child.key);
                                    allowInit = false;
                                        firebase.database().ref('/users/' + child.key).update({
                                            calArray: tempArray
                                        });
                                    break;        
                                }      
                            }
                    }
                });

                //delete the event from currentUser
                for(e in currentUser.calArray){
                    let tempvar = JSON.parse(currentUser.calArray[e]);
                    console.log(tempvar.id + " :: " + eventSingle.id );
                    if (tempvar.id == eventSingle.id){
                        console.log("event found at index: " + e);
                        currentUser.calArray.splice(e ,1);  
                        firebase.database().ref('/users/' + currentUser.luid).update({
                            calArray: currentUser.calArray
                        });   
                        break;
                        
                    }
                }
            });
            
            // remove the event from the calendars 
            myCalendar.getEventById(eventSingle.id).remove();
            myCalendarAlt.getEventById(eventSingle.id).remove();

        } 
    
    }
     
    else if(eventSingle.extendedProps.description.split("/")[0] == "booked"){
         let requestId = eventSingle.extendedProps.description.split("/")[2];
         let approveId = eventSingle.extendedProps.description.split("/")[1];
                        
        question = "This is a confirmed event!\nAre you sure you want to delete this event?\nIf you do, the event will be cancelled \nand a message will be sent to the other person!";
        let answer= confirm(question);
        if (answer ==false){ //cancel deletion
            return;
            }
        else
        {
            if(approveId != currentUser.luid){
                console.log("I ram not the origianl side  ");              

                firebase.database().ref('/users/'+approveId).once('value').then(function(snapshot){

                    //send Email to the other side
                    userEmail = snapshot.val().email;
                    nameTosend = snapshot.val().name;
                    console.log(nameTosend + ' ' + userEmail);
                    //open Text
                    let textAreaField = document.getElementById("textAreaField");
                    let eventDate = moment(eventSingle.start).format("dddd, MMMM Do YYYY, h:mm:ss a");
                
                    let mailBody = "Hello " + nameTosend + ".\n " + currentUser.name + " has deleted the event on "+ eventDate + 
                                ". The request has been updated in your calendar";
            
                    if (textAreaField.value.length >0){
                    mailBody += "\n \n A message was sent as well: \n"+textAreaField.value;
                    textAreaField.value = "";
                    }
                    console.log(mailBody); 
                    if(sendEmails == true)
                    {    
                        Email.send({
                            Host: "smtp.ipage.com",
                            Username : "roi@roiwerner.com",
                            Password : "Roki868686",
                            To : userEmail,
                            From : "<roi@roiwerner.com>",
                            Subject : "Session deleted",
                            Body : mailBody,
                            }).then(
                                message => alert("mail sent successfully")
                        );
                    } 

                    //open the event on the other side
                    let userToFindCalArray = snapshot.val().calArray;
                    console.log(userToFindCalArray.length);
                    for (let i = 0; i < userToFindCalArray.length; i++) {
                        let eventToUpdate = JSON.parse(userToFindCalArray[i]);
                        // console.log(eventToUpdate.id);
                        // console.log(eventSingle.id);
                        if (eventToUpdate.id == eventSingle.extendedProps.description.split("/")[3]){
                            console.log("found an event to update: ",eventToUpdate);
                            eventToUpdate.title = snapshot.val().name + " " + snapshot.val().lastName;
                            eventToUpdate.extendedProps.description = "open/" + snapshot.key;                            
                           

                            //connect events
                            let eventsToDeleteArray = [];
                            for (j = 0; j < userToFindCalArray.length; j++){
                                let tempEvent = JSON.parse(userToFindCalArray[j]);
                                console.log("tempevent: ",tempEvent);
                                if(tempEvent.extendedProps.description.split("/"[0] == "open")){
                                    if (moment(tempEvent.end).isSame(moment(eventToUpdate.start))){
                                        eventToUpdate.start = tempEvent.start;
                                        // userToFindCalArray.splice(j,1);  
                                        eventsToDeleteArray.push(tempEvent.id);
                                        

                                    }
                                    if(moment(tempEvent.start).isSame(moment(eventToUpdate.end))){
                                        eventToUpdate.end = tempEvent.end;
                                        // userToFindCalArray.splice(j,1); 
                                        eventsToDeleteArray.push(tempEvent.id);
                                    }                                    
                                }                                                                
                            }
                            userToFindCalArray.splice(i,1);
                            userToFindCalArray.push(JSON.stringify(eventToUpdate));
                            
                            for (k = 0; k < eventsToDeleteArray.length; k++){
                                for (j = 0; j < userToFindCalArray.length; j++){
                                    let tempEvent = JSON.parse(userToFindCalArray[j]);
                                    if(tempEvent.id == eventsToDeleteArray[k]){
                                        userToFindCalArray.splice(j,1);
                                    }
                                                                                                
                                }
                            }
                            console.log(eventsToDeleteArray);
                            console.log(userToFindCalArray);
                            
                            // myCalendar.getEventById(eventSingle.id).remove();
                            // myCalendarAlt.getEventById(eventSingle.id).remove();
                            myCalendar.getEventById(eventToUpdate.id).remove();
                            myCalendarAlt.getEventById(eventToUpdate.id).remove();
                            myCalendarAlt.addEvent(eventToUpdate);
                            myCalendar.addEvent(eventToUpdate);
                            
                            allowInit = false;
                            firebase.database().ref('/users/'+approveId).update({
                                calArray: userToFindCalArray
                            });
                            break;
                        }
                    }                  
                });
            }
            else {
                console.log("I am the origianl side  ");                
                                
                firebase.database().ref('/users/'+requestId).once('value').then(function(snapshot){

                    //send Email to the other side
                    userEmail = snapshot.val().email;
                    nameTosend = snapshot.val().name;
                    console.log(nameTosend + ' ' + userEmail);

                    //open Text
                    let textAreaField = document.getElementById("textAreaField");
                    let eventDate = moment(eventSingle.start).format("dddd, MMMM Do YYYY, h:mm:ss a");
                
                    let mailBody = "Hello " + nameTosend + ".\n " + currentUser.name + " has deleted the event on "+ eventDate + 
                                ". The request has been updated in your calendar";
            
                    if (textAreaField.value.length >0){
                    mailBody += "\n \n A message was sent as well: \n"+textAreaField.value;
                    textAreaField.value = "";
                    }
                    console.log(mailBody);       
                    if(sendEmails == true)
                    {    
                        Email.send({
                            Host: "smtp.ipage.com",
                            Username : "roi@roiwerner.com",
                            Password : "Roki868686",
                            To : userEmail,
                            From : "<roi@roiwerner.com>",
                            Subject : "Session deleted",
                            Body : mailBody,
                        }).then(
                                message => alert("mail sent successfully")
                        ); 
                    }

                    //open the event on the cuurent side
                    let userToFindCalArray = snapshot.val().calArray;
                    console.log(userToFindCalArray);
                    for (let i = 0; i < userToFindCalArray.length; i++) {
                        let eventToUpdate = JSON.parse(userToFindCalArray[i]);
                        console.log(eventToUpdate.id);
                        console.log(eventSingle.id);
                        if (eventToUpdate.id == eventSingle.extendedProps.description.split("/")[4]){
                            console.log(eventToUpdate);
                            eventToUpdate.title = snapshot.val().name + " " + snapshot.val().lastName;
                            eventToUpdate.extendedProps.description = "open/" + snapshot.key;
                            // eventToUpdate.extendedProps.status = "open";
                            // eventToUpdate.extendedProps.approvedBy = "";
                            userToFindCalArray.splice(i,1);
                            userToFindCalArray.push(JSON.stringify(eventToUpdate));
                            console.log(userToFindCalArray);
                            allowInit = false;
                            firebase.database().ref('/users/'+requestId).update({
                                calArray : userToFindCalArray
                            });
                            // myCalendar.getEventById(eventSingle.id).remove();
                            // myCalendarAlt.getEventById(eventSingle.id).remove();
                            myCalendar.getEventById(eventToUpdate.id).remove();
                            myCalendarAlt.getEventById(eventToUpdate.id).remove();
                            myCalendarAlt.addEvent(eventToUpdate);
                            myCalendar.addEvent(eventToUpdate);
                            break;
                        }                      
                    }                    
                });
                
            }
            // else{
            //     console.log("THERE IS AN ERROR HERE");
            // }            
        }            

        //delete the event from currentUser
        for(e in currentUser.calArray){
            let tempvar = JSON.parse(currentUser.calArray[e]);
            console.log(tempvar.id + " :: " + eventSingle.id );
            if (tempvar.id == eventSingle.id){
                console.log("event found at index: " + e);
                currentUser.calArray.splice(e ,1); 
                allowInit = false;
                firebase.database().ref('/users/' + currentUser.luid).update({
                    calArray: currentUser.calArray
                });   
                break;                
            }
        }
        
        console.log("NOW DELETING EVENTS FROM CALS");
        // remove the event from the calendars 
        
    
    }

    else{
        //-delete the request from the asking user
        let answer= confirm("Are you sure you want to delete this event?");
      
        if (answer ==false){ //cancel deletion
            return;
        }
        for(e in currentUser.calArray){
            let tempvar = JSON.parse(currentUser.calArray[e]);
            // console.log(tempvar.id);
            if (tempvar.id == eventSingle.id){
                console.log("event found at index: " + e);
                currentUser.calArray.splice(e ,1); 
                allowInit = false;
                
                myCalendar.getEventById(eventSingle.id).remove();
                myCalendarAlt.getEventById(eventSingle.id).remove(); 
                
                
                break;
                
            }
        } 
        // currentUser.calArray.push(JSON.stringify(myEvent))  
        allowInit = false; 
        // let allevent = myCalendarAlt.getEvents();
        // resetCalAlt(allevent);          
        writeEventsP();
        // firebase.database().ref('users/' + currentUser.luid).update(
        //     {        
        //         calArray: currentUser.calArray            
        //     });
    }
    // }
  
    // else if(eventSingle.extendedProps.acceptGuest == "waiting"){
    //   let answer= confirm("This event is waiting confirmation, if you delete it, the request will be deleted.");
      
    //   if (answer ==false){ //cancel deletion
    //     return;
    //   }
    //   //delete the request
    //   let requestKey = eventSingle.extendedProps.description.split(":")[0];
    //   console.log(requestKey);
    //   return;
    //   firebase.database().ref('/requests/'+requestKey).remove();    
    // }
    // else{
    //   let answer= confirm("Are you sure you want to delete this event?")
    //   if (answer ==false){ //CANCEL DELETION
    //     return;
    //   }
    // }
    
     
    // console.log(currentUser.calArray);
    // allowInit = false;
    
      
      
    
    // writeEventsP();    
    
    
      
      // REMOVE THE 2 EVENTS WITH THE SAME ID BECASUE OF CONFIRMATION!
    //   var eventTodelete = myCalendar.getEventById(eventSingle.id);
    //   eventTodelete.remove();
    //   var eventTodelete1 = myCalendar.getEventById(eventSingle.id);
    //   eventTodelete1.remove();    
    //   let allevents = myCalendar.getEvents();
    //   allevents.forEach(el => { el.remove(); });            
    //   myCalendar.addEventSource(allevents);

    //   let allevents2 = myCalendarAlt.getEvents();
    //   allevents2.forEach(el => { el.remove(); });            
    //   myCalendarAlt.addEventSource(allevents2);


    //   backToCal();
}

function submitPC(){
   
    console.log("submitPC");
    if(sourceCal == "singleConfirm"){
        console.log(currentUser.luid);
        submitConfirm();
    }
    else if(sourceCal == "singleInvite"){
        submitAcceptInvite();
    }
    else{
        var modal = document.getElementById("textArea");  
        modal.style.display = "none";    
        sendRequestEvent();
    }
        
}

function closeModalPC(){
    modal.style.display = "none";
}

function sendRequestEvent(){
    console.log("request event: ",JSON.stringify( eventSingle));
    
    //check if this is my own event? is this even possible?
    if(eventSingle.extendedProps.appId == currentUser.appId){
      console.log("should go to edit");    
      editEvent();
      return;
    }
  
  
    var requestedEvents = calendarSingle.getEvents();    
    var requestedEve = [];
    var origianlEvent = eventSingle;
    
    
    // checking if the user selected a differant time than the whole time scope
    if(requestedEvents.length == 1){ //user add a new time
      requestedEve = requestedEvents[0]; //this is the original
          
    }
    else{
      requestedEve = requestedEvents[1]; //this is the new time
    }
    let UniqueKey = Math.random().toString(36).substring(2);  
    let r = Math.random().toString(36).substring(2);

    // create the new event to be put into the user calendar
    newEvent = {
        resourceId: currentUser.appId,
        title: "pending approval from: "+ requestedEve.title,
        start: moment(requestedEve.start).format(),
        end: moment(requestedEve.end).format(),
        id: r,                              
        backgroundColor: color_toBook,
        extendedProps:{
          acceptGuest : false,
          appId: currentUser.appId,          
          description: "waiting/" + origianlEvent.extendedProps.description.split("/")[1] + "/" + currentUser.luid + "/" + origianlEvent.id + "/" + r + "/" + UniqueKey,
        //   status : "waiting",
        //   auther: currentUser.name + " " + currentUser.lastName          
        }
    };        

    //add the event to both auther and me as an invisible event(or red), once it will be confirmed it, will show up.
   
    //--Get the User who created the event! this is for the other side!
    allUsersSnapShot.forEach(function(child) { 
      // console.log(child.val().appId + " : " + eventSingle.extendedProps.appId);
      
      if(child.val().appId == origianlEvent.extendedProps.appId){
        nameTosend = child.val().name;
        emailTosend = child.val().email;
        requestAppId = currentUser.appId;
        
        var tempEventsArray = child.val().calArray;
        tempEventsArray = tempEventsArray.filter(function(e){return e}); 
        
          //get the specific event for confirmation process
          for (let index = 0; index < tempEventsArray.length; index++) {
            const element = JSON.parse(tempEventsArray[index]);          
            if(element.id == origianlEvent.id){
                
                // element.extendedProps.description = UniqueKey + ":" + currentUser.appId; 
                element.title = "waiting for your approval from: " + element.title;
                element.extendedProps.description = "pending/" + origianlEvent.extendedProps.description.split("/")[1] + "/" + currentUser.luid + "/" + origianlEvent.id + "/" + r + "/" + UniqueKey;
                element.editable = false;
                // element.extendedProps.status = "pending";   
                // element.resourceId = eventSingle.getResources(),            
               
                tempEventsArray[index] = JSON.stringify(element);
                
                myCalendar.getEventById(origianlEvent.id).remove();
                myCalendarAlt.getEventById(origianlEvent.id).remove();
                myCalendar.addEvent(element);
                myCalendarAlt.addEvent(element);
                
                console.log(element);
                console.log("event found: ",element.id);
                
                origianlEvent = element;
                 
                console.log (child.key);
                // firebase.database().ref('users/' + child.key).once('value').then(function(snapp){
                //   console.log(snapp.val().calArray);
                // });
                allowInit = false;
                firebase.database().ref('users/' + child.key).update({
                  calArray: tempEventsArray
                });
                break;                                
            }        
          }      
      }                                       
    });
    
    firebase.database().ref('requests/'+UniqueKey).set(
      {       
        requestBy: currentUser.luid,      
        origEvent: JSON.stringify(origianlEvent),
        requestedEvent: JSON.stringify(newEvent),      
      }   
      ,function(error)
      {
        if (error) {
          alert (error);
        
          // The write failed...
        }
      }).then(() => 
      {  
        //send an email to the auther
        let mailBody = "Hello " + nameTosend + ".\n " + currentUser.name + " would like to book your offered session\n"+
                        "please follow this link to approve it\n"
                        + "roiwerner.com/gse5/singleEvent.html?&key="+UniqueKey;
                        // id="+eventSingle.id+"&id2="+requestEventId+"&id3="+requestAppId+"
  
          let textAreaField = document.getElementById("textAreaField");        
          if (textAreaField.value.length >0){
            mailBody += "\n \n A message was sent as well: \n"+textAreaField.value;
            textAreaField.value = "";
          }
  
          console.log(mailBody);
            if(sendEmails == true)
            {  
                Email.send({
                    Host: "smtp.ipage.com",
                    Username : "roi@roiwerner.com",
                    Password : "Roki868686",
                    To : emailTosend,
                    From : "<roi@roiwerner.com>",
                    Subject : "Session booking",
                    Body : mailBody,
                    }).then(
                    message => alert("mail sent successfully")
                );
            } 
  
      });
  
  //console.log("send to: " + emailTosend +" from: " + currentUser.email + "event id: "+eventId);
  
    
    // var tempi = requestedEve;
    // tempi.backgroundColor = color_special;    
    // tempi.title = 'pending approval';
    // console.log(tempi.title);
    // // let r = Math.random().toString(36).substring(2);
  
    // newEvent = {
    //   resourceId: currentUser.appId,
    //   title: "pending approval",
    //   start: tempi.start,
    //   end: tempi.end,
    //   id: tempi.id,                              
    //   backgroundColor: "purple",
    //   extendedProps:{
    //     acceptGuest : 'waiting',
    //     appId: currentUser.appId,
    //     auther: currentUser.name,
    //     reqKey: UniqueKey,
    //     droppable: false
    //   }
    // };
    // console.log(newEvent);
    // return;

    console.log("here I am");
    myCalendar.addEvent(newEvent); 
    myCalendarAlt.addEvent(newEvent);       
    // currentUser.calArray.push (JSON.stringify(requestedEvent[1]));
    // console.log(currentUser.calArray);
    console.log("THIS IS THE CALARRAY BEFORE ADDING:");
    console.log(currentUser.calArray);
    if(currentUser.calArray === undefined){
        currentUser.calArray = [];
      }
    
    currentUser.calArray.push(JSON.stringify(newEvent));    
          
    writeEventsP();    
        
    backToCal(); 
    
}

//---------- END BUTTONS ACTIONS -----------//

//---------- CONFIRMATION CAL -------------//

function makeCalConfirm(){
        var calendarEl = document.getElementById('calendarSingle');
        calendarConfirm = new FullCalendar.Calendar(calendarEl, {
  
              initialView: 'timeGridDay',
              allDaySlot: false, 
              selectable: true,
            //   editable: true,
            //   droppable: false, 
              eventResizableFromStart: true,
              slotDuration: ('00:15:00'),
            //   slotMinTime: moment(eventi.start).format('HH:mm:ss'),
            //   slotMaxTime: moment(eventi.end).format('HH:mm:ss'),
              // height: (window.innerHeight)/2,
              
              eventDidMount: function(arg){
                // myCalendarAlt.setOption('editable',false);
                console.log("call eventMount from confirm");
                eventMount(arg);            
            },
              eventContent: { domNodes: [] },

              eventContent: function(arg) {
                let italicEl = document.createElement('p')                  
                italicEl.innerHTML = moment(arg.event.start).format('HH:mm')+" - " + moment(arg.event.end).format('HH:mm') + '<br/>' + arg.event.title;
                let arrayOfDomNodes = [ italicEl ]
                return { domNodes: arrayOfDomNodes }
              },
                  
              events: [
                ]  
                               
          });                           
          var timeSlotArray =document.getElementsByClassName("fc-event-draggable");
          var timeSlot = timeSlotArray[timeSlotArray.length-1];
}

var eventi = []; //originaleventToConfirm
var reqEvent=[];    // requestEventToConfirm

var event1 = [];
var event2 = [];
var event3 = [];
var eventi = [];
var reqEvent=[];
var requestKey = "";
calendarConfirm = FullCalendar;

function loadEventToConfirm(){
    console.log("loading event to confirm: ",eventSingle);
    sourceCal = "singleConfirm";


    document.getElementById("toggleSelf").style.display = "none";
    document.getElementById("toggleDisplay").style.display = "none";
    document.getElementById("toggleResources").style.display = "none";
    document.getElementById('AddEventManually').style.display = "none";
    document.getElementById('openEventsToConfirm').style.display = "none";
    document.getElementById('btn_day').disabled = true;
    document.getElementById('btn_week').disabled = true;
    document.getElementById('btn_month').disabled = true;
    document.getElementById('label_AG_singlePage').style.display = "none";
    document.getElementById('acceptGuest_singlePage').style.display = "none"; 


    
    $(document).keyup(function(e) {
        if (e.key === "Escape") { // escape key maps to keycode `27`
            if (textModalOpen == false){
                backToCal()
            }
        }
    });

    requestKey = eventSingle.extendedProps.description.split("/")[5];
    console.log("loadEventToConfirm" ,requestKey);
    firebase.database().ref('/requests/'+requestKey).once('value').then(function(snapshot){            
        // let  originaleventToDelete = JSON.parse(snapshot.val().origEvent);            
        // let requestEventToDelete = JSON.parse(snapshot.val().requestedEvent); 
        eventi = JSON.parse(snapshot.val().origEvent);
        console.log(eventi.extendedProps.acceptGuest);

        reqEvent = JSON.parse(snapshot.val().requestedEvent);
        console.log(reqEvent);

        requestingUserId = snapshot.val().requestBy;
        

        makeCalConfirm();
        calendarConfirm.setOption("slotMaxTime", moment(eventi.end).format('HH:mm'));
        calendarConfirm.setOption("slotMinTime", moment(eventi.start).format('HH:mm'));

        document.getElementById("calendar").style.visibility = "hidden"; 
        document.getElementById("calendarAlt").style.visibility = "hidden";
        document.getElementById("calendarSingle").style.visibility = "visible";

        document.getElementById('deleteEvent').style.display = "inline-block";
        document.getElementById('label_AG_singlePage').style.display = "none";
        document.getElementById('acceptGuest_singlePage').style.display = "none";
        document.getElementById('AddEventManually').style.display = "none";
        document.getElementById('label_AG').style.display = "none";
        document.getElementById('acceptGuest_default').style.display = "none";
        document.getElementById('trimB').style.display = ""; 
        document.getElementById('confirmB').style.display = ""; 
        document.getElementById('declineB').style.display = "";
        document.getElementById("backToCal").style.display = "";

        
        // calendarConfirm.addEvent(eventi);
        // calendarConfirm.addEvent(reqEvent);
        

        let myself = currentUser.name + " " + currentUser.lastName;
        console.log(myself);
        allUsersSnapShot.forEach(function(child){

            if (child.key == reqEvent.extendedProps.description.split("/")[2]){
                autherName = child.val().name + " " + child.val().lastName;
            }
        });
        let bookedTitled = "requested by: " + autherName;
        console.log(bookedTitled);
        console.log(eventi.start + " " + reqEvent.start);
        console.log(eventi.end + " " + reqEvent.end);
        if(moment(eventi.start).isSame(moment(reqEvent.start)) && moment(eventi.end).isSame(moment(reqEvent.end))){
            console.log("same time");
            event1= {resourceId:currentUser.appId, id:1 , title: bookedTitled, start: eventi.start, end: eventi.end, backgroundColor: 'red',extendedProps:{
                acceptGuest : eventi.extendedProps.acceptGuest,
                appId: currentUser.appId,
                description: eventi.extendedProps.description,            
                },
            };
            
            calendarConfirm.addEvent(event1);
            ccase = 1;
        }
        else if(moment(reqEvent.start).isAfter(moment(eventi.start)) && moment(eventi.end).isSame(moment(reqEvent.end))){
            console.log("start later");
            event1= {resourceId:currentUser.appId, id:1 , title: myself, start: eventi.start, end: reqEvent.start, backgroundColor: color_normal_me, extendedProps:{
                acceptGuest : eventi.extendedProps.acceptGuest,
                appId: currentUser.appId,              
                description: 'open/' + currentUser.luid            
              },};         
              event2= {resourceId:currentUser.appId, id:2 , title: bookedTitled, start: reqEvent.start, end: eventi.end, backgroundColor: 'red',extendedProps:{
                acceptGuest : eventi.extendedProps.acceptGuest,
                appId: currentUser.appId,
                description: eventi.extendedProps.description,             
              },};
                                  
              calendarConfirm.addEvent(event1);                    
              calendarConfirm.addEvent(event2);                                                           
              ccase = 2;
        }
        else if(moment(reqEvent.start).isAfter(moment(eventi.start)) && moment(reqEvent.end).isBefore(moment(eventi.end))){
            console.log("start later end before");
            const tempEvent = eventi;
    
            event1= {resourceId:currentUser.appId, id:1 , title: myself, start: eventi.start, end: reqEvent.start, backgroundColor: color_normal_me, extendedProps:{
              acceptGuest : eventi.extendedProps.acceptGuest,
              appId: currentUser.appId,
              auther: currentUser.name + " " +currentUser.lastName,
              description: 'open/' + currentUser.luid
            //   droppable: false
            },};
            event2= {resourceId:currentUser.appId, id:2 , title: bookedTitled, start: reqEvent.start, end: reqEvent.end,backgroundColor: 'red',extendedProps:{
              acceptGuest : eventi.extendedProps.acceptGuest,
              appId: currentUser.appId,                            
              description: eventi.extendedProps.description,
            },};
            event3= {resourceId:currentUser.appId, id:3 , title: myself, start: reqEvent.end, end: eventi.end, backgroundColor: color_normal_me, extendedProps:{
              acceptGuest : eventi.extendedProps.acceptGuest,
              appId: currentUser.appId,
              auther: currentUser.name + " " +currentUser.lastName,
              description: 'open/' + currentUser.luid
            },};
                                
            calendarConfirm.addEvent(event1);                    
            calendarConfirm.addEvent(event2);                                                           
            calendarConfirm.addEvent(event3);
            ccase =3;
        }
        else if(moment(eventi.start).isSame(moment(reqEvent.start)) && moment(reqEvent.end).isBefore(moment(eventi.end))){
            console.log("start same end before");
            event1= {resourceId:currentUser.appId, id:1 , title: bookedTitled, start: eventi.start, end: reqEvent.end, backgroundColor: 'red',extendedProps:{
              acceptGuest : eventi.extendedProps.acceptGuest,
              appId: currentUser.appId,              
              description: eventi.extendedProps.description,
            //   droppable: false
            },};
            event2= {resourceId:currentUser.appId, id:2 , title: myself, start: reqEvent.end, end: eventi.end,backgroundColor: color_normal_me, extendedProps:{
              acceptGuest : eventi.extendedProps.acceptGuest,
              appId: currentUser.appId,
              description: 'open/' + currentUser.luid      
            //   droppable: false
            },};
                                
            calendarConfirm.addEvent(event1);                    
            calendarConfirm.addEvent(event2);                     
            ccase =4;

        }
        // if (eventi.start == reqEvent.start && eventi.end == reqEvent.end){
        //     console.log("same time");
        //     event1= {resourceId:currentUser.appId, id:1 , title: bookedTitled, start: eventi.start, end: eventi.end, backgroundColor: 'red',extendedProps:{
        //         acceptGuest : eventi.extendedProps.acceptGuest,
        //         appId: currentUser.appId,
        //         description: eventi.extendedProps.description,            
        //         },
        //     };
            
        //     calendarConfirm.addEvent(event1);
        //     ccase = 1;
            
        //   }
        //   else if (eventi.start < reqEvent.start && eventi.end == reqEvent.end){
        //     console.log("start later");
    
        //     event1= {resourceId:currentUser.appId, id:1 , title: myself, start: eventi.start, end: reqEvent.start, backgroundColor: color_normal_me, extendedProps:{
        //       acceptGuest : eventi.extendedProps.acceptGuest,
        //       appId: currentUser.appId,              
        //       description: 'open/' + currentUser.luid            
        //     },};         
        //     event2= {resourceId:currentUser.appId, id:2 , title: bookedTitled, start: reqEvent.start, end: eventi.end, backgroundColor: 'red',extendedProps:{
        //       acceptGuest : eventi.extendedProps.acceptGuest,
        //       appId: currentUser.appId,
        //       description: eventi.extendedProps.description,             
        //     },};
                                
        //     calendarConfirm.addEvent(event1);                    
        //     calendarConfirm.addEvent(event2);                                                           
        //     ccase = 2;
            
        //   }
        //   else if (eventi.start < reqEvent.start && eventi.end > reqEvent.end){
        //     console.log("start later end before");
        //     const tempEvent = eventi;
    
        //     event1= {resourceId:currentUser.appId, id:1 , title: myself, start: eventi.start, end: reqEvent.start, backgroundColor: color_normal_me, extendedProps:{
        //       acceptGuest : eventi.extendedProps.acceptGuest,
        //       appId: currentUser.appId,
        //       auther: currentUser.name + " " +currentUser.lastName,
        //       description: 'open/' + currentUser.luid
        //     //   droppable: false
        //     },};
        //     event2= {resourceId:currentUser.appId, id:2 , title: bookedTitled, start: reqEvent.start, end: reqEvent.end,backgroundColor: 'red',extendedProps:{
        //       acceptGuest : eventi.extendedProps.acceptGuest,
        //       appId: currentUser.appId,                            
        //       description: eventi.extendedProps.description,
        //     },};
        //     event3= {resourceId:currentUser.appId, id:3 , title: myself, start: reqEvent.end, end: eventi.end, backgroundColor: color_normal_me, extendedProps:{
        //       acceptGuest : eventi.extendedProps.acceptGuest,
        //       appId: currentUser.appId,
        //       auther: currentUser.name + " " +currentUser.lastName,
        //       description: 'open/' + currentUser.luid
        //     },};
                                
        //     calendarConfirm.addEvent(event1);                    
        //     calendarConfirm.addEvent(event2);                                                           
        //     calendarConfirm.addEvent(event3);
        //     ccase =3;
    
            
        //   }
        //   else if (eventi.start == reqEvent.start && eventi.end > reqEvent.end){
        //     console.log("start same end before");
        //     event1= {resourceId:currentUser.appId, id:1 , title: bookedTitled, start: eventi.start, end: reqEvent.end, backgroundColor: 'red',extendedProps:{
        //       acceptGuest : eventi.extendedProps.acceptGuest,
        //       appId: currentUser.appId,              
        //       description: eventi.extendedProps.description,
        //     //   droppable: false
        //     },};
        //     event2= {resourceId:currentUser.appId, id:2 , title: myself, start: reqEvent.end, end: eventi.end,backgroundColor: color_normal_me, extendedProps:{
        //       acceptGuest : eventi.extendedProps.acceptGuest,
        //       appId: currentUser.appId,
        //       description: 'open'      
        //     //   droppable: false
        //     },};
                                
        //     calendarConfirm.addEvent(event1);                    
        //     calendarConfirm.addEvent(event2);                     
        //     ccase =4;
            
        //   }

        calendarConfirm.render();
        calendarConfirm.gotoDate(moment(eventSingle.start).format());
        document.getElementById('currentDate').innerHTML = calendarConfirm.view.title;
    });    
}

function loadInviteEvent(){
    console.log('loadInviteEvent: ',eventSingle.id);
    sourceCal = "singleInvite";
    
    for (var i = 0; i <eventsToConfirm.length; i++) {
        if (eventsToConfirm[i].id == eventSingle.id){
            eventSingle = eventsToConfirm[i];            
            break;
        }
    }

    eventSingle.backgroundColor = color_special;
    
    
    //change visible states of elemetns
    document.getElementById("toggleSelf").style.display = "none";
    document.getElementById("toggleDisplay").style.display = "none";
    document.getElementById("toggleResources").style.display = "none";
    document.getElementById('AddEventManually').style.display = "none";
    document.getElementById('openEventsToConfirm').style.display = "none";
    document.getElementById('btn_day').disabled = true;
    document.getElementById('btn_week').disabled = true;
    document.getElementById('btn_month').disabled = true;
    document.getElementById('acceptGuest_singlePage').style.display = "none";
    document.getElementById('label_AG_singlePage').style.display = "none"; 
    document.getElementById('label_AG').style.display = "none";
    document.getElementById('acceptGuest_default').style.display = "none";
    document.getElementById('AddEventManually').style.display = "none";
    document.getElementById("backToCal").style.display = "";
   


    
    $(document).keyup(function(e) {
        if (e.key === "Escape") { // escape key maps to keycode `27`
            if (textModalOpen == false){
                backToCal()
            }
        }
    });

               
        // let  originaleventToDelete = JSON.parse(snapshot.val().origEvent);            
        // let requestEventToDelete = JSON.parse(snapshot.val().requestedEvent); 
        eventi = eventSingle;
        console.log(eventi.extendedProps.acceptGuest);

        // reqEvent = eventSingle;
        // console.log(reqEvent);

        // requestingUserId = snapshot.val().requestBy;
        

        makeCalConfirm();
        

        document.getElementById("calendar").style.visibility = "hidden"; 
        document.getElementById("calendarAlt").style.visibility = "hidden";
        document.getElementById("calendarSingle").style.visibility = "visible";

        //The user event
        if(eventi.extendedProps.appId == currentUser.appId){
            document.getElementById('trimB').style.display = "none"; 
            document.getElementById('confirmB').style.display = "none"; 
            document.getElementById('declineB').style.display = "none";
            document.getElementById('deleteEvent').style.display = "inline-block";
            calendarConfirm.setOption("scrollTime", moment(eventSingle.start).format('HH:mm:ss'));
            

        }
        // the side who is invited
        else{
            calendarConfirm.setOption("slotMaxTime", moment(eventi.end).format('HH:mm'));
            calendarConfirm.setOption("slotMinTime", moment(eventi.start).format('HH:mm'));
            // calendarConfirm.setOption("editable",false); // NOT working :()
            document.getElementById('trimB').style.display = ""; 
            document.getElementById('trimB').innerText = "Edit invitation time"
            document.getElementById('confirmB').style.display = ""; 
            document.getElementById('confirmB').innerText = "Accept invitation"
            document.getElementById('declineB').style.display = "";
        }
        
        
        
        
        console.log(eventi);
        console.log(eventi.backgroundColor);

        
        calendarConfirm.addEvent(eventi);
        // calendarConfirm.addEvent(reqEvent);
        calendarConfirm.render();
        calendarConfirm.gotoDate(moment(eventi.start).format()); 
        calendarConfirm.scrollTime = moment(eventi.start).format();
        calendarConfirm.setOption("scrollTime", moment(eventSingle.start).format('HH:mm')); 
        document.getElementById('currentDate').innerHTML = calendarConfirm.view.title;       
        return;

        let myself = currentUser.name + " " + currentUser.lastName;
        console.log(myself);
        let bookedTitled = "requested by: " + reqEvent.extendedProps.auther;
        console.log(bookedTitled);

        if (eventi.start == reqEvent.start && eventi.end == reqEvent.end){
            console.log("same time");
            event1= {resourceId:currentUser.appId, id:1 , title: bookedTitled, start: eventi.start, end: eventi.end, backgroundColor: 'red',extendedProps:{
              acceptGuest : eventi.extendedProps.acceptGuest,
              appId: currentUser.appId,
              auther: currentUser.name + " " +currentUser.lastName,
              requestby: requestingUserId,
              status: 'booked'
    
            //   droppable: false
            },};
            
            calendarConfirm.addEvent(event1);
            ccase = 1;
            
          }
          else if (eventi.start < reqEvent.start && eventi.end == reqEvent.end){
            console.log("start later");
    
            event1= {resourceId:currentUser.appId, id:1 , title: myself, start: eventi.start, end: reqEvent.start, backgroundColor: color_normal_me, extendedProps:{
              acceptGuest : eventi.extendedProps.acceptGuest,
              appId: currentUser.appId,
              auther: currentUser.name,
              status: 'open'
            //   droppable: false
            },
          
          };
            event2= {resourceId:currentUser.appId, id:2 , title: bookedTitled, start: reqEvent.start, end: eventi.end, backgroundColor: 'red',extendedProps:{
              acceptGuest : eventi.extendedProps.acceptGuest,
              appId: currentUser.appId,
              auther: currentUser.name + " " +currentUser.lastName ,
              requestby: requestingUserId,
              status: 'booked'
            //   droppable: false
            },};
                                
            calendarConfirm.addEvent(event1);                    
            calendarConfirm.addEvent(event2);                                                           
            ccase = 2;
            
          }
          else if (eventi.start < reqEvent.start && eventi.end > reqEvent.end){
            console.log("start later end before");
            const tempEvent = eventi;
    
            event1= {resourceId:currentUser.appId, id:1 , title: myself, start: eventi.start, end: reqEvent.start, backgroundColor: color_normal_me, extendedProps:{
              acceptGuest : eventi.extendedProps.acceptGuest,
              appId: currentUser.appId,
              auther: currentUser.name + " " +currentUser.lastName,
              status: 'open'
            //   droppable: false
            },};
            event2= {resourceId:currentUser.appId, id:2 , title: bookedTitled, start: reqEvent.start, end: reqEvent.end,backgroundColor: 'red',extendedProps:{
              acceptGuest : eventi.extendedProps.acceptGuest,
              appId: currentUser.appId,
              auther: currentUser.name + " " +currentUser.lastName,
              requestby: requestingUserId,
              status: 'booked'
            //   droppable: false
            },};
            event3= {resourceId:currentUser.appId, id:3 , title: myself, start: reqEvent.end, end: eventi.end, backgroundColor: color_normal_me, extendedProps:{
              acceptGuest : eventi.extendedProps.acceptGuest,
              appId: currentUser.appId,
              auther: currentUser.name + " " +currentUser.lastName,
              status: 'open'
            //   droppable: false
            },};
                                
            calendarConfirm.addEvent(event1);                    
            calendarConfirm.addEvent(event2);                                                           
            calendarConfirm.addEvent(event3);
            ccase =3;
    
            
          }
          else if (eventi.start == reqEvent.start && eventi.end > reqEvent.end){
            console.log("start same end before");
            event1= {resourceId:currentUser.appId, id:1 , title: bookedTitled, start: eventi.start, end: reqEvent.end, backgroundColor: 'red',extendedProps:{
              acceptGuest : eventi.extendedProps.acceptGuest,
              appId: currentUser.appId,
              auther: currentUser.name + " " + currentUser.lastName,
              requestby: requestingUserId,
              status: 'booked'
            //   droppable: false
            },};
            event2= {resourceId:currentUser.appId, id:2 , title: myself, start: reqEvent.end, end: eventi.end,backgroundColor: color_normal_me, extendedProps:{
              acceptGuest : eventi.extendedProps.acceptGuest,
              appId: currentUser.appId,
              auther: currentUser.name + " " + currentUser.lastName,  
              status: 'open'      
            //   droppable: false
            },};
                                
            calendarConfirm.addEvent(event1);                    
            calendarConfirm.addEvent(event2);                     
            ccase =4;
            
          }

               
}

var confirmed = true;
var requestingUserId = "";

function confirmEvent(){
  console.log("confirm");
  confirmed = true;
  //open Text
  openTextModal();
}




function sendConfirmation(){
  console.log("sendConfirmation ", requestKey);
  

  //get requesting user email
  firebase.database().ref('/users/'+requestingUserId).once('value').then(function(snapshot){
    
    userEmail = snapshot.val().email;
    nameTosend = snapshot.val().name;

    //open Text
    let textAreaField = document.getElementById("textAreaField");

    let mailBody = "Hello " + nameTosend + ".\n " + currentUser.name + " approved your session request\n"+
                    "The request has been updated in your calendar";

    if (textAreaField.value.length >0){
      mailBody += "\n \n A message was sent as well: \n"+textAreaField.value;
      textAreaField.value = "";
    }
    console.log(mailBody);  
    if(sendEmails == true)     
    {    
        Email.send({
            Host: "smtp.ipage.com",
            Username : "roi@roiwerner.com",
            Password : "Roki868686",
            To : userEmail,
            From : "<roi@roiwerner.com>",
            Subject : "Session request approved",
            Body : mailBody,
            }).then(
            message => alert("mail sent successfully")
        );
    } 

    //--update the reqested event on the other side
    
    var tempArray = snapshot.val().calArray
    console.log(tempArray);
    console.log(eventi.id);
    console.log("requested id: ",reqEvent.id +" original id: ",eventi.id);


    // let r = Math.random().toString(36).substring(2);
    for (e in tempArray){
      let element = JSON.parse(tempArray[e])
      
      if(element.id == reqEvent.id){
        console.log("found match: ", element.id + ":" + reqEvent.id);
        element.resourceId = element.extendedProps.appId;
        element.title = "Confirmed by "+currentUser.name + " " + currentUser.lastName; 
        // let newDescription =        
        // element.extendedProps.status = "booked";
        element.extendedProps.description = "booked/"+ element.extendedProps.description.split("/")[1] + "/" + element.extendedProps.description.split("/")[2] + "/" + eventi.id + "/" + reqEvent.id;
        // element.extendedProps.approvedBy = currentUser.luid;
        tempArray[e] = JSON.stringify(element);
        console.log("tempArray ",tempArray[e]);
        console.log(requestingUserId);
        firebase.database().ref('/users/'+requestingUserId).update({
          calArray: tempArray
        });
        break;        
      }      
    }
    // return;
    //--update the event on the currentUser based on the split choice
    for (var i = 0; i <eventsToConfirm.length; i++) {
        if (eventsToConfirm[i].id == eventi.id){
            eventsToConfirm.splice(i,1);
            break;
        }
    }
    console.log('call buildTippyEvents');
    buildTippyEvents();
    
    console.log(currentUser.luid);
    var tempUserArray = [];

    firebase.database().ref('/users/'+currentUser.luid).once('value').then(function(snap){
      tempUserArray = snap.val().calArray;

      for (e in tempUserArray){
        let element = JSON.parse(tempUserArray[e]);
        console.log(element.id + " " + eventi.id);
        
        if (element.id == eventi.id){
            myCalendar.getEventById(eventi.id).remove();
            myCalendarAlt.getEventById(eventi.id).remove();
          
          console.log("Element to replace found! ",element);
          tempUserArray.splice(e,1);        
          
          if (event1Trimmed == false & event1.length != 0){ 
            console.log("event 1 found");
            // event1.id = eventi.id; 
            if(event1.extendedProps.description.split("/")[0] == "pending"){
              event1.id = eventi.id;
              event1.extendedProps.description = "booked/"+ element.extendedProps.description.split("/")[1] + "/" + element.extendedProps.description.split("/")[2] + "/" + eventi.id + "/" + reqEvent.id;
            }                    
            tempUserArray.push(JSON.stringify(event1));
            myCalendarAlt.addEvent(event1);
            myCalendar.addEvent(event1);
          }
          if (event2Trimmed == false & event2.length != 0){
            console.log("event 2 found");
            event2.id = Math.random().toString(36).substring(2); 
            if(event2.extendedProps.description.split("/")[0] == "pending"){
              event2.id = eventi.id;
              event2.extendedProps.description = "booked/"+ element.extendedProps.description.split("/")[1] + "/" + element.extendedProps.description.split("/")[2] + "/" + eventi.id + "/" + reqEvent.id;
            } 
            tempUserArray.push(JSON.stringify(event2));
            myCalendarAlt.addEvent(event2);
            myCalendar.addEvent(event2);
          }
          if (event3Trimmed == false & event3.length != 0){
            console.log("event 3 found");
            event3.id = Math.random().toString(36).substring(2); 
            if(event3.extendedProps.description.split("/")[0] == "pending"){
              event3.id = eventi.id;
              event3.extendedProps.description = "booked/"+ element.extendedProps.description.split("/")[1] + "/" + element.extendedProps.description.split("/")[2] +  "/" + eventi.id + "/" + reqEvent.id;
            } 
            tempUserArray.push(JSON.stringify(event3));
            myCalendarAlt.addEvent(event3);
            myCalendar.addEvent(event3);
          } 
          console.log("tempUserArray ",tempUserArray);  
          
          // -- update the current user in firebase

          

          currentUser.calArray = tempUserArray;
          firebase.database().ref('/users/'+currentUser.luid).update({
            calArray: tempUserArray
          },function(error, committed, snapshot) {
            if (error) {
              console.error(error);
            } else {
              //delete the request from 'requests'
              firebase. database().ref('/requests/'+requestKey).remove(); 
              console.log("tempUserArray ",tempUserArray); 
              // tempUserArray = currentUser.calArray;
              
              //go back to main window
                // backToCal();
            }
            
          });
          break;          
        }      
      }
      
    });
    
  });  
  backToCal();
}

function sendAcceptInvite(){
  console.log("sendAcceptInvite", eventSingle.extendedProps.appId);
  
    
  //get original user email
  
    allUsersSnapShot.forEach(function(snapshot){       
        if (snapshot.val().appId == eventSingle.extendedProps.appId){ 
            console.log("found user here",snapshot.val().name + "  " + snapshot.val().appId);
            userEmail = snapshot.val().email;
            nameTosend = snapshot.val().name;
            requestingUserId =  snapshot.key;
        
    
            //open Text
            let textAreaField = document.getElementById("textAreaField");

            let mailBody = "Hello " + nameTosend + ".\n " + currentUser.name + " accepted your invitation request\n"+
                            "The request has been updated in your calendar";

            if (textAreaField.value.length >0){
            mailBody += "\n \n A message was sent as well: \n"+textAreaField.value;
            textAreaField.value = "";
            }
            console.log(mailBody); 
            if(sendEmails == true)      
            {    
                Email.send({
                    Host: "smtp.ipage.com",
                    Username : "roi@roiwerner.com",
                    Password : "Roki868686",
                    To : userEmail,
                    From : "<roi@roiwerner.com>",
                    Subject : "Invitattion accepted",
                    Body : mailBody,
                    }).then(
                    message => alert("mail sent successfully")
                );
            } 

            //--update the reqested event on the origianl side
    
            var tempArray = snapshot.val().calArray
            // console.log(tempArray);
            
            let r = Math.random().toString(36).substring(2);
            for (e in tempArray){
            let element = JSON.parse(tempArray[e])
            console.log(element.id + ":" + eventSingle.id);
                if(element.id == eventSingle.id){
                    element.resourceId = eventSingle.extendedProps.appId;
                    element.title = "Accecpted by "+currentUser.name + " " + currentUser.lastName;        
                    // element.extendedProps.status = "booked";
                    element.extendedProps.description = "booked/" + eventSingle.extendedProps.description.split("/")[1] + "/" + currentUser.luid + "/" + eventSingle.id + "/" + r; //send the event id that current user will have
                    // element.extendedProps.approvedBy = currentUser.luid;
                    tempArray[e] = JSON.stringify(element);
                    console.log("tempArray ",tempArray);
                    
                    allowInit = false;
                    firebase.database().ref('/users/'+requestingUserId).update({
                        calArray: tempArray
                    });
                    break;        
                }      
            }
        
        //--update the event on the currentUser based on the split choice

            //handle events to confirm if the invitation is saved to it
            for (var i = 0; i <eventsToConfirm.length; i++) {
                if (eventsToConfirm[i].id == eventi.id){
                    eventsToConfirm.splice(i,1);
                    break;
                }
            }
            console.log('call buildTippyEvents');
            buildTippyEvents();
        
            console.log(currentUser.luid);
            var tempUserArray = [];

    // firebase.database().ref('/users/'+currentUser.luid).once('value').then(function(snap){
            newEvent = {
                resourceId: currentUser.appId,
                id: r,
                title: eventSingle.title,
                start: eventSingle.start,
                end: eventSingle.end,
                allDay: false,
                // editable: true,
                // draggable: true,
                // eventStartEditable: true,
                // droppable: true,
                
                extendedProps:{
                    description : "booked/" + eventSingle.extendedProps.description.split("/")[1] + "/" + currentUser.luid + "/" + eventSingle.id + "/" + r,                               
                    appId: currentUser.appId,                    
                    acceptGuest : false 
                }
            }

            myCalendar.getEventById(eventSingle.id).remove();
            myCalendarAlt.getEventById(eventSingle.id).remove();
            currentUser.calArray.push(JSON.stringify(newEvent));
            myCalendarAlt.addEvent(newEvent);
            myCalendar.addEvent(newEvent);

            // allowInit = false;
            writeEventsP();

            console.log('backtocal');

            
        
    //     if (element.id == eventi.id){
    //       console.log(element);
    //       tempUserArray.splice(e,1);        
          
    //       if (event1Trimmed == false & event1.length != 0){ 
    //         event1.id = Math.random().toString(36).substring(2); 
    //         if(event1.extendedProps.status == "booked"){
    //           event1.id = r;
    //           event1.extendedProps.description =reqEvent.id;
    //         }                    
    //         tempUserArray.push(JSON.stringify(event1));
    //       }
    //       if (event2Trimmed == false & event2.length != 0){
    //         event2.id = Math.random().toString(36).substring(2); 
    //         if(event2.extendedProps.status == "booked"){
    //           event2.id = r;
    //           event2.extendedProps.description =reqEvent.id;
    //         } 
    //         tempUserArray.push(JSON.stringify(event2));
    //       }
    //       if (event3Trimmed == false & event3.length != 0){
    //         event3.id = Math.random().toString(36).substring(2); 
    //         if(event3.extendedProps.status == "booked"){
    //           event3.id = r;
    //           event3.extendedProps.description =reqEvent.id;
    //         } 
    //         tempUserArray.push(JSON.stringify(event3));
    //       } 
    //       console.log("tempUserArray ",tempUserArray);  
          
    //       // -- update the current user in firebase
    //       currentUser.calArray = tempUserArray;
    //       firebase.database().ref('/users/'+currentUser.luid).update({
    //         calArray: tempUserArray
    //       },function(error, committed, snapshot) {
    //         if (error) {
    //           console.error(error);
    //         } else {
    //           //delete the request from 'requests'
    //           firebase. database().ref('/requests/'+requestKey).remove(); 
    //           console.log("tempUserArray ",tempUserArray); 
    //           // tempUserArray = currentUser.calArray;
              
    //           //go back to main window
    //             // backToCal();
    //         }
            
    //       });
    //       break;          
    //     }      
    //   }
      
    // });
        }
  });  
  backToCal();
}

function decline(){
  console.log("decline");
  confirmed = false;
  textModalOpen = true;
  openTextModal();

}
function sendDecline(){

    console.log("sendDecline");
    if(eventSingle.extendedProps.description.split("/")[0] == "invite"){

        let OriginalUser = eventSingle.extendedProps.description.split("/")[1];
        console.log(OriginalUser);
        
        
        allUsersSnapShot.forEach(function(child) 
        {
            if(child.key == OriginalUser){
                // let OriginalId = child.key                
                // var localUsersArray = allUsersSnapShot.toJSON();

                // get the original user email
                firebase.database().ref('/users/'+OriginalUser).once('value').then(function(snapshot){
                {
                    console.log("got user: "+snapshot.val().name);
                    if(snapshot.val().appId == eventSingle.extendedProps.appId){
                        console.log("found matching user to delete invite from: ",child.val().email);
                        userEmail = snapshot.val().email;
                        nameTosend = snapshot.val().name;
                                        

                            let mailBody = "Hello " + nameTosend + ".\n " + currentUser.name + " has declined your invitation\n"+
                                            "The invitation has been deleted from your calendar";
                            console.log(mailBody);

                            //open Text
                            let textAreaField = document.getElementById("textAreaField");        
                            if (textAreaField.value.length >0){
                                mailBody += "\n \n A message was sent as well: \n"+textAreaField.value;
                                textAreaField.value = "";
                            }
                            // send an email to the origianl user
                            if(sendEmails == true)
                            {    
                                Email.send({
                                    Host: "smtp.ipage.com",
                                    Username : "roi@roiwerner.com",
                                    Password : "Roki868686",
                                    To : userEmail,
                                    From : "<roi@roiwerner.com>",
                                    Subject : "Invitation declined",
                                    Body : mailBody,
                                    }).then(
                                    message => alert("mail sent successfully")
                                );
                            } 

                            // delete the event from the origianl user cal on fb
                            var tempArray = snapshot.val().calArray
                            for (e in tempArray){
                                let element = JSON.parse(tempArray[e])
                                // console.log(element);
                                if(element.id == eventSingle.id){
                                    console.log("event to delete found ", element.id + " " + snapshot.key);
                                    tempArray.splice(e ,1);
                                    console.log(tempArray);
                                    
                                    firebase.database().ref('/users/'+OriginalUser).update({
                                    calArray: tempArray
                                    });
                                    break;        
                                }      
                        

                                // delete the event from the tippy request - not implimented yet
                                for (var i = 0; i <eventsToConfirm.length; i++) {
                                    if (eventsToConfirm[i].id == eventi.id){
                                        eventsToConfirm.splice(i,1);
                                        break;
                                    }
                                }
                            }
                        }
                    }
                
                });
            }
        });

        
       
        // delete the event from the current calendar (or is it enough to delete it on fb)?
        myCalendar.getEventById(eventSingle.id).remove()
        myCalendarAlt.getEventById(eventSingle.id).remove()
        
        // // return to cal
        backToCal();
        
    }

    else{

    
    
    
        //get requesting user email
        
        firebase.database().ref('/users/'+requestingUserId).once('value').then(function(snapshot){
            console.log(requestingUserId);
            
            userEmail = snapshot.val().email;
            nameTosend = snapshot.val().name;
            console.log(userEmail);

            

            let mailBody = "Hello " + nameTosend + ".\n " + currentUser.name + " has declined your session request\n"+
                            "The request has been deleted from your calendar";
            console.log(mailBody);

            //open Text
            let textAreaField = document.getElementById("textAreaField");        
            if (textAreaField.value.length >0){
            mailBody += "\n \n A message was sent as well: \n"+textAreaField.value;
            textAreaField.value = "";
            }
            if(sendEmails == true)
            {    
                Email.send({
                    Host: "smtp.ipage.com",
                    Username : "roi@roiwerner.com",
                    Password : "Roki868686",
                    To : userEmail,
                    From : "<roi@roiwerner.com>",
                    Subject : "Session request not approved",
                    Body : mailBody,
                    }).then(
                    message => alert("mail sent successfully")
                ); 
            }

            //delete the reqested event from firebase

            for (var i = 0; i <eventsToConfirm.length; i++) {
                if (eventsToConfirm[i].id == eventi.id){
                    eventsToConfirm.splice(i,1);
                    break;
                }
            }
            console.log('call buildTippyEvents');
            buildTippyEvents();

            
            var tempArray = snapshot.val().calArray
            for (e in tempArray){
            let element = JSON.parse(tempArray[e])
            // console.log(element);
            if(element.id == reqEvent.id){
                console.log("event to delete found ", element.id + " " + snapshot.key);
                tempArray.splice(e ,1);
                console.log(tempArray);
                
                firebase.database().ref('/users/'+requestingUserId).update({
                calArray: tempArray
                });
                break;        
            }      
            }

            // set the event back to open state on user cal




            console.log(currentUser.luid);
            var tempUserArray = [];

            firebase.database().ref('/users/'+currentUser.luid).once('value').then(function(snap){
            tempUserArray = snap.val().calArray;

            for (e in tempUserArray){
                let element = JSON.parse(tempUserArray[e]);
                
                if (element.id == eventi.id){
                console.log("found element: " ,element);
                tempUserArray.splice(e,1); 
                // origEvent.extendedProps.description = "";
                element.title = currentUser.name + " " + currentUser.lastName;
                element.extendedProps.description = "";
                element.extendedProps.status = "open";

                console.log(element);
                // console.log(origEvent);
                // origEvent.setExtendedProp('description', "");                
                tempUserArray.push(JSON.stringify(element));
                
                console.log("tempUserArray ",tempUserArray);  

                    myCalendar.getEventById(eventi.id).remove();
                    myCalendarAlt.getEventById(eventi.id).remove();
                    myCalendarAlt.addEvent(element);
                    myCalendar.addEvent(element);
                
                // -- update the current user in firebase
                firebase.database().ref('/users/'+currentUser.luid).update({
                    calArray: tempUserArray
                },function(error, committed, snapshot) {
                    if (error) {
                    console.error(error);
                    } 
                    
                });
                break;          
                }      
            }
            
            });

            //delete the request from 'requests'
            firebase.database().ref('/requests/'+requestKey).remove();

        });
        backToCal();
    }
//   window.location.href = "../gse5/publicCalendar.html";

}
var isTrimmed = false;
var event1Trimmed = false;
var event2Trimmed = false;
var event3Trimmed = false;

function trimEvent(){
  isTrimmed = true;
  console.log("trim " ,ccase);
  let trimB = document.getElementById('trimB');
  trimB.innerHTML = "Undo trim";
  trimB.setAttribute('onclick', 'undoTrim()');

  if(ccase == 0){

  }
  else if(ccase == 1){ //same time
    // eventt1.remove();
    // event1="";

  }
  else if(ccase ==2){ //start later
    var eventTodelete = calendarConfirm.getEventById('1');
    eventTodelete.remove();
    event1Trimmed = true;
    // event1=[];
  }
  else if(ccase ==3){ //start later end early
    
    var eventTodelete = calendarConfirm.getEventById('1');
    eventTodelete.remove();
    var eventTodelete = calendarConfirm.getEventById('3');
    eventTodelete.remove();
    // event1 = [];
    // event3 = [];
    event1Trimmed = true;
    event3Trimmed = true;

  }
  else{ //end early
    var eventTodelete = calendarConfirm.getEventById('2');
    eventTodelete.remove();
    event2Trimmed = true;
    // event2=[];

  }
}

function undoTrim(){
  isTrimmed = false;
  event1Trimmed = false;
  event2Trimmed = false;
  event3Trimmed = false;

  let trimB = document.getElementById('trimB');
  trimB.innerHTML = "Trim";
  trimB.setAttribute('onclick', 'trimEvent()');
  if(ccase == 0){

  }
  else if(ccase == 1){ //same time
    // eventt1.remove();
    // event1="";

  }
  else if(ccase ==2){ //start later
    // var eventTodelete = calendarConfirm.getEventById('1');
    // eventTodelete.remove();
    // event1=[];
    calendarConfirm.addEvent(event1);
  }
  else if(ccase ==3){ //start later end early
    
    // var eventTodelete = calendar.getEventById('1');
    // eventTodelete.remove();
    // var eventTodelete = calendar.getEventById('3');
    // eventTodelete.remove();
    // event1 = [];
    // event3 = [];

    calendarConfirm.addEvent(event1);
    calendarConfirm.addEvent(event3);

  }
  else{ //end early
    // var eventTodelete = calendarConfirm.getEventById('2');
    // eventTodelete.remove();
    // event2=[];
    calendarConfirm.addEvent(event2);

  }
}

function cancel(){
 let r =  confirm ("Cacnel - you will be redirected to the calendar and can choose to confirm at another time"); 
  if (r == true){
      backToCal();
    // window.location.href = "../gse5/publicCalendar.html";
  }
}

 

function openTextModal(message){
    // console.log(typeof(message),message);
    textModalOpen = true; 

    var requestedEvents = calendarConfirm.getEvents();    
    var requestedEve = [];
    var origianlEvent = eventSingle;
    console.log(requestedEvents);
        
    if(requestedEvents.length == 1){
    requestedEve = requestedEvents[0];
        
    }
    else{
    requestedEve = requestedEvents[1];
    }
    console.log(requestedEve.id);
    allUsersSnapShot.forEach(function(child){
        if (child.key == requestedEve.extendedProps.description.split("/")[1]){
            autherName = child.val().name + " " + child.val().lastName;
        }
    });
    let headerString = "You are confirming an event on " + moment(requestedEve.start).format('dddd') + " " + moment(requestedEve.start).format('DD.MM.YYYY') + " starting at: " + moment(requestedEve.start).format('HH:mm') + " ending at: " + moment(requestedEve.end).format('HH:mm') + "\nWith "+ autherName;
    document.getElementById('btn_TextModalSubmit').innerText = "Confirm";

    if(requestedEve.extendedProps.description.split("/")[0] == "invite"){
        headerString = "You are accepting an invitation for an event on</br> " + moment(requestedEve.start).format('dddd') + " " + moment(requestedEve.start).format('DD.MM.YYYY') + " starting at: " + moment(requestedEve.start).format('HH:mm') + " ending at: " + moment(requestedEve.end).format('HH:mm') + "<br/>From "+ autherName;
        document.getElementById('btn_TextModalSubmit').innerText = "Accept";
    }

    if(confirmed ==  false){
        headerString = "You are declining an event on " + moment(requestedEve.start).format('dddd') + " " + moment(requestedEve.start).format('DD.MM.YYYY') + " starting at: " + moment(requestedEve.start).format('HH:mm') + " ending at: " + moment(requestedEve.end).format('HH:mm') + "\n Requested by: "+ autherName;        
    }

    document.getElementById('textAreaHeader').innerHTML = headerString;

    
    modal.style.display = "block";
  
    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
        textModalOpen = false;
        modal.style.display = "none";
    }
  
    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            // modal.style.display = "none";
        }
    }
    $(document).keyup(function(e) {
        console.log(textModalOpen);
        if(textModalOpen == true){
            textModalOpen = false;
            modal.style.display = "none";
        } 
   });
  
}
  
  var textTosend = "";
function submitConfirm(){
     
    console.log("submitConfirm");
    var modal = document.getElementById("textArea");  
    modal.style.display = "none";
    //the confirmed bool is checking if this is pressed on after accept or decline as they use the same text window
    if (confirmed == true){
      sendConfirmation();
    }
    else{
      sendDecline();
    }
    
}
function submitAcceptInvite(){
     
    console.log("submitConfirm");
    var modal = document.getElementById("textArea");  
    modal.style.display = "none";
    //the confirmed bool is checking if this is pressed on after accept or decline as they use the same text window
    if (confirmed == true){
      sendAcceptInvite();
    }
    else{
      sendDecline();
    }
    
}
  
function clearText(){  
console.log("clearText");
let textAreaField = document.getElementById("textAreaField");
console.log(textAreaField.value);
textAreaField.value = "";
}


function toggleToolTip(){
    console.log(allowTippy)
    // var instance = tippy(document.querySelector('button'));
    if(allowTippy == true){
        allowTippy = false;
        
    }
    else{
        allowTippy = true;
        
    }
}

function deleteEvent1(){
    console.log("delete");
}


function openEventsToConfirm(){
    console.log("openEventsToConfirm");
    console.log(eventsToConfirm);

    

    
    // instance.show();
    
}


// function toggleUserSelection(){
//     console.log('toggleUserSelection');
// }


//---------- COLORS ----------
// is seperate script colors.js



//---------- no needed???? -----------//
// function toggleEvent(){      
//     let currentAllEvents = myCalendar.getEvents();
//     for (e in currentAllEvents){
//       currentAllEvents[e].remove();
//     }
//     myCalendar.addEventSource(allEvents);
// }

  