
// const queryString = window.location.search;
// // console.log(queryString).innerHTML = "";
// if (queryString){
//   const urlParams = new URLSearchParams(queryString);
//   var product = urlParams.get('id')
// //   console.log(product);
// //   readEvents(product);

// }
var product = "";
document.addEventListener('DOMContentLoaded', function() {
    // console.log("keyUp");
//hitting enter on the password clicks the login.
    var input = document.getElementById("message")
    
    allowInit = false;
    input.addEventListener("keyup", function(event) {        
    // Number 13 is the "Enter" key on the keyboard
    if (event.keyCode === 13) {
        console.log("keyUp");
        // Cancel the default action, if needed
        event.preventDefault();
        // Trigger the button element with a click
        sendMessage()
        // document.getElementById("SubmitMessageButton").click();
    }
    });
});
// document.getElementById("name").innerHTML = queryString;
firebase.database().ref('/users/').once('value').then(function(snapshot) {
    var username = (snapshot.val()) || 'Anonymous';
    allUsersArray=[];
    allUsersSnapShot = snapshot;  
    allUsersJson = allUsersSnapShot.toJSON();
    var arrayCount =  snapshot.numChildren();
    // var allUsersArray = [];
    
    
    var tempIndex=0;
    for (i in allUsersJson) {
    //   console.log(allUsersJson[i].appId);          
      tempIndex +=1;
      allUsersArray = allUsersArray.concat(allUsersJson[i]) ;                        
    }

    findUser();
  });


  //--CHAT--
  //-- get current user
    var currentUser = JSON.parse(localStorage.getItem("currentUser"));
    myName = currentUser.name + " " + currentUser.lastName;
    
        
    //-- get the current conversation
    firebase.database().ref("messages").once("value", function (snapshot1) {
        let allMessages = snapshot1;
        allMessages.forEach(function(child) {
            if(child.val().creator == currentUser.appId || child.val().to == currentUser.appId ){
                
                if(child.val().creator == product || child.val().to == product ){
                    // console.log(child.key);
                    let currentConversation = child;
                    firebase.database().ref('messages/'+child.key).orderByChild('timestamp').once("value", function(snap){
                        snap.forEach(function(childd){
                            // console.log(childd.val().message);
                            displayMessage(childd);
                            

                        });
                    });

                    chatKey = child.key
                    firebase.database().ref('messages/'+child.key).orderByChild('timestamp').startAt(Date.now()).on('child_added', function(snapi) {
                        console.log('new record', snapi.key);
                        displayMessage(snapi);
                    });
                }
                
            }

        });
        
    });



    

  //--listen to changes
//   firebase.database().ref("messages").on("child_added", function (snapshot) {
//     // console.log("Submit 1");
    
//     if (snapshot.val().creator == currentUser.appId){
//         // console.log("I am the auther of this chat");
//         if(snapshot.val().to == product){
//             // console.log("it is with this user indeed"); 
//             // console.log(snapshot.val().status); 
//             chatKey = snapshot.key;
//             // console.log(chatKey);
//             // console.log("Submit 2");

//             firebase.database().ref("messages/"+snapshot.key).orderByChild('timestamp').on("child_added", function (snap) {
//                 if (snap.val().status == "unread"){
//                     console.log("A MESSAGE IS WAITING");
                    
//                 }
//                 // console.log(snap.key);
                
//                 // console.log("new message: " + snap.val().message);
                
//                 // console.log("Submit 3");
//                 displayMessage(snap);
    
                
//             });
                                  
//         }
//         else{
//             return;
//         }
        
//     }
//     else if (snapshot.val().to == currentUser.appId){
//         console.log("I am the receiver of this chat");
//         if(snapshot.val().creator == product){
//             chatKey = snapshot.key;
//             // console.log("I was invited by this user indeed"); 
//             // console.log(snapshot.val().status); 
//             firebase.database().ref("messages/"+snapshot.key).orderByChild('timestamp').on("child_added", function (snap) {

//                 if (snap.val().status == "unread"){
//                     console.log("A MESSAGE IS WAITING");
                    
//                 }

//                 // console.log("new message: " + snap.val().message);                
//                 displayMessage(snap);
                
//             });       
//         }
//         else{
//             return;
//         }
//     }
//     else{
//         return;
//     }
        
    
// });

function displayMessage(snapshot){
    console.log(snapshot.ref.toString());
    let str = snapshot.ref.toString();
    
    //  var new_str = str.split("com")[0];
    var new_str1 = str.split("com")[1].replace("status", "");;
    // console.log(new_str);
    console.log(new_str1);
    
    if(snapshot.val().sender === undefined){
        
    }
    else
    {

        // firebase.database().ref("messages/"+snapshot.key).update({
        //     // status:"read"
        // });

        
        var html = "";
        // give each message a unique ID
        
        // show delete button if message is sent by me
        if (snapshot.val().sender == myName) {
            html += "<li class ='sentMessage' id='message-" + snapshot.key + "'>";
            html += "<button data-id='" + snapshot.key + "' onclick='deleteMessage(this);'>";
                html += "Delete";
            html += "</button>";
            html +=  snapshot.val().message;
            html += "</li>";
        }
        else{
            str = "read";
            firebase.database().ref(new_str1).update({
                status: str
            });

            html += "<li class = 'receivedMessage' id='message-" + snapshot.key + "'>";
            html += snapshot.val().sender + ": " + snapshot.val().message;
            html += "</li>";
        }
        
        
        // console.log(html);
        
        document.getElementById("messages").innerHTML += html;
    }
}

function sendMessage() {
    // console.log(window.hasOwnProperty("chatKey"));
    
    if(window.hasOwnProperty("chatKey") == false ){
        //start a new conversation here
        chat();
    }

    // console.log("send message to: "+ chatKey);
    
    // // --get message
    var message = document.getElementById("message").value;
    let readString = 'unread';

    // --save in database
    firebase.database().ref("messages/" + chatKey).push().set({
        "sender": myName,
        "message": message,
        "status": readString,
        "timestamp": firebase.database.ServerValue.TIMESTAMP 
    });
    document.getElementById("message").value = "";
    // --prevent form from submitting
    // return false;
}

function deleteMessage(self) {
    console.log("delete message: ",self);
    
    // get message ID
    var messageId = self.getAttribute("data-id");
 
    // delete message
    firebase.database().ref("messages").child(messageId).remove();
}
 
// attach listener for delete message
firebase.database().ref("messages").on("child_removed", function (snapshot) {
    // remove message node
    document.getElementById("message-" + snapshot.key).innerHTML = "This message has been removed";
});


//--END OF CHAT--
function findUser(){
    
    // console.log(queryString);
    var userToDisplay =  allUsersArray.filter(function(filter) {
    return filter.appId == product;
    });
    
    var filteredUserInfo = userToDisplay[0]
    console.log(typeof(filteredUserInfo));
    
    // console.log(userToDisplay);
    if (filteredUserInfo.profileImageUrl){
        document.getElementById("profileImage").src = filteredUserInfo.profileImageUrl;
    }
    
    tempArr = [];
    let tempA = filteredUserInfo.fieldsOfinterest;
    for (i in tempA){
        // console.log(tempA[i]);
        tempArr.push(tempA[i]);
    }            
    document.getElementById("name").innerHTML = filteredUserInfo.name + " " + filteredUserInfo.lastName;
    document.getElementById("fieldsOfInterest").innerHTML = "Fields of Practice: " + tempArr.toString();
    document.getElementById("addressCity").innerHTML = filteredUserInfo.city + ", " + filteredUserInfo.country;
    // document.getElementById("addressCountry").innerHTML = filteredUserInfo.country;
    document.getElementById("about").innerHTML = "About: " + filteredUserInfo.about;
    document.getElementById("exLanguage").innerHTML = filteredUserInfo.mainLanguage;
    document.getElementById("website").innerHTML = filteredUserInfo.userWebSite;
    document.getElementById("faceBook").innerHTML = filteredUserInfo.facebookUrl;
    document.getElementById("linkedIn").innerHTML = filteredUserInfo.linkedInUrl;
    
    //show all info that was hidden till load!
    document.getElementById("info").style.display = "";
    // document.getElementById("loading").style.display = "none";
    
}

function contactUser(){

    console.log("Implement sending email here");
    
}

function chat(){
    console.log("Chat here");

    //initiate a new chat
    var reference = firebase.database().ref("messages").push()
    var uniqueKey = reference.key
    var nowTime = new Date();

    reference.set({
        creator: currentUser.appId,
        to: product,
        status: "waiting",
        created: firebase.database.ServerValue.TIMESTAMP
    })
    .then(() => {
        uq = uniqueKey;
        console.log(uq);
        chatKey = uq;
    })
    .catch(err =>{
        console.log(err)
    });


    // var newRef = firebase.database().ref("messages").push();
    // var newID = newRef.name();
    // console.log(newID);
    
    //create a new firebase message ID
    // firebase.database().ref("messages").push().set({
    //     "sender": myName,
    //     "message": message
    // });
    
}





