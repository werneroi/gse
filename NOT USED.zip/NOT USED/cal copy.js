
// var database = firebase.database();
// var currentUser = JSON.parse(localStorage.getItem("currentUser"));

// const queryString = window.location.search;
// console.log(queryString);
// if (queryString){
//   const urlParams = new URLSearchParams(queryString);
//   const product = urlParams.get('id')
//   console.log(product);
//   readEvents(product);

// }

//goto event based on id!!!

document.addEventListener('DOMContentLoaded', function() {
  // var eventDiv = document.getElementById('singleEvent');
  // eventDiv.style.display = "none";

  let today = new Date().toISOString().slice(0, 10)
  // color_main = '#361156';
  // color_guest = '#369810';
  // color_special = '#369890';




  
  /* initialize the calendar
  -----------------------------------------------------------------*/
  // readEvents();
  // var currentUser = JSON.parse(localStorage.getItem("currentUser"));
  // console.log(currentUser);
  //   // console.log(calArrayNew);
  // // console.log(currentUser.name +" " +currentUser.luid );
  // console.log(currentUser.calArray);
  // if (currentUser.calArray){
    
    
  var allEvents = [];
  // };

  var calendarEl = document.getElementById('calendar');
  myCalendar = new FullCalendar.Calendar(calendarEl, {
    eventClick: function(info) {


      // var eventObj = info.event;
      // var eventEnding = moment(eventObj.end);
          
      //   console.log(eventEnding.format('HH:mm:ss'));
      //   console.log(eventEnding.format('YYYY-MM-DD'));


      //   //--check if the current time clicked is before the end of event, if so allow to click, else do nothing.
      //   var timeClickedDate = Date.parse(moment().format('YYYY-MM-DD'));
      //   let endDate = Date.parse(eventEnding.format('YYYY-MM-DD'));
      //   if (timeClickedDate>endDate){
      //     console.log("event is in the past");
      //     alert("You can not show an event in the past!");
      //     return;
      //   }
      //   else if (timeClickedDate == endDate){
      //     var timeClickedTime = moment().format('HH:mm:ss');
      //     let endTime = eventEnding.format('HH:mm:ss');
          
        
          
      //     str1 =  timeClickedTime.split(':');
      //     str2 =  endTime.split(':');

      //     console.log(timeClickedTime + " " + endTime);

      //     totalSecondsTimeClicked = parseInt(str1[0] * 3600 + str1[1] * 60 + str1[0]);
      //     totalSecondsEndtime = parseInt(str2[0] * 3600 + str2[1] * 60 + str2[0]);
      //     console.log(totalSecondsTimeClicked + " " + totalSecondsEndtime);
      //     if (totalSecondsTimeClicked > totalSecondsEndtime ){
      //       console.log("event is in the past");
      //       alert("You can not show an event in the past!");
      //       return;
      //     }
      //     else{
      //       console.log("event is in the future");
      //     }          
      //   }



      // // alert ("hell");
      // var eventObj = info.event;
      // if (eventObj.url) {
      //   alert(
      //     'Clicked ' + eventObj.title + '.\n' +
      //     'Will open ' + eventObj.url + ' in a new tab'
      //   );

      //   window.open(eventObj.url);

      //   info.jsEvent.preventDefault(); // prevents browser from following link in current tab.
      // } else {
      //   console.log(eventObj.start);
      //   // console.log(eventObj.end);
      //   //open an even window
      //   calDiv = document.getElementById('calendar');
        
      //   eventId = eventObj.id;

      //   document.getElementById('eventAuther').innerHTML = eventObj.extendedProps.auther;
      //   document.getElementById('eventName').innerHTML = eventObj.title;
      //   document.getElementById('eventStart').innerHTML = eventObj.start;
      //   document.getElementById('eventEnd').innerHTML = eventObj.end;
      //   document.getElementById('acceptGuest').checked = eventObj.extendedProps.acceptGuest;
      //   console.log("check?: ",document.getElementById('acceptGuest').checked);

      //   console.log(eventId);
      //   CurrentEvent=myCalendar.getEventById(eventId);
        

      //   // document.getElementById('calendar').hidden = true;
      //   // calDiv.style.visibility = "hidden";
      //   // document.getElementById('singleEvent').style.visibility = "visible";
      //   calDiv.style.display = "none";
      //   document.getElementById('acceptGuest_default').style.display = "none";
      //   document.getElementById('singleEvent').style.display = "block";


      // }
    },
    now: today,
    startEditable: true,
    editable: true, // enable draggable events
    droppable: true, // this allows things to be dropped onto the calendar
    selectable: true,
    aspectRatio: 1.8,
    // scrollTime: '09:00', // undo default 6am scrollTime
    headerToolbar: {
      left: 'today prev,next',
      center: 'title',
      right: 'timeGridDay,timeGridWeek,dayGridMonth'
    },
    dateClick: function(info) {
      console.log('clicked ' + info.dateStr);

    },
    
    select: function(info) {
      




      // var eventObj = info.event;
      // var eventEnding = moment(info.startStr);
          
      //   console.log(eventEnding.format('HH:mm:ss'));
      //   console.log(eventEnding.format('YYYY-MM-DD'));


      //   //--check if the current time clicked is before the end of event, if so allow to click, else do nothing.
      //   var timeClickedDate = Date.parse(moment().format('YYYY-MM-DD'));
      //   let endDate = Date.parse(eventEnding.format('YYYY-MM-DD'));
      //   if (timeClickedDate>endDate){
      //     console.log("event is in the past");
      //     alert("You can not create an event in the past!");
      //     return;
      //   }
      //   else if (timeClickedDate == endDate){
      //     var timeClickedTime = moment().format('HH:mm:ss');
      //     let endTime = eventEnding.format('HH:mm:ss');
          
        
          
      //     str1 =  timeClickedTime.split(':');
      //     str2 =  endTime.split(':');

      //     console.log(timeClickedTime + " " + endTime);

      //     totalSecondsTimeClicked = parseInt(str1[0] * 3600 + str1[1] * 60 + str1[0]);
      //     totalSecondsEndtime = parseInt(str2[0] * 3600 + str2[1] * 60 + str2[0]);
      //     console.log(totalSecondsTimeClicked + " " + totalSecondsEndtime);
      //     if (totalSecondsTimeClicked > totalSecondsEndtime ){
      //       console.log("event is in the past");
      //       alert("You can not create an event in the past!");
      //       return;
      //     }
      //     else{
      //       console.log("event is in the future");
      //     }          
      //   }



      // console.log(document.getElementById('acceptGuest_default').checked);
      // var currentUser = JSON.parse(localStorage.getItem("currentUser"));
      // let r = Math.random().toString(36).substring(2);
      // var allowGuest = false;
      // var bgColor = color_main;
      // if (document.getElementById('acceptGuest_default').checked==true){
      //   allowGuest = true;
      //   bgColor = color_guest;
      // }
      // myCalendar.addEvent({
      //         id: r,
      //         title: currentUser.name +" " +currentUser.lastName,
      //         start: info.startStr,
      //         end: info.endStr,
      //         allDay: false,
      //         backgroundColor: bgColor,
      //         appId: currentUser.appId,
      //         auther: currentUser.name,
      //         acceptGuest : allowGuest
      //       });

      //       CurrentEvent=myCalendar.getEventById(r);

      //       //save all events to firebase
      //       // saveAllEvents(myCalendar);
      //       writeEvents();
    },
    initialView: 'timeGridWeek',
    // 'listDay'
    // views: {
    //   resourceTimelineThreeDays: {
    //     type: 'timeline',
    //     duration: { days: 3 },
    //     buttonText: '3 days'
    //   }
    // },
    selectMinDistance: 15,
    events: [
      {
        title: 'BCH237',
        start: '2020-10-18T10:30:00',
        end: '2020-10-18T13:30:00',
      },
      {
        title: 'BCH238',
        start: '2020-10-18T14:30:00',
        end: '2020-10-18T16:30:00',
      }
    ],
    eventResize: function(info) {
      // console.log(info);
      
      // var eventObj = info.event;
      // var eventEnding = moment(eventObj.end);
          
      //   console.log(eventEnding.format('HH:mm:ss'));
      //   console.log(eventEnding.format('YYYY-MM-DD'));


      //   //--check if the current time clicked is before the end of event, if so allow to click, else do nothing.
      //   var timeClickedDate = Date.parse(moment().format('YYYY-MM-DD'));
      //   let endDate = Date.parse(eventEnding.format('YYYY-MM-DD'));
      //   if (timeClickedDate>endDate){
      //     console.log("event is in the past");
      //     alert("You can not edit an event in the past!");
      //     info.revert();
      //     return;
      //   }
      //   else if (timeClickedDate == endDate){
      //     console.log("same day");
          
      //     var timeClickedTime = moment().format('HH:mm:ss');
      //     let endTime = eventEnding.format('HH:mm:ss');
          
        
          
      //     str1 =  timeClickedTime.split(':');
      //     str2 =  endTime.split(':');

      //     console.log(timeClickedTime + " " + endTime);

      //     totalSecondsTimeClicked = parseInt(str1[0] * 3600 + str1[1] * 60 + str1[0]);
      //     totalSecondsEndtime = parseInt(str2[0] * 3600 + str2[1] * 60 + str2[0]);
      //     console.log(totalSecondsTimeClicked + " " + totalSecondsEndtime);
      //     if (totalSecondsTimeClicked > totalSecondsEndtime ){
      //       console.log("event is in the past");
      //       alert("You can not edit an event in the past!");
      //       return;
      //     }
      //     else{
      //       console.log("event is in the future");
      //     }          
      //   }




      // writeEvents();
    },
    drop: function(arg) {
      // console.log(arg);
      
      


      // console.log('drop date: ' + arg.dateStr)

      // if (arg.resource) {
      //   console.log('drop resource: ' + arg.resource.id)
      // }

      // // is the "remove after drop" checkbox checked?
      // if (document.getElementById('drop-remove').checked) {
      //   // if so, remove the element from the "Draggable Events" list
      //   arg.draggedEl.parentNode.removeChild(arg.draggedEl);
      // }
      // writeEvents();
    },
    eventReceive: function(arg) { // called when a proper external event is dropped
      console.log('eventReceive', arg.event);
    },
    eventDrop: function(arg) { // called when an event (already on the calendar) is moved

      // console.log('eventDrop', arg.event);
      
      // var eventObj = arg.event;
      // var eventEnding = moment(eventObj.end);
          
      //   console.log(eventEnding.format('HH:mm:ss'));
      //   console.log(eventEnding.format('YYYY-MM-DD'));


      //   //--check if the current time clicked is before the end of event, if so allow to click, else do nothing.
      //   var timeClickedDate = Date.parse(moment().format('YYYY-MM-DD'));
      //   let endDate = Date.parse(eventEnding.format('YYYY-MM-DD'));
      //   if (timeClickedDate>endDate){
      //     console.log("event is in the past");
      //     alert("You can not move an event in the past!");
      //     arg.revert();
      //     return;
      //   }
      //   else if (timeClickedDate == endDate){
      //     var timeClickedTime = moment().format('HH:mm:ss');
      //     let endTime = eventEnding.format('HH:mm:ss');
          
        
          
      //     str1 =  timeClickedTime.split(':');
      //     str2 =  endTime.split(':');

      //     console.log(timeClickedTime + " " + endTime);

      //     totalSecondsTimeClicked = parseInt(str1[0] * 3600 + str1[1] * 60 + str1[0]);
      //     totalSecondsEndtime = parseInt(str2[0] * 3600 + str2[1] * 60 + str2[0]);
      //     console.log(totalSecondsTimeClicked + " " + totalSecondsEndtime);
      //     if (totalSecondsTimeClicked > totalSecondsEndtime ){
      //       console.log("event is in the past");
      //       alert("You can not move an event in the past!");
      //       return;
      //     }
      //     else{
      //       console.log("event is in the future");
      //     }          
      //   }
      
      
      
      // writeEvents();
    }

  });
  var now = new Date();
  // var rangeStart = myCalendar.state.dateProfile.renderRange.start;

  // attention here
  
  myCalendar.render();
  myCalendar.scrollToTime('09:00');
  console.log("done?");
  

});


function saveData(){
  // firebase.database().ref('users/' + currentUser.luid).update(
  //   {

  //     jasonArray: jasonArray
  // //     email: currentUser.email,
  // //     name: currentUser.name,
  // //     lastName: currentUser.lastName,
  // //     mainLanguage: currentUser.mainLanguage,
  // //     secLanguage: currentUser.secLanguage,
  // //     address: currentUser.address,
  // //     city: currentUser.city,
  // //     country: currentUser.country,
  // //     luid: currentUser.luid,
  // // //   //   username: name,
  // //     calender: {
  // //                       name: propValue.name,
  // //                       start: propValue.start,
  // //                       end: propValue.end,
  // //                       id: propValue.id
  // //                   }
  //   });
  //   // localStorage.setItem("currentUser", JSON.stringify(currentUser));
  //   console.log("written please check");

}

function readEvents(eventId){
  // console.log("readEvents"+" "+eventId);
  
  // var userId = firebase.auth().currentUser.uid;
return firebase.database().ref('/users/' + currentUser.luid).once('value').then(function(snapshot) {
  // var username = (snapshot.val() && snapshot.val().about) || 'Anonymous';
  // alert(username);
  // console.log(snapshot.val().calArray);
  calArrayNew = JSON.parse(snapshot.val().calArray);
  var eventfound = false;
  for (let index = 0; index < calArrayNew.length; index++) {
    // console.log(calArrayNew[index]);
    
    if(calArrayNew[index].id == eventId){
      const element = calArrayNew[index];
      console.log("event found: " +  element.start);
      console.log(typeof(element));
      myCalendar.gotoDate(element.start); 
      eventfound = true;
      break;           
    }
  }
  if (eventfound==false){
   
      alert ("Ooops! this event was not found here!")
 
  }
  // console.log(calArrayNew);
  // ...
  });
}

function writeEvents(){
  array = myCalendar.getEvents();
  console.log(array);
  jasonArray = JSON.stringify(array);
  console.log(jasonArray);
  currentUser.calArray = jasonArray;
  firebase.database().ref('users/' + currentUser.luid).update(
    {
      calArray: jasonArray
      // test: "passed"
    });
    localStorage.setItem("currentUser", JSON.stringify(currentUser));

}


function addevent(){
  console.log(JSON.stringify(CurrentEvent));

  // myCalendar.addEvent({
  //         id: r,
  //         title: 'dynamic event',
  //         start: info.startStr,
  //         end: info.endStr,
  //         allDay: false
  //       });
}

function returnTable(){


  console.log(JSON.stringify(CurrentEvent));
  calDiv.style.display = "block";
  document.getElementById('acceptGuest_default').style.display = "block";
  document.getElementById('singleEvent').style.display = "none";
  CurrentEvent.remove();
  console.log(CurrentEvent.backgroundColor + " " + document.getElementById('acceptGuest').checked);
  if(document.getElementById('acceptGuest').checked == true){
    bgColor = color_guest;
    console.log(bgColor);
  }
  else{
    bgColor = color_main;
    console.log(bgColor);
  }

  myCalendar.addEvent({
          id: CurrentEvent.id,
          // title: 'FREE TIME',
          title: CurrentEvent.title,
          start: CurrentEvent.start,
          end: CurrentEvent.end,
          allDay: false,
          auther: CurrentEvent.extendedProps.auther,
          backgroundColor: bgColor,
          acceptGuest: document.getElementById('acceptGuest').checked
        });
  writeEvents();

}

function doSOmething(callback){
          callback();
};

function deleteEvent(){


  console.log(JSON.stringify(CurrentEvent));
  // calendar.render();
  // document.getElementById('calendar').style.display = "initial";
  // calDiv.style.visibility = "visible";
  // document.getElementById('singleEvent').style.visibility = "hidden";
  calDiv.style.display = "block";
  document.getElementById('acceptGuest_default').style.display = "block";
  document.getElementById('singleEvent').style.display = "none";
  CurrentEvent.remove();

  var MyCal = myCalendar.getEvents();
  console.log(JSON.stringify(myCalendar.getEvents()));
  // saveAllEvents(myCalendar);
  writeEvents();

}


function verifyTimeValid(){
  //check if the date end is before now, don't click!
        // alert(eventObj.start.format('h:mm:ss a'));
        
        
}





