var currentUser = JSON.parse(localStorage.getItem("currentUser"));
allUsersNamesArray = [];
calAllEvents = [];
selectedUsers = [];
fbAllEvents = [];
myCalendar = FullCalendar;
var showFavsOnly = false;

var singleEventOriginalStart = "";
var singleEventOriginalEnd = "";

var currentdate = new Date();
var datetime = "Last Sync: " + currentdate.getDay() + "/" + currentdate.getMonth() 
+ "/" + currentdate.getFullYear() + " @ " 
+ currentdate.getHours() + ":" 
+ currentdate.getMinutes() + ":" + currentdate.getSeconds();



document.addEventListener('DOMContentLoaded', function() {
  console.log("build cal 2");
  
  //create tabs according to the user field of interest.
  // createTabsNamesByInterest();
  buildFOISelector();
  document.getElementById('myself').innerHTML = currentUser.name + " " + currentUser.lastName; 
  isGuestsOnlyActive = document.getElementById('guestOnly');

  //enable 'ENTER' on search
  var input = document.getElementById("myInput")
  input.addEventListener("keyup", function(event) {
  // Number 13 is the "Enter" key on the keyboard
    if (event.keyCode === 13) {
      // Cancel the default action, if needed
      event.preventDefault();
      // Trigger the button element with a click
      document.getElementById("searchB").click();
    }
  });
// InitCal(); is called from Init!
       
});


//----TABS-----//

// function createTabsNamesByInterest (){
//   let localFieldsOfInterest = [];
//   for (i in currentUser.fieldsOfinterest){
//     localFieldsOfInterest.push(currentUser.fieldsOfinterest[i]);
//   }
//   localFieldsOfInterest.push("All_as_guest");
  
//   htmlString = '';
//   tabsString = '';
//   //console.log("create tabs local " + localFieldsOfInterest);
//   //console.log("create tabs " + currentUser.fieldsOfinterest);
  
//   for (i in localFieldsOfInterest){
//       activeString = '';
//       if(i == 0){
//         activeString = " active";
//       }
//       currentField = localFieldsOfInterest[i]
//       htmlString += "<button class='tablinks " + activeString + "' onclick='openTab(event, " +currentField + ")'>" + currentField + "</button>"
//       tabsString += "<div id=" + currentField + " class='tabcontent'><h3>" + currentField + "</h3><div  id='allUsersDisplay'></div></div>"
//   }
//   htmlData = "<div id='tableTabsByInterest' class='tab'>"+htmlString+"</div>"+tabsString;
//   document.getElementById("tabsNav").innerHTML = htmlData;
// }

// function openTab(evt, fieldName) {
//     console.log(fieldName.id);
//         if (fieldName.id == "All_as_geusts"){
      
//         }
//         else{        
//             var i, tabcontent, tablinks;
//             tabcontent = document.getElementsByClassName("tabcontent");
//             for (i = 0; i < tabcontent.length; i++) {
//               tabcontent[i].style.display = "none";
//             }
//             tablinks = document.getElementsByClassName("tablinks");
//             for (i = 0; i < tablinks.length; i++) {
//               tablinks[i].className = tablinks[i].className.replace(" active", "");
//             }
//             // document.getElementById(fieldName.id).style.display = "block";
//             evt.currentTarget.className += " active";  
//         }

//     filterCurrentInterest(fieldName.id)    
//   }
var usersResourceList =[];
var allEventsFromFBOrigin=[];
//   ------------------- CALENDAR ------------------
function InitCal(){    
      
  console.log("create events database from snapShot");
  newSelfEvents = []; 
  newSelfEventsJSON =[];      
  var i =0;
  selfEvents = [];
  allUsersSnapShot.forEach(function(child) 
  
  {
                  
      //create a list of all users with out myself!
      let userFullName = child.val().name + " " + child.val().lastName
      usersResourceList.push({
        
        id: child.val().appId,
        title: userFullName
        
      })
      if (child.val().appId != currentUser.appId){
      // //console.log("found: "+ child.val().appId);
          allUsersNamesArray.push({
              key:   child.val().appId,
              value: userFullName
          });  
      }

      else{
        // selfEvents = JSON.stringify(child.val().calArray);
        // if (child.val().calArray){
          //======== DEAL WITH SELF EVENTS HERE ==============//
          let tempChildArray = child.val().calArray;
          console.log(typeof(tempChildArray));
          if(typeof(tempChildArray) === undefined || tempChildArray == undefined){
            tempChildArray = [];
            console.log(tempChildArray);
          }
          
          if(tempChildArray.length != 0){                                        
                                              
              var localSelfCalArray = child.val().calArray;                  
              var tempEvent = [];
              for(v in localSelfCalArray){
                // console.log(tempEvent.id + " "+ tempEvent.backgroundColor);
                // console.log(JSON.stringify(tempEvent));
                
                tempEvent = JSON.parse(localSelfCalArray[v])
                console.log(tempEvent);
                // tempEvent.title = child.val().name + "\n" + child.val().lastName;
                if (tempEvent.backgroundColor == "orange"){
                  tempEvent.editable = false;
                  tempEvent.droppable = false;
                }
                else if (tempEvent.extendedProps.acceptGuest == "waiting"){
                  tempEvent.editable = false;
                  tempEvent.droppable = false;
                  
                }
                else if (tempEvent.extendedProps.description){
                  if (tempEvent.extendedProps.description.length > 0){
                    tempEvent.title = ("waiting for confirmation");
                    tempEvent.editable = false;
                    tempEvent.droppable = false;
                  }
                  
                }
                else if(tempEvent.extendedProps.acceptGuest == "booked"){
                  tempEvent.backgroundColor = color_booked;
                  tempEvent.title = tempEvent.title.replace("requested by:","confirmed with:")
                  tempEvent.editable = false;
                  tempEvent.droppable = false;
                }

                else if(tempEvent.extendedProps.acceptGuest == "none"){
                  tempEvent.backgroundColor = color_special;
                }
                else if (tempEvent.extendedProps.acceptGuest == true){
                  tempEvent.backgroundColor = color_guest_me;
                  tempEvent.editable = true;
                  tempEvent.droppable = true;
                }
                else{
                  tempEvent.backgroundColor = color_normal_me;
                  tempEvent.editable = true;
                  tempEvent.droppable = true;
                } 
                
                //GETTING THE EVENT FROM THE FIREBASE
                // console.log(tempEvent);
                // console.log(typeof(tempEvent));
              //   console.log(JSON.stringify(tempEvent));
                
                              
                selfEvents = selfEvents.concat(tempEvent);
                newSelfEventsJSON = newSelfEventsJSON.concat(JSON.stringify(tempEvent));
                
                newSelfEvents.push(tempEvent);
                
                
                // currentUser.calArray = selfEvents;
          //       // console.log(fbAllEvents);
                
          //       fbAllEvents = fbAllEvents.concat(JSON.stringify(tempEvent));                                 
              }
            }                                              
      }
        
      
      //once finished populate the users table and make the calendar
      i = i+1;
      if (i== allUsersSnapShot.numChildren()){      
          allEventsFromFBOrigin = fbAllEvents;
          eventsToBuildArray_cache = fbAllEvents;
          console.log("eventsToBuildArray_cache1: ",eventsToBuildArray_cache);
          
          populateUsersTablePC1(allUsersNamesArray);
          makeCal(fbAllEvents);
          filterCurrentInterest(currentUser.fieldsOfinterest[0]);
      };                            
    });
}
// fc-datagrid-cell-cushion fc-scrollgrid-sync-inner
function resourcesCSS(){
  let resourcesDivs = document.getElementsByClassName("fc-datagrid-cell-main");
  // let resourcesDivs = document.getElementsByClassName("fc-datagrid-cell-cushion");
  for (e in resourcesDivs){
    let nameString = resourcesDivs[e].innerText;
    // fbUserAppIdTrimed = fbUserAppId.slice(1, -1);
    if (nameString)
    {
      // console.log("++++++++++++++++",resourcesDivs[e].innerText);

        parent = resourcesDivs[e].parentNode,
        contents = parent.innerHTML ;
        
        
        // parent.innerHTML = "<div id='holder' onclick='toggleUserSelection(" + fbUserAppId + ")'>"<i class="favIcon fa fa-star"' + contents + '</div>';
        parent.innerHTML ="<div id='holder'>" + contents + "</div>";
        // resourcesDivs[e].innerHTML = "<p style='display: inline-block'>" + nameString +'</p>';
    }    
  }
}

var runShowmyself = 0;
console.log("changing runShowmyself to 0");
var indexxxx=0;

function makeOneDayCal(event1){
        console.log(JSON.stringify(event1));

        eventSingle = event1;
        var calendarEl = document.getElementById('calendarSingle');
        calendarEl.style.display = "block";
        document.getElementById('calendar').style.display = "none";
        document.getElementById('backToCal').style.display = "block";
        document.getElementById('label_AG').style.display = "none";
        document.getElementById('acceptGuest_default').style.display = "none";

        document.getElementById('label_AG_singlePage').style.display = "";
        document.getElementById('acceptGuest_singlePage').style.display = "";

        if (eventSingle.extendedProps.acceptGuest == true){          
          document.getElementById('acceptGuest_singlePage').checked = true;
        }
        else{          
          document.getElementById('acceptGuest_singlePage').checked = false;
        }
        

        
        var scrollT = moment(event1.start).format('HH:mm:ss');
        console.log(scrollT);
        
        let r = Math.random().toString(36).substring(2);

        let backgroundColor = color_toBook;
        let editable = true;
        if (event1.extendedProps.acceptGuest == "booked"){
          console.log("Found accepted guest booked");
          backgroundColor = color_booked;
          editable = false;
        }

        let displayForm = 'background'
        if(event1.extendedProps.appId == currentUser.appId){
          console.log("Found as self event");
          displayForm = 'block'
        }
        var eventsToCal = [];
        if(event1.extendedProps.acceptGuest != "booked"){
          console.log("Found not booked");
          eventsToCal =[
            {
            resourceId: currentUser.appId,
            id: event1.id,
            title: event1.title,
            start: moment(event1.start).format(),
            end: moment(event1.end).format(),  
            backgroundColor: event1.backgroundColor,
            display: displayForm ,
            extendedProps:{
                  acceptGuest : event1.extendedProps.acceptGuest,
                  appId: currentUser.appId,
                  auther: currentUser.name + " " + currentUser.lastName,
                  droppable: false,
                  
                },                        
          }          
        ];
        }
        else{
          eventsToCal=[{
            resourceId: currentUser.appId,
            id: r,
            title: event1.title,
            start: moment(event1.start).format(),
            end: moment(event1.end).format(),  
            backgroundColor: backgroundColor,
            extendedProps:{
              acceptGuest : event1.extendedProps.acceptGuest,
              appId: currentUser.appId,
              auther: currentUser.name + " " + currentUser.lastName,
              droppable: false
            }}]

        }
        

        calendar1 = new FullCalendar.Calendar(calendarEl, {

          select: function(info){

            console.log("select - ");
            console.log(calendar1.getEvents().length);
            if (calendar1.getEvents().length > 1){
              calendar1.getEvents()[1].remove();
            }
            var eventObj = info.event;
            var eventEnding = moment(info.startStr);
            console.log(eventEnding);   
                                          
            var allowGuest = false;
            var bgColor = color_toBook;
            
            
            calendar1.addEvent({
              resourceId: appId,
              id: r,
              title: currentUser.name +" " +currentUser.lastName,
              start: moment(info.start).format(),
              end: moment(info.end).format(),              
              editable: true,
              droppable: true,
              description :"",
              backgroundColor: color_guest_me,              
              extendedProps:{
                acceptGuest : false,
                appId: currentUser.appId,
                auther: currentUser.name + " " + currentUser.lastName,
                droppable: false
              }              
            })
          },

          displayEventTime:true,
            initialView: 'timeGridDay',
            // initialView:'resourceTimeline',
            allDaySlot: false, 
            allDay:false,
            
            selectable: true,
            dragScroll:false,
            editable: editable,
            droppable: false, 
            eventResizableFromStart: true,
            slotDuration: ('00:15:00'), 
            dayMaxEventRows: true,                        
            scrollTime: (scrollT), 
            eventContent: { domNodes: [] },            
            eventContent: function(arg) {
                  let italicEl = document.createElement('p')                  
                  italicEl.innerHTML = moment(arg.event.start).format('HH:mm')+" - " + moment(arg.event.end).format('HH:mm') + '<br/>' + arg.event.title;
                  let arrayOfDomNodes = [ italicEl ]
                  return { domNodes: arrayOfDomNodes }
            },

            resources: usersResourceList,             
            events: eventsToCal
                                        
        });

        calendar1.render();
        calendar1.gotoDate(moment(event1.start).format());
        // calendar1.eventRender.;
        
        
        var timeSlotArray =document.getElementsByClassName("fc-event-draggable");
        var timeSlot = timeSlotArray[timeSlotArray.length-1];
        
        // if(event1.extendedProps.acceptGuest != "booked"){
        //     timeSlot.className = "fc-timegrid-event fc-v-event fc-event fc-event-resizable fc-event-start fc-event-end fc-event-today fc-event-future";
        // }

        
        
        var addEventB = document.getElementById('AddEventManually');
            addEventB.style.display = 'none';
        
        if(event1.extendedProps.appId != currentUser.appId){
            calendar1.setOption("slotMaxTime", moment(event1.end).format('HH:mm'));
            calendar1.setOption("slotMinTime", moment(event1.start).format('HH:mm'));

            var deleteB = document.getElementById('deleteEvent');
            deleteB.style.display = 'none';
            document.getElementById('requestEv').style.display = "block"; 
            document.getElementById('label_AG_singlePage').style.display = "none";
            document.getElementById('acceptGuest_singlePage').style.display = "none";                       
            
        } 
        else if (event1.extendedProps.acceptGuest == "waiting"){
          document.getElementById('label_AG_singlePage').style.display = "none";
            document.getElementById('acceptGuest_singlePage').style.display = "none";
            var deleteB = document.getElementById('deleteEvent');
            deleteB.style.display = 'block';

        }
        else if (event1.extendedProps.acceptGuest == "booked"){
            calendar1.setOption("slotMaxTime", moment(event1.end).format('HH:mm'));
            calendar1.setOption("slotMinTime", moment(event1.start).format('HH:mm'));
            document.getElementById('label_AG_singlePage').style.display = "none";
            document.getElementById('acceptGuest_singlePage').style.display = "none";
            var deleteB = document.getElementById('deleteEvent');
            deleteB.style.display = 'block';
        }
        else{
          
          var deleteB = document.getElementById('deleteEvent');
            deleteB.style.display = 'block';
            
          

        } 
        console.log(moment(event1.end).format('HH:mm'));   
        // calendar1.setOption("slotMaxTime", moment(event1.end).format('HH:mm'));
        // calendar1.setOption("slotMinTime", moment(event1.start).format('HH:mm'));  
}


function makeCal(fbAllEvents){
  console.log("makecal");  
    
    var initView = 'timeGridWeek';
    // var initView = 'resourceTimeline';
    if (myCalendar.view){
      initView = myCalendar.view.type;
      myCalendar.destroy();
    }
    
    var calendarEl = document.getElementById('calendar');
    document.getElementById('label_AG').style.display = "";
    document.getElementById('acceptGuest_default').style.display = "";
    document.getElementById('label_AG_singlePage').style.display = "none";
    document.getElementById('acceptGuest_singlePage').style.display = "none";
    //console.log("STOPPPPP");
    myCalendar = new FullCalendar.Calendar(calendarEl, {
      
      // Calendar Option
      initialView: initView,
      allDaySlot: false,      
      // views: {
      //   timelineDay: {
      //       type: 'timelineDay',
      //       scrollTime: '09:00:00',
      //   },
      //   timelineWeek: {
      //       type: 'timelineWeek',          
      //       scrollTime: '09:00:00',
      //   },
      //   timelineMonth: {
      //     type: 'timelineMonth'
      //   }
      // },
      // views: {
      //   timeGridDay: {
      //       type: 'timeGrid',
      //       scrollTime: '09:00:00',
      //   },
      //   timeGridWeek: {
      //       type: 'timeGrid',          
      //       scrollTime: '09:00:00',
      //   },
      //   dayGridMonth: {
            
      //   }
      // },
      firstDay: moment().format('e'),
      dragScroll: false,
      now: moment().format(),
      nowIndicator: true,  
      editable: false,
      droppable: false,           
      selectable: true,
      selectOverlap: true,
      eventOverlap: true,
      aspectRatio: 1.8,
      scrollTime: '09:00', // undo default 6am scrollTime
      headerToolbar: {
        left: 'today prev,next',
        center: 'title',
        right: 'resourceTimelineDay,resourceTimelineWeek,resourceTimelineMonth,timeGridDay,timeGridWeek,dayGridMonth'
        // right: 'timeGridDay,timeGridWeek,dayGridMonth'
      },
      dayMaxEventRows: true,
      eventContent: { domNodes: [] },
      eventContent: function(arg) {
          let italicEl = document.createElement('p')
          italicEl.innerHTML = moment(arg.event.start).format('HH:mm')+" - " + moment(arg.event.end).format('HH:mm') + '<br/>' + arg.event.title;
          let arrayOfDomNodes = [ italicEl ]
          return { domNodes: arrayOfDomNodes }
      },
      resources: usersResourceList,

      //------------------------
      //event Options
      
      drop: function(arg) {
        //console.log(arg);

      },
      eventResizeStart: function(arg){
        //console.log("eventResizeStart: ========",arg);
        var eventObj = arg.event;

        if (eventObj.extendedProps.appId != currentUser.appId){
          //console.log("Not your event, can't touch this.");
          // arg.revert();
          return;
        }
        
      },
      eventDrop: function(arg) { // called when an event (already on the calendar) is moved
        
        console.log('eventDrop', arg.event);          
        var eventObj = arg.event;
        if (eventObj.extendedProps.appId != currentUser.appId){
          //console.log("Not your event, can't touch this.");
          
          arg.revert();
          return;
        }
        else
        {
          var eventEnding = moment(eventObj.end);            
          //--check if the current time clicked is before the end of event, if so allow to click, else do nothing.
          var timeClickedDate = Date.parse(moment().format('YYYY-MM-DD'));
          let endDate = Date.parse(eventEnding.format('YYYY-MM-DD'));
          if (timeClickedDate>endDate){
            //console.log("event is in the past");
            alert("You can not move an event in the past!");
            arg.revert();
            return;
          }
          else if (timeClickedDate == endDate){
            var timeClickedTime = moment().format('HH:mm:ss');
            let endTime = eventEnding.format('HH:mm:ss');              
            str1 =  timeClickedTime.split(':');
            str2 =  endTime.split(':');
  
            //console.log(timeClickedTime + " " + endTime);
  
            totalSecondsTimeClicked = parseInt(str1[0] * 3600 + str1[1] * 60 + str1[0]);
            totalSecondsEndtime = parseInt(str2[0] * 3600 + str2[1] * 60 + str2[0]);
            //console.log(totalSecondsTimeClicked + " " + totalSecondsEndtime);
            if (totalSecondsTimeClicked > totalSecondsEndtime ){
              //console.log("event is in the past");
              alert("You can not move an event in the past!");
              return;
            }
            else{
              //console.log("event is in the future");
            }          
          } 
          for (let index = 0; index < newSelfEventsJSON.length; index++) {
              var element = JSON.parse(newSelfEventsJSON[index]);
              console.log(element.id + " / "  + eventObj.id);                
              if(element.id == eventObj.id){
                  console.log("found event - ", element);
                  console.log(eventObj.end);
                  
                  element.start = moment(eventObj.start);
                  element.end = moment(eventObj.end);

                  newSelfEventsJSON[index] = JSON.stringify(element);
                  console.log(JSON.parse(newSelfEventsJSON[index]));                    
                  break;
              }                
          }

          writeEventsP();
        }
      },

      eventResize: function(info) {
        console.log("Resize event: " ,info);

        var eventObj = info.event;
        if (eventObj.extendedProps.appId != currentUser.appId){
          //console.log("Not your event, can't touch this.");
          info.revert();
          return;
        }
        else
        {  
          var eventEnding = moment(eventObj.end);
                        
          //--check if the current time clicked is before the end of event, if so allow to click, else do nothing.
          var timeClickedDate = Date.parse(moment().format('YYYY-MM-DD'));
          let endDate = Date.parse(eventEnding.format('YYYY-MM-DD'));
          if (timeClickedDate>endDate){
            //console.log("event is in the past");
            alert("You can not edit an event in the past!");
            info.revert();
            return;
          }
          else if (timeClickedDate == endDate){
            console.log("same day");
            
            var timeClickedTime = moment().format('HH:mm:ss');
            let endTime = eventEnding.format('HH:mm:ss');

            str1 =  timeClickedTime.split(':');
            str2 =  endTime.split(':');
  
            //console.log(timeClickedTime + " " + endTime);
  
            totalSecondsTimeClicked = parseInt(str1[0] * 3600 + str1[1] * 60 + str1[0]);
            totalSecondsEndtime = parseInt(str2[0] * 3600 + str2[1] * 60 + str2[0]);
            //console.log(totalSecondsTimeClicked + " " + totalSecondsEndtime);
            if (totalSecondsTimeClicked > totalSecondsEndtime ){
              //console.log("event is in the past");
              alert("You can not edit an event in the past!");
              return;
            }                   
          }
          // else{

          //     //deal with updating event:
              
          //     //console.log("event is in the future");
          //   }     

          for (let index = 0; index < newSelfEventsJSON.length; index++) {
              var element = JSON.parse(newSelfEventsJSON[index]);
              console.log(element.id + " / "  + eventObj.id);                
              if(element.id == eventObj.id){
                  console.log("found event - ", element);
                  console.log(eventObj.end);
                  
                  element.start = moment(eventObj.start);
                  element.end = moment(eventObj.end);

                  newSelfEventsJSON[index] = JSON.stringify(element);
                  console.log(JSON.parse(newSelfEventsJSON[index]));                                        
                  break;
              }                
          }    
        writeEventsP();
        }
      },
      
      select: function(info){
        console.log("select_______________");
        
        var eventObj = info.event;
        var eventEnding = moment(info.startStr);
            
        //console.log(eventEnding.format('HH:mm:ss'));
        //console.log(eventEnding.format('YYYY-MM-DD'));


        //--check if the current time clicked is before the end of event, if so allow to click, else do nothing.
        var timeClickedDate = Date.parse(moment().format('YYYY-MM-DD'));
        let endDate = Date.parse(eventEnding.format('YYYY-MM-DD'));
        if (timeClickedDate>endDate){
        //console.log("event is in the past");
        alert("You can not create an event in the past!");
        return;
        }
        else if (timeClickedDate == endDate){
            var timeClickedTime = moment().format('HH:mm:ss');
            let endTime = eventEnding.format('HH:mm:ss');
            
            
            
            str1 =  timeClickedTime.split(':');
            str2 =  endTime.split(':');

            //console.log(timeClickedTime + " " + endTime);

            totalSecondsTimeClicked = parseInt(str1[0] * 3600 + str1[1] * 60 + str1[0]);
            totalSecondsEndtime = parseInt(str2[0] * 3600 + str2[1] * 60 + str2[0]);
            //console.log(totalSecondsTimeClicked + " " + totalSecondsEndtime);
            if (totalSecondsTimeClicked > totalSecondsEndtime ){
                //console.log("event is in the past");
                alert("You can not create an event in the past!");
                return;
            }
            else{
                //console.log("event is in the future");
            }          
        }
   
        //console.log(document.getElementById('acceptGuest_default').checked);
        // var currentUser = JSON.parse(localStorage.getItem("currentUser"));
        let r = Math.random().toString(36).substring(2);
        var allowGuest = false;
        var bgColor = color_normal_me;
        if (document.getElementById('acceptGuest_default').checked==true){
          allowGuest = true;
          bgColor = color_guest_me;
        }

        let myEvent = {
          resourceId: currentUser.appId,
          id: r,
          title: currentUser.name +" " +currentUser.lastName,
          start: info.startStr,
          end: info.endStr,
          allDay: false,
          editable: true,
          droppable: true,
          backgroundColor: bgColor,
          extendedProps:{
            description :"",            
            appId: currentUser.appId,
            auther: currentUser.name,
            acceptGuest : allowGuest            
          }
        };
          
          

        myCalendar.addEvent(myEvent);
              
        console.log(myEvent);
        console.log(JSON.stringify(myEvent));   
        CurrentEvent = myCalendar.getEventById(r);                        
        
        
        // currentUser.calArray = [];
        // localStorage.setItem("currentUser", JSON.stringify(currentUser));
        var tempArrayOfAll = [];
        if(typeof(selfEvents)!==undefined){

          if(selfEvents.length>0){
            tempArrayOfAll = selfEvents;
          }                              
          //console.log("tempArrayOfAll defined " + tempArrayOfAll.length);
          
        }
        else{
          //console.log("tempArrayOfAll not defined" + tempArrayOfAll);
        }
        console.log(typeof(CurrentEvent));
        
        newSelfEventsJSON = newSelfEventsJSON.concat(JSON.stringify(myEvent));
        // newSelfEventsJSON = newSelfEventsJSON.concat(JSON.stringify(CurrentEvent));
      //   newSelfEvents = newSelfEvents.concat(CurrentEvent);

        newSelfEvents = newSelfEvents.concat(JSON.stringify(myEvent));
        // newSelfEvents = newSelfEvents.concat(JSON.stringify(CurrentEvent));
      //   selfEvents.push(JSON.stringify(CurrentEvent));
        console.log(newSelfEventsJSON);
        // console.log(newSelfEvents);
        
        // //console.log("tempArrayOfAll: " ,tempArrayOfAll);
        
        // var tempArrayOfAll =  tempArrayOfAll.concat(JSON.stringify(CurrentEvent));
        // //console.log("tempArrayOfAll: " ,tempArrayOfAll);
        // //console.log(tempArrayOfAll);
        // currentUser.calArray = tempArrayOfAll;

        console.log("New Self Events ",newSelfEvents);
        

        //save all events to firebase
        // saveAllEvents(myCalendar);
        writeEventsP();

      },    

      eventClick: function(info) {
        
        //console.log(info);
        
        var eventObj = info.event;
        userAppId = eventObj.extendedProps.appId;
        
        if (eventObj.url) {
          alert(
            'Clicked ' + eventObj.title + '.\n' +
            'Will open ' + eventObj.url + ' in a new tab'
          );
          window.open(eventObj.url);
          info.jsEvent.preventDefault(); // prevents browser from following link in current tab.
        } 
        else if(eventObj.extendedProps.description){
          if(eventObj.extendedProps.description.length > 0){
            window.location.href = "../gse5/singleEvent.html?&key=" + eventObj.extendedProps.description;
          }
          
        }
        
        
        else {

          //--1/ check if the evnt autor is the suer                    


              $('#datetime15').combodate('setValue', moment(eventObj.start).format('hh:mm A'));
              $('#datetime16').combodate('setValue', moment(eventObj.end).format('hh:mm A'));
              
              singleEventOriginalStart = $('#datetime15').combodate('getValue');
              singleEventOriginalEnd = $('#datetime16').combodate('getValue');
              console.log("singleEventOriginalEnd",singleEventOriginalEnd);
              
                    
              var eventName = document.getElementById('eventName');
              var eventDate = moment(eventObj.start).format('YYYY/MM/DD');
              // var eventStart = moment(eventObj.start).format('hh:mm A');
              // var eventEnd = moment(eventObj.end).format('hh:mm A');
              eventAuther = eventObj.auther;
              // var eventId = eventObj.id;
              eventId = eventObj.id;
          
              document.getElementById('eventName').innerHTML = eventObj.title;
              document.getElementById('eventDate').innerHTML = moment(eventDate).format('DD - MMMM - YYYY');
              
              CurrentEvent=myCalendar.getEventById(eventId);
          
            var eventEnding = moment(eventObj.end);                        

            var timeClickedDate = Date.parse(moment().format('YYYY-MM-DD'));
            let endDate = Date.parse(eventEnding.format('YYYY-MM-DD'));
            
            if (timeClickedDate>endDate){
            //console.log("event is in the past");
            alert("You can not select an event in the past!");
            return;
            }
            else if (timeClickedDate == endDate){
                var timeClickedTime = moment().format('HH:mm:ss');
                let endTime = eventEnding.format('HH:mm:ss');                
                
                str1 =  timeClickedTime.split(':');
                str2 =  endTime.split(':');

                //console.log(timeClickedTime + " " + endTime);

                totalSecondsTimeClicked = parseInt(str1[0] * 3600 + str1[1] * 60 + str1[0]);
                totalSecondsEndtime = parseInt(str2[0] * 3600 + str2[1] * 60 + str2[0]);
                //console.log(totalSecondsTimeClicked + " " + totalSecondsEndtime);
                if (totalSecondsTimeClicked > totalSecondsEndtime ){
                    //console.log("event is in the past");
                    alert("You can not select an event in the past!");
                    return;
                }
                else{
                    //console.log("event is in the future");
                }          
            }  
            
            // -------------
            makeOneDayCal(eventObj)             
        }
      },
      dateClick: function(info) {
        //console.log('clicked ' + info.dateStr);
      },
      resourceRender: function(renderInfo) {
        renderInfo.el.style.backgroundColor = 'blue';
      },

      resourceLabelDidMount: function(arg){
        arg.el.style.backgroundColor = 'orange';
        console.log(arg.resource);
        arg.el.addEventListener("click", function () { console.log('clicked:' + arg.resource.id); });
      },
   

      eventRender(info) {
        console.log(info.event.title);
        // const dept = info.event.extendedProps.department;
        // if (dept && info.event.title.indexOf(dept) === -1 ) {
        //   info.event.setProp('title', info.event.extendedProps.department + ' - ' + 
        //                     info.event.extendedProps.subDept);  
        // }
      }        
    });

    
    
    myCalendar.render(); 
    document.getElementsByClassName("fc-resourceTimelineDay-button")[0].style.display = "none";
    document.getElementsByClassName("fc-resourceTimelineWeek-button")[0].style.display = "none";
    document.getElementsByClassName("fc-resourceTimelineMonth-button")[0].style.display = "none";   
}

function populateUsersTablePC1(usersToPopulateTable){
    console.log("--------usersToPopulateTable: ",usersToPopulateTable);
    
    //populate the names table as an HTML 
    
    let tempString = '';
    let dataHtml = '';
    var displayedNamesArray = [];
    mainDiv = document.getElementById('external-events');
    
    k=0;
    //check inside all the users if there is a fav
    for (var i in usersToPopulateTable)
    {      

      // check if the user is selected (for filtering) and mark the check box on
      for (var temp in selectedUsers){
        if (selectedUsers[temp] == usersToPopulateTable[i] )
        {
          tempString="checked";
          break;
        }
      }
      k = k+1;

      displayedNamesArray = displayedNamesArray.concat(usersToPopulateTable[i].value);
      //create the HTML code
      let fbUserAppId = JSON.stringify(usersToPopulateTable[i].key);
      
      fbUserAppIdTrimed = fbUserAppId.slice(1, -1);
      dataHtml += "<div id='" + fbUserAppIdTrimed + "'class='user_row' onclick='toggleUserSelection(" + fbUserAppId + ")'>"+
      "<i class='fa fa-eye-slash' id='toggleUserSelection" + fbUserAppIdTrimed + "' onclick='toggleUserSelection(" + fbUserAppId + ")'>"+
      "</i>"+
      "<p onclick='openUser(" + fbUserAppIdTrimed + ")'>" + usersToPopulateTable[i].value + "</p>";      
      myFavArray = currentUser.favoritesArray;
      //check if the user is a favorite and check the box on
      var string = "<i class='favIcon fa fa-star'";
      // //console.log("HELLLLLLLOOOOOOO! "+currentUser.favoritesArray);
        if (typeof myFavArray === 'undefined' || myFavArray === null) {

        }
          else {
            for (i in myFavArray){
              // //console.log(myFavArray[i] + "  " + fbUserAppIdTrimed);
                if (myFavArray[i] == fbUserAppIdTrimed){
                //   document.getElementById("toggleUserSelection",fbUserAppIdTrimed).checked = true;
                string = "<i class='favIcon fa fa-heart'";
                break;
                }                                             
            }
          }
      dataHtml += "<i class='chatIcon fa fa-comment' onclick='openUser(" + fbUserAppIdTrimed + ")'></i>" + string + " id='toggleFavorite1"+ fbUserAppIdTrimed +"' onclick='toggleFavorite1(" + fbUserAppId + ")'></i></div>"; 
            
    };
    if (k == usersToPopulateTable.length){
      //update the users table and fill in the autocomplete for search
      mainDiv.innerHTML = dataHtml;
      console.log(displayedNamesArray);
      
      // console.log("usersToPopulateTable++++++++++++++",typeof(usersToPopulateTable),usersToPopulateTable);
      autocomplete(document.getElementById("myInput"), displayedNamesArray);      
    };
}

  

  var tempUsersByInterestArray = [];
  var tempEventForInterest=[];
  var selfEvents = [];
  
  var tempUsersResourcesByInterestArray = [];
  
  var tempEventsFromResources = [];
  
  
  function filterResourcesFOI(currentField){
    
    tempUsersResourcesByInterestArray = [];
    tempEventsFromResources = [];
      
    var allResources = myCalendar.getResources();
    for(e in allResources) {
      allResources[e].remove();
    }


    var localUsersArray = allUsersSnapShot.toJSON();
      allUsersSnapShot.forEach(function(child) 
      {
        var tempFieldsArray = child.val().fieldsOfinterest;

          if (tempFieldsArray === undefined){                        
          }        
          else
          {
            if (Object.values(tempFieldsArray).includes(currentField)) 
            {
                resource = 
                {
                  id:   child.val().appId,
                title: child.val().name + " " + child.val().lastName
                  }
              myCalendar.addResource(resource);

              tempUsersResourcesByInterestArray.push({
                key:   child.val().appId,
                value: child.val().name + " " + child.val().lastName
              }); 
            
              
              // tempEventsFromResources.push(child.val().calArray);
              if(child.val().calArray){
                console.log(child.val().calArray);
                for(e in  child.val().calArray){
                  let elem = child.val().calArray[e];
                  tempEventsFromResources.push(JSON.parse(elem));
                }
              }              
            }            
          }
      });
      console.log(tempEventsFromResources);
      console.log(tempUsersResourcesByInterestArray);
      populateUsersTablePC1(tempUsersResourcesByInterestArray);
      let allEventsHere = myCalendar.getEvents()
      for(e in allEventsHere ){
        allEventsHere[e].remove();
      }
      myCalendar.addEventSource(tempEventsFromResources);  
      $('#loading').hide();    
  }


  function filterCurrentInterest(currentField){
      console.log("filterCurrentInterest: " ,currentField);    
     
      console.log("filtering now: " ,currentField);      
      tempUsersByInterestArray = [];
      tempEventForInterest=[];
      
      //--filter out the users based on FOI
      var localUsersArray = allUsersSnapShot.toJSON();
      allUsersSnapShot.forEach(function(child) 
      {

          var tempFieldsArray = child.val().fieldsOfinterest;

          if (tempFieldsArray === undefined){
            // console.log("undifined tempFieldArray");
            
          }        
          else{
            // create the user list
            if(currentField == "All_as_guest"){
                  tempUsersByInterestArray.push({
                    key:   child.val().appId,
                    value: child.val().name + " " + child.val().lastName
                  }); 

                let tempArray = child.val().calArray;
                if (typeof(tempArray)=== undefined || tempArray === undefined){
                  //console.log("no array found ");
                }
                else
                {
                  if(tempArray === undefined){
                    //console.log("emptry bastered");
                    
                  }
                  else 
                  {
                    if(child.val().appId == currentUser.appId)
                    {
                        var localSelfCalArray = child.val().calArray;

                        tempEvent = [];
                        console.log(tempEvent.backgroundColor);

                        //check if the event are by the current user and if so change the color
                      for(v in localSelfCalArray){
                        tempEvent = JSON.parse(localSelfCalArray[v])

                        if (tempEvent.extendedProps.acceptGuest == "none"){
                          tempEvent.backgroundColor = color_special;
                          tempEvent.editable = true;
                          tempEvent.droppable = true;
                          console.log(typeof(selfEvents));                        
                        }                        
                        else if (tempEvent.extendedProps.acceptGuest == true){
                          tempEvent.backgroundColor = color_guest_me;
                          tempEvent.editable = true;
                          tempEvent.droppable = true;
                          console.log(typeof(selfEvents));                        
                        }
                        else{
                          tempEvent.backgroundColor = color_normal_me;
                          tempEvent.editable = true;
                          tempEvent.droppable = true;
                        }                                      
                      }                    
                    }
                    else
                    {
                        console.log(child.val().name);
                        
                        var localSelfCalArray = child.val().calArray;
                        //console.log(typeof(localSelfCalArray));
                        //console.log(localSelfCalArray);
                        console.log("STOPPPPP");
                        
                        for (i in localSelfCalArray){
                          let tempVar = JSON.parse(localSelfCalArray[i]);
                            //console.log(tempVar.backgroundColor);
                            if (tempVar.backgroundColor == "orange"){
                              // tempVar.display = 'none';

                            }
                            else if (tempEvent.extendedProps.acceptGuest == "waitng"){
                              tempVar.display ='none';                        
                            }

                            else if(tempVar.backgroundColor == "red"){
                              tempVar.backgroundColor = color_special;
                              tempVar.display = 'none';
                            }
                            else if (tempVar.extendedProps.acceptGuest == true){
                              tempVar.backgroundColor = color_guest;
                              tempEventForInterest = tempEventForInterest.concat(tempVar);  
                            }
                            else{
                              tempVar.backgroundColor = color_guest;
                            }                                             
                        }                                             
                      }                
                  } 
                } 
            }
            else
            {
                // console.log("creating users list by interest");
                
                if (Object.values(tempFieldsArray).includes(currentField)) {

                  //========= OTHERES EVENTS VISIBLITY =============//
                    if(child.val().appId != currentUser.appId){
                      // console.log(child.val().name);
                      tempUsersByInterestArray.push({
                          key:   child.val().appId,
                          value: child.val().name + " " + child.val().lastName
                      }); 
                    }
                    
                    
                    // create the Event lists for the relevent users
                    let tempArray = child.val().calArray;
                    if (typeof(tempArray)=== undefined || tempArray === undefined){
                      //console.log("no array found ");
                    }
                    else
                    {
                      if(tempArray === undefined){
                        //console.log("emptry bastered");
                        
                      }
                      else 
                      {
                        if(child.val().appId == currentUser.appId)
                        {
                            var localSelfCalArray = child.val().calArray;

                            tempEvent = [];

                            //check if the event are by the current user and if so change the color
                          for(v in localSelfCalArray)
                          {
                            tempEvent = JSON.parse(localSelfCalArray[v]);
                            console.log(tempEvent.extendedProps.acceptGuest);
                            
                            if (tempEvent.extendedProps.acceptGuest == "none"){
                              console.log("should be red");
                              
                              tempEvent.backgroundColor = color_special;
                              tempEvent.editable = false;
                              tempEvent.droppable = false;


                            }
                            else if (tempEvent.extendedProps.acceptGuest == "waiting"){
                              console.log("waiting event");
                              
                              tempEvent.display = 'none';


                            }
                            else if (tempEvent.extendedProps.acceptGuest == true){
                              // tempEvent.backgroundColor = color_guest_me;
                              tempEvent.editable = true;
                              tempEvent.droppable = true;
                              // console.log(typeof(selfEvents));                        
                            }
                            else
                            {
                              // tempEvent.backgroundColor = color_normal_me;
                              tempEvent.editable = true;
                              tempEvent.droppable = true;
                            }                                          
                          }                    
                        }
                        else
                        {
                            // console.log(child.val().name);
                            //============ SHOW EVENTS OF OTHER USERS =============//
                            var localSelfCalArray = child.val().calArray;                                                
                            for (i in localSelfCalArray){
                              let tempVar = JSON.parse(localSelfCalArray[i]);
                                //console.log(tempVar.backgroundColor);
                                if (tempVar.extendedProps.acceptGuest == 'none'){
                                  tempVar.display = 'none';
                                }
                                else if(tempVar.extendedProps.acceptGuest == "booked"){
                                  tempVar.display = 'none';
                                }
                                else if(tempVar.extendedProps.description && tempVar.extendedProps.description.length>0){
                                  tempVar.display = 'none';
                                }

                                else if (tempVar.extendedProps.acceptGuest == 'waiting'){
                                  tempVar.display = 'none';
                                }
                                else if (tempVar.extendedProps.acceptGuest == true){
                                  tempVar.backgroundColor = color_guest;
                                }
                                else{
                                  tempVar.backgroundColor = color_special;
                                } 
                                tempVar.editable = false;
                                tempEventForInterest = tempEventForInterest.concat(tempVar);                   
                            }                                             
                        }                
                      } 
                    }                                         
                  }  
                }
              }
      });
      
      
      //check if there are selected users
      console.log("selected Users: ",selectedUsers);
      if(selectedUsers.length>0)
      {
        
        for (let index = 0; index < selectedUsers.length; index++) 
        {
          const element = selectedUsers[index];
          console.log(element);
                    
          for (h in tempUsersByInterestArray) 
          {
            console.log(h);
            
            console.log(tempUsersByInterestArray[h].key);
            if(tempUsersByInterestArray[h].key == element){
              console.log("Found a match");
              let filteredEventsByInterest = tempEventForInterest

              // c = a.filter( x => !b.filter( y => y.id === x.id).length);
              filterOne(tempUsersByInterestArray[h].key)

              break;
              
            } 
          }                            
        
        
        // console.log("sortedEventsArra 4: ",sortedEventsArray);        
        // load the selected state!
        // populateUsersTablePC1(tempUsersByInterestArray);
        // filterCal(sortedEventsArray);
       
        populateUsersTablePC1(tempUsersByInterestArray);
        keepSelectedUsersOn();
        return;
        }      
      
      // filterCal(tempEventForInterest);
      //console.log(tempEventForInterest);
      // populateUsersTablePC1(tempUsersByInterestArray);

    }
    
    console.log("======?? tempUsersByInterestArray: ",tempUsersByInterestArray);
    populateUsersTablePC1(tempUsersByInterestArray);

    //refresh the calendar!
    console.log("tempEventForInterest:____",tempEventForInterest);
    const unique = Array.from(new Set(tempEventForInterest.map(JSON.stringify))).map(JSON.parse);
    filterCal(unique);
    // let allevents = myCalendar.getEvents(); 
    // allevents.forEach(el => { el.remove(); })
    // myCalendar.addEventSource(tempEventForInterest);
  
    
}

function returnTable(){
    //console.log(JSON.stringify(CurrentEvent));
    // CurrentEvent.remove();
    calendarDiv.style.display = "block";
    document.getElementById('singleEvent').style.display = "none";  
    myCalendar.render();
}

function writeEventsP(){
    //TODO - fix the write events to have only the user's
    array = selfEvents; 
    console.log(array);
         
    allowInit = false;         
    firebase.database().ref('users/' + currentUser.luid).update(
      {
        
        calArray: newSelfEventsJSON        
      });
    //   localStorage.setItem("currentUser", JSON.stringify(currentUser));
}



function openUser(passedUserAppId){

  event.stopPropagation();  
  console.log(passedUserAppId.id);
  
  let tempChatIcon = document.getElementById(passedUserAppId.id).getElementsByClassName('fa-comment');
  console.log(tempChatIcon[0]);
    
  tempChatIcon[0].className = "chatIcon fa fa-comment";

  document.getElementById("singleUserPage").innerHTML='<object type="text/html" style="width:100vw; height:100vh;" data="../gse5/singleUser.html?id='+passedUserAppId.id+'"></object>';

  // let url="../gse5/singleUser.html?id="+passedUserAppId.id;
  // popupWindow = window.open(url,'popUpWindow','height=500,width=500,left=100,top=100,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no, status=yes').focus();
  var modal = document.getElementById("singleUser");  
  var span = document.getElementsByClassName("close")[2];
  // document.getElementById("sendOrdelete").innerHTML = "Delete Event";
  // document.getElementById("sendOrdelete").onclick = function(){
  //   deleteEvent(eventObj);
  // }
  modal.style.display = "block";

  // When the user clicks on <span> (x), close the modal
  span.onclick = function() {
    modal.style.display = "none";
  }

  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    if (event.target == modal) {
      // modal.style.display = "none";
    }
  }


}










function deleteEvent(){
  console.log(eventSingle)
  let eventObj = eventSingle;
  if (eventObj.extendedProps.acceptGuest == "booked"){
    let answer= confirm("This is a confirmed event!\nAre you sure you want to delete this event?\nIf you do, the event will be cancelled \nand a message will be sent to the other person!")
    
    if (answer ==false){ //cancel deletion
      return;
    }
    else{
      let requestingUserId = eventSingle.extendedProps.requestby;
      
      //GET REQUESTOR EMAIL
      firebase.database().ref('/users/'+requestingUserId).once('value').then(function(snapshot){
    
        userEmail = snapshot.val().email;
        nameTosend = snapshot.val().name;
    
        //open Text
        let textAreaField = document.getElementById("textAreaField");
        let eventDate = moment(eventSingle.start).format("dddd, MMMM Do YYYY, h:mm:ss a");
    
        let mailBody = "Hello " + nameTosend + ".\n " + currentUser.name + " has deleted the event on "+ eventDate + 
                        ". The request has been updated in your calendar";
    
          if (textAreaField.value.length >0){
            mailBody += "\n \n A message was sent as well: \n"+textAreaField.value;
            textAreaField.value = "";
          }
          // console.log(mailBody);       
          
          Email.send({
              Host: "smtp.ipage.com",
              Username : "roi@roiwerner.com",
              Password : "Roki868686",
              To : userEmail,
              From : "<roi@roiwerner.com>",
              Subject : "Session deleted",
              Body : mailBody,
              }).then(
                message => alert("mail sent successfully")
            ); 
      
          //--update the reqested event on the requestBy side
          
          var tempArray = snapshot.val().calArray
          console.log(tempArray);
        
    
          for (e in tempArray){
            let element = JSON.parse(tempArray[e])
            // console.log(element.id + ":" + eventSingle.id);
              if(element.id == eventSingle.id){
                // IN CASE I WANT TO CHNAGE THE EVENT FOR THE REQUESTER TO FREE TIME?
                // element.title = "Confirmed by "+currentUser.name + " " + currentUser.lastName;
                // element.backgroundColor = "red";
                // element.extendedProps.acceptGuest = "booked";
                // element.extendedProps.approvedBy = currentUser.luid;
                // tempArray[e] = JSON.stringify(element);
                tempArray.splice(e,1);
                // console.log("tempArray ",tempArray);
                
                  firebase.database().ref('/users/'+requestingUserId).update({
                    calArray: tempArray
                  });
                break;        
              }      
          }
      });
  
    }
  }

  else if(eventSingle.extendedProps.acceptGuest == "waiting"){
    let answer= confirm("This event is waiting confirmation, if you delete it, the request will be deleted.");
    
    if (answer ==false){ //cancel deletion
      return;
    }
    //delete the request
    let requestKey = eventSingle.extendedProps.reqKey;
    console.log(requestKey);
    firebase. database().ref('/requests/'+requestKey).remove();    
  }
  else{
    let answer= confirm("Are you sure you want to delete this event?")
    if (answer ==false){ //CANCEL DELETION
      return;
    }
  }
  
    
    console.log("delete Event: " + eventObj.id);
    
     
    
    for(e in newSelfEventsJSON){
      let tempvar = JSON.parse(newSelfEventsJSON[e]);
      // console.log(tempvar.id);
      if (tempvar.id == eventObj.id){
        console.log("event found at indes: " + e);
        newSelfEventsJSON.splice(e ,1);     
        break;
        
      }
    }  
    console.log(newSelfEventsJSON);
    allowInit = false;
    firebase.database().ref('users/' + currentUser.luid).update(
      {        
        calArray: newSelfEventsJSON            
      });
    writeEventsP();
    backToCal();
    
    // REMOVE THE 2 EVENTS WITH THE SAME ID BECASUE OF CONFIRMATION!
    var eventTodelete = myCalendar.getEventById(eventObj.id);
    eventTodelete.remove();
    var eventTodelete1 = myCalendar.getEventById(eventObj.id);
    eventTodelete1.remove();    
    let allevents = myCalendar.getEvents();
    allevents.forEach(el => { el.remove(); });            
    myCalendar.addEventSource(allevents);
}



var tempFilteredEvents = [];
//------------- TOGGLE USER SELECTION ------------------//

function filterOne(appId){
  console.log("filterOne");
  
  // if (calAllEvents.length==0){
  //   calAllEvents = myCalendar.getEvents();
  // }


  // if (showMyself)
   
  //   console.log(calAllEvents);

    // console.log("filter one:" ,appId);
    console.log(tempEventForInterest);
    
  var newFilteredArray =  tempEventForInterest.filter(function(filter) {
  return filter.extendedProps.appId == appId;
    });
  console.log(newFilteredArray);
  
  if (selectedUsers.length>1){

    console.log("more then 1 user");    
    sortedEventsArray = sortedEventsArray.concat(newFilteredArray);
    console.log("sortedEventsArra 1: ",sortedEventsArray);
    //console.log("filter call 1");
    tempFilteredEvents = sortedEventsArray;
    // filterCal(sortedEventsArray);  
  
    
  }
  else{
    console.log("first selected user");
    
      sortedEventsArray = newFilteredArray;
      tempFilteredEvents = sortedEventsArray;
      //console.log("sorted array: ",sortedEventsArray);
      //console.log("filter call 2");
      console.log(selfEvents);
        
      console.log("sortedEventsArra 2: ",sortedEventsArray);
      // filterCal(sortedEventsArray);
      
      
  }
  
  // let SortedEventWithSelf = sortedEventsArray.concat(selfEvents);
  filterCal(sortedEventsArray);

}
sortedEventsArray = [];

function unfilterOne(appId){
console.log("unfilterOne");

    
  var newFilteredArray =  sortedEventsArray.filter(function(filter) {
  return filter.extendedProps.appId == appId;
  });
  // //console.log(newFilteredArray);
  for(g in newFilteredArray){
    var tempFilteredEvent = newFilteredArray[g];
    sortedEventsArray.splice( sortedEventsArray.indexOf(tempFilteredEvent), 1 );
      // sortedEventsArray = sortedEventsArray.concat(JSON.parse(tempFilteredEvent));
  }
  console.log("sortedEventsArra 3: ",sortedEventsArray);
      //console.log("filter call 3");
      // let SortedEventWithSelf = sortedEventsArray.concat(selfEvents);
      filterCal(sortedEventsArray);
}

function toggleAllUserSelection(){
  //--check if any users are filtered
  console.log("selectedUsers length: ", selectedUsers.length);
  //no users are filtered
    if (selectedUsers.length == 0){
      return;
    
  }
  
    filterCal(tempEventForInterest);  
    
 
  
  // filterCal(calAllEvents)

  

  //show the events based on the tab selected


  //load the relevent events only
  
  // clear all users selction eyes and color
  tempDiv = document.getElementsByClassName("user_row");
  for (let l = 0; l < tempDiv.length; l++) {    
    let element = tempDiv[l];
    // console.log(element);
    
    element.style.backgroundColor = "";
    var tempButton = document.getElementById('toggleUserSelection'+element.id);        
    tempButton.className = "fa fa-eye-slash";

  }
  selectedUsers = [];
}

function keepSelectedUsersOn(){
  console.log("keepSelectedUsersOn");
  
  for (let index = 0; index < selectedUsers.length; index++) {
    
    console.log(index);
    
    const element = selectedUsers[index];
    console.log(element);
    tempDiv = document.getElementById(element);
    if(tempDiv == null){

      //selected user does not exsit here, so show all
      filterCal(tempEventForInterest);

    }else{
      console.log(tempDiv);
      tempDiv.style.backgroundColor = "lightGrey";
      var tempButton = document.getElementById('toggleUserSelection'+element);        
      tempButton.className = "fa fa-eye";
    }    
  }
}

function toggleUserSelection(number){
  
  console.log("toggleUserSelection" + number);
  tempDiv = document.getElementById(number);
  // //console.log(tempDiv);
  // //console.log("selectedUsers: ",selectedUsers);
  if (tempDiv.style.backgroundColor != ""){
    tempDiv.style.backgroundColor = "";
    var tempButton = document.getElementById('toggleUserSelection'+number);        
    tempButton.className = "fa fa-eye-slash";
    selectedUsers.splice( selectedUsers.indexOf(number), 1 );
    //console.log(selectedUsers);
    if (selectedUsers === undefined || selectedUsers.length == 0){        
      filterCal(tempEventForInterest)              
    }
    else{
      unfilterOne(number);
    }
  }
  else{
    //console.log("filter only user: ",number);
    
    selectedUsers = selectedUsers.concat(number);
    //console.log("selectedUsers: " + selectedUsers);
    tempDiv.style.backgroundColor = "lightGrey";
    var tempButton = document.getElementById('toggleUserSelection'+number);        
    tempButton.className = "fa fa-eye";
    // "<button class='btn' id='toggleUserSelection" + fbUserAppIdTrimed + "' onclick='toggleUserSelection(" + fbUserAppId + ")'>"+
    //   "<i class='far fa-eye' aria-hidden='true'></i></button>"+


    filterOne(number);
  }

}


function toggleFavorite1(userAppid){
  event.stopPropagation();
  tempFavIcon = document.getElementById("toggleFavorite1"+userAppid);
  //console.log("Toggle favs from Icon " + userAppid +"with value: "+ tempFavIcon.className);
  
  if (showFavsOnly === true){
    tempDiv = document.getElementById(userAppid);
    //console.log(tempDiv);
    tempDiv.style.display = "none";
    const index = myFavArray.indexOf(userAppid);
      if (index > -1) {
        myFavArray.splice(index, 1);
      }
  }
  else{
    //--check if user is a fav already
    if (tempFavIcon.className == "favIcon fa fa-star"){ //not a fav yet
      tempFavIcon.className = "favIcon fa fa-heart";
      if (typeof myFavArray === 'undefined' || myFavArray === null) {
        myFavArray = [];
      }
      myFavArray = myFavArray.concat(userAppid); 
    }
    else{ //already a fav
      tempFavIcon.className = "favIcon fa fa-star";
      const index = myFavArray.indexOf(userAppid);
      if (index > -1) {
        myFavArray.splice(index, 1);
      }
    }
    //console.log("favoritesArray: " + myFavArray);
    writeFavsToFB();
    
  }
}

function writeFavsToFB(){
  // array = myCalendar.getEvents();
  // jasonArray = JSON.stringify(array);
  // //console.log(currentUser.luid + " " + favoritesArray);
  currentUser.favoritesArray = myFavArray;
  firebase.database().ref('users/' + currentUser.luid).update(
    {
      favoritesArray: myFavArray
      // test: "passed"
    });
    localStorage.setItem("currentUser", JSON.stringify(currentUser));

}

var eventsToBuildArray_cache = [];


function filterCal(eventsToBuildArray){
  // console.log("F I L T E R  C A L :", showMySelfCheck);
  // console.log(selfEvents)
  
  eventsToBuildArray_cache = JSON.stringify(eventsToBuildArray);
  console.log("eventsToBuildArray_cache2: ",eventsToBuildArray_cache);

  //console.log("eventsToBuildArray: ",eventsToBuildArray);
  //if show self is on:
  if (showMySelfCheck == true){
    console.log("add myself to events");
    console.log(newSelfEvents);
    console.log(newSelfEventsJSON);
    
    
    eventsToBuildArray = eventsToBuildArray.concat(newSelfEvents);
    console.log("eventsToBuildArray added: ",eventsToBuildArray);
    
  
  }
  else{
    console.log("don't add myself to events");
    // eventsToBuildArray = eventsToBuildArray.splice(selfEvents);
    eventsToBuildArray = eventsToBuildArray.filter( x => !newSelfEvents.filter( y => y.id === x.id).length);
    // eventsToBuildArray_cache = eventsToBuildArray_cache.filter( x => !newSelfEvents.filter( y => y.id === x.id).length);

  }
  
  const unique = Array.from(new Set(eventsToBuildArray.map(JSON.stringify))).map(JSON.parse);

  // const unique = [...new Map(eventsToBuildArray.map(item => [item[key], item])).values()];
  console.log(unique);
  
  // myCalendar.addEventSource(eventsToBuildArray)
  let allevents = myCalendar.getEvents(); 
  allevents.forEach(el => { el.remove(); })
  myCalendar.addEventSource(unique);

  // showAllFavs();
  
  // toggleAllFavsSelection();
  // console.log(runShowmyself);
  // if (runShowmyself == 1){
  //   // console.log("changing runShowmyself to 2");
  //   // runShowmyself=2;
  //   showMyself();
  // }
  
  // myCalendar.refetchEvents();  
  // console.log(myCalendar.getEvents());
  
  $('#loading').hide();
    
   
}

  

  


function toggleAllFavsSelection(){

  var toggleAllFavB = document.getElementById("toggleFavsOnly");
  var allCheckFavBox = document.getElementById('external-events').getElementsByClassName("favIcon");

  if (showFavsOnly == false){ //show only favorites 
    toggleFavsOnly.innerHTML = "show all users"
    //console.log("ToggleFavsOnly false");
    showFavsOnly = true; 
    for (i = 0; i < allCheckFavBox.length; i++){
      allCheckFavBox[i].parentElement.style.display = "none";
      // //console.log("allCheckFavBox: " + i +" "+allCheckFavBox[i].checked);      
      if(allCheckFavBox[i].className == "favIcon fa fa-heart"){
        allCheckFavBox[i].parentElement.style.display = "block";
      }         
    }
  }
  else{
    toggleFavsOnly.innerHTML = "show only favs"
    showFavsOnly = false;  
    
    i = 0;
    var tempFavPeople = [];
    for (i = 0; i < allCheckFavBox.length; i++){
      // //console.log("tempElement: " + i +" "+tempElement);
      // //console.log("allCheckFavBox: " + i +" "+allCheckFavBox[i].checked);            
        allCheckFavBox[i].parentElement.style.display = "block"; 
    }
  }
    
  showAllFavs();
  
}
var tempAllEvents=[];


function showAllFavs(){
  var tempAllFavEvents=[];
  console.log("toggle All Favs: ",showFavsOnly);
  if (tempAllEvents.length == 0){
    tempAllEvents = myCalendar.getEvents();
  }
  console.log("found this tempAllEvents: ",tempAllEvents);
  

  console.log("showFavsOnly: ",showFavsOnly);
  if (showFavsOnly == true){ //show only favorites    
        
    // tempAllEvents   
    for(ev in tempAllEvents){
      //console.log(tempAllEvents[ev].extendedProps.appId);
      for (j in currentUser.favoritesArray){
        // //console.log(currentUser.favoritesArray[j]);
        
        if (currentUser.favoritesArray[j] == tempAllEvents[ev].extendedProps.appId || currentUser.appId ==  tempAllEvents[ev].extendedProps.appId){
          // //console.log("there is a match");
          tempAllFavEvents.push(tempAllEvents[ev]);
          break;          
        }
      } 
    }
    console.log("use this tempAllEvents: ",tempAllFavEvents);
  }
  else{
    tempAllFavEvents = tempAllEvents;
    // if (tempAllFavEvents.length>0){
    //   console.log("use this tempAllEvents: ",tempAllFavEvents);

    // }
    // else{
      
    // }
    // let tempAllEvents = myCalendar.getEvents()
    //console.log(tempAllFavEvents);
    // var tempAllEvents = JSON.parse(localStorage.getItem("tempAllEvents"));
    // //console.log(tempAllEvents);
    
    //console.log("ToggleFavsOnly true");
    // let allevents = myCalendar.getEvents(); 
    // allevents.forEach(el => { el.remove(); })
    // myCalendar.addEventSource(tempAllEvents);
    // tempAllEvents=;
    // tempAllFavEvents=[];
    //console.log(tempAllEvents); 

    
  }

  let allevents = myCalendar.getEvents(); 
    allevents.forEach(el => { el.remove(); })
    myCalendar.addEventSource(tempAllFavEvents);
    // myCalendar.refetchEvents();
    console.log("shoud see");
    
}


var showMySelfCheck = true;
var eventsWithMyself = [];
var hideOthersCheck = false;
var eventsBeforeHideOthers = [];

function respondToHideOtheresClick(){
  console.log("HIDE OTHERS TOGGLE");
  console.log("eventsBeforeHideOthers ",eventsBeforeHideOthers);
  
  
  console.log("eventsToBuildArray_cache: ",eventsToBuildArray_cache);
  var hideOthersButton = document.getElementById("hideOthers");
  if (hideOthersCheck == true){
    // console.log());
    
    hideOthersCheck = false;      
    hideOthersButton.innerText="hide others";   
    filterCal(JSON.parse(eventsBeforeHideOthers));         
  }
  else{
    console.log("false");
    eventsBeforeHideOthers = eventsToBuildArray_cache;
    console.log("eventsBeforeHideOthers ",eventsBeforeHideOthers);
    hideOthersCheck = true;
    hideOthersButton.innerText="Show others";
    filterCal(newSelfEvents);
  }
  
  
  // showMyself();
}

function showMyself(){
    tempUsersResourcesByInterestArray = [];
    tempEventsFromResources = [];
      
    var allResources = myCalendar.getResources();
    for(e in allResources) {
      allResources[e].remove();
    }

    resource = 
              {
                id:   currentUser.appId,
                title: currentUser.name + " " + currentUser.lastName
              }
    
    myCalendar.addResource(resource);

    tempUsersResourcesByInterestArray.push({
      key:   currentUser.appId,
      value: currentUser.name + " " + currentUser.lastName
    }); 
  
    
    // tempEventsFromResources.push(child.val().calArray);
    
      
      for(e in  currentUser.calArray){
        let elem = currentUser.calArray[e];
        tempEventsFromResources.push(JSON.parse(elem));
      }
     
          
    console.log(tempEventsFromResources);
    console.log(tempUsersResourcesByInterestArray);
    populateUsersTablePC1(tempUsersResourcesByInterestArray);
    let allEventsHere = myCalendar.getEvents()
    for(e in allEventsHere ){
      allEventsHere[e].remove();
    }
    myCalendar.addEventSource(tempEventsFromResources);
} 


function respondToshowMySelfClick(){
  var showSelfButton = document.getElementById("showSelf");
  if (showMySelfCheck == true){
    showMySelfCheck = false;      
    showSelfButton.innerText="Show myself";            
  }
  else{
    showMySelfCheck = true;
    showSelfButton.innerText="Hide myself";
  }
  
  console.log("eventsToBuildArray_cache: ",eventsToBuildArray_cache);
  showMyself();
}
  
function showMyself1(){
  let tempa = JSON.parse(eventsToBuildArray_cache);
  console.log(tempa);
  
  console.log(typeof(tempa));
  console.log(newSelfEventsJSON);
  console.log(typeof(newSelfEventsJSON));
  
  
  if(showMySelfCheck==false){

    tempa = tempa.filter( x => !newSelfEvents.filter( y => y.id === x.id).length);



    // eventsToBuildArray_cache = eventsToBuildArray_cache.filter(function(x) { 
    //   return selfEvents.indexOf(x) < 0;
    
    console.log(tempa);
    
  }
  else{
    // eventsToBuildArray_cache = eventsToBuildArray_cache.concat(selfEvents);
    console.log(tempa);
  }
  
  
  
  filterCal(tempa);            
}


function AddEventManually(){

  //response to clicking "add event"
  console.log("AddEventManually");
  
  
  $('#datetime12').combodate({
    minYear: 2020,
    maxYear: 2022,
    smartDays: true,    
  });
  let ct = moment().format('DD-MM-YYYY')
  console.log(ct);
  
   
  $('#datetime12').combodate('setValue', ct);
  $('#datetime13').combodate('setValue', moment().format('hh:mm A'));
  $('#datetime14').combodate('setValue', moment().format('hh:mm A'));

  var modal = document.getElementById("addEvent");  
  var span = document.getElementsByClassName("close")[1];  
  
  
  modal.style.display = "block";
  // When the user clicks on the button, open the modal
  // btn.onclick = function() {
  //   modal.style.display = "block";
  // }

  // When the user clicks on <span> (x), close the modal
  span.onclick = function() {
    console.log("close");
    
    modal.style.display = "none";
  }

  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    if (event.target == modal) {
      modal.style.display = "none";
    }
  }

}

function writeManualEvent(){
    //get all the events and save them
    let tmpAllEventsFromCal = myCalendar.getEvents();

      
    //verify time input 
    let tempDate = $('#datetime12').combodate('getValue');
    // console.log(tempDate);
    // console.log(moment(tempDate)format('YYYY-DD-MMMM'));
    
    
    let tempStart = $('#datetime13').combodate('getValue');
    // console.log(tempDate + " " + tempStart);
    
    let startTime = moment(tempDate + " " + tempStart);
    // console.log(startTime.format('YYYY-DD-MMMM'));
    
    // var startTime = moment(tempStart).format('MM DD YYYY') + ' ' + moment(tempStart, "HH:mm a");
    var t2 = moment(startTime).format();
    console.log(t2);
    t1 = moment(t2).format('YYYY-DD-MM')+t2.slice(10);
    

    let tempEnd = $('#datetime14').combodate('getValue');
    var endTime = moment(tempDate + " " + tempEnd);
    var t3 = moment(endTime).format();
    // console.log(t3);
    // console.log(t3.slice(10));
    t4 = moment(t3).format('YYYY-DD-MM')+t3.slice(10);
    console.log(t1 + " / " + t4);
    
    
    if(startTime.isAfter(endTime)){
      console.log("oops");
      alert("Please set a proper start and end time.")
    }
    else if (endTime.isAfter(startTime)){
        console.log("time is ok");
               
        
        let r = Math.random().toString(36).substring(2);
        var allowGuest = false;
        var bgColor = color_normal_me;
        if (document.getElementById('acceptGuest_default').checked==true){
          allowGuest = true;
          bgColor = color_guest_me;
        }

              
        //delete all the events from the cal
        let allevents = myCalendar.getEvents(); 
        allevents.forEach(el => { el.remove(); })
        
        //creat the new event
        var event1 =({
                resourceId: currentUser.appId,
                id: r,
                title: currentUser.name + " " +currentUser.lastName,
                start: t1,
                end: t4,
                allDay: false,
                editable: true,
                
                extendedProps:{
                  acceptGuest : allowGuest,
                  appId: currentUser.appId,
                  auther: currentUser.name,
                  droppable: true
                },
                backgroundColor: bgColor                
              });
        console.log(myCalendar.getEvents());
              
        //add the event to calendar
        myCalendar.addEvent(event1);
        let singleEvent = myCalendar.getEvents;
        console.log(myCalendar.getEvents());
        
        // selfEvents.push (JSON.stringify(event1));
        selfEvents=selfEvents.concat(event1);
        tmpAllEventsFromCal=tmpAllEventsFromCal.concat(singleEvent);        
        myCalendar.addEventSource(tmpAllEventsFromCal); 
        
        //write the event to fb
        writeEventsP();

        var modal = document.getElementById("addEvent");
        modal.style.display = 'none';
    }
    else {
      console.log("efqueel");
      alert("Please set a proper start and end time.")
      
    }
}

function convert(date){
  console.log("convert");
  
  var datearray = date.split("-");
  var newdate = datearray[2] + '-' + datearray[1] + '-' + datearray[0];

  return newdate;
  
}

function timeConversionSlicker(s) {
  let AMPM = s.slice(-2);
  let timeArr = s.slice(0, -2).split(":");
  if (AMPM === "AM" && timeArr[0] === "12") {
      // catching edge-case of 12AM
      timeArr[0] = "00";
  } else if (AMPM === "PM") {
      // everything with PM can just be mod'd and added with 12 - the max will be 23
      timeArr[0] = (timeArr[0] % 12) + 12
  }  
  return timeArr.join(":");
}

var eventsBeforeSearch = [];
function search(){


  

  eventsBeforeSearch = myCalendar.getEvents();
  console.log("search");
  var searchForm = document.getElementById("searchForm");
  
  //clear the search bar

  //find the user and display him
  var searchResult = document.getElementById("myInput").value;
  // const index = usersNamesArray.indexOf(searchResult);
  // console.log(index);

  var allDisplayedEvents = document.getElementsByClassName("user_row");
  for (i = 0; i < allDisplayedEvents.length; i++){
    console.log(allDisplayedEvents[i].id);
    console.log((allDisplayedEvents[i].textContent).replace('filterFavorite',''));
    let tempResult = (allDisplayedEvents[i].textContent).replace('filterFavorite','');
    allDisplayedEvents[i].style.display="none";
    if (searchResult == tempResult)
    {
      allDisplayedEvents[i].style.display="block";
      
      filterOne(allDisplayedEvents[i].id)
      searchForm.action = "javascript:cancelSearch("+allDisplayedEvents[i].id+")";
      
    }
    //--change looking glass to x and make into a cancel search function
    var searchB = document.getElementById("searchB");
    var cancelS = document.getElementById("cancelS");
    // searchB.classList.add("fa-ban");
    // searchB.onclick = "cancelSearch()";
    searchB.style.display = "none";
    cancelS.style.display = "";
    
    
  }
  // action="javascript:search()"
}




function cancelSearch(appId){
  console.log("cancel search ",appId.id);
  
  var searchB = document.getElementById("searchB");
  var cancelS = document.getElementById("cancelS");
  var searchForm = document.getElementById("searchForm");
  searchForm.action = "javascript:search()";
  
  console.log("cancael search");
  searchB.style.display = "";
  cancelS.style.display = "none";

  

  var allDisplayedEvents = document.getElementsByClassName("user_row");
  for (i = 0; i < allDisplayedEvents.length; i++){
    allDisplayedEvents[i].style.display="";
  }

  let allevents = myCalendar.getEvents(); 
  allevents.forEach(el => { el.remove(); })
  myCalendar.addEventSource(eventsBeforeSearch);
  // filterCal(eventsToBuildArray_cache);  
}


function toggleGuestsOnly(){
  console.log(selectedUsers.length + " toggleGuestsOnly ",isGuestsOnlyActive.checked );
  if (selectedUsers.length>0){
      console.log("few users")
      console.log("filter call 4");
      filterCal(sortedEventsArray);
  }
  else{  
    console.log('no users')  
    console.log("filter call 5");    
      filterCal(calAllEvents); 
      // console.log(calAllEvents)       
    }
}

var toggleGuestChangeinSingle = false;
function toggleGuest(){
  toggleGuestChangeinSingle = true;
  console.log("toggleGuest", eventSingle);
  console.log(myCalendar.getEvents());

  if (eventSingle.extendedProps.acceptGuest == true){
    eventSingle.backgroundColor = color_guest_me
    // eventSingle.setExtendedProp('acceptGuest', 'false');
  }
  else{
    eventSingle.backgroundColor = color_normal_me
    // eventSingle.setExtendedProp('acceptGuest', 'true');
  }
  // console.log(JSON.stringify(myCalendar.getEvents()));
  console.log("toggleGuest", eventSingle);
  console.log(myCalendar.getEvents());
  // myCalendar.addEvent(eventSingle);





}


function notifyMessageWaiting(snapshot){
  console.log("notifyMessageWaiting");
  let messageAuther = "";
  if (snapshot.val().creator == currentUser.appId){
    messageAuther = snapshot.val().to;
  }
  else{
    messageAuther = snapshot.val().creator
  }

  let tempChatIcon = document.getElementById(messageAuther).getElementsByClassName('fa-comment');
  console.log(tempChatIcon[0]);
  
  
    tempChatIcon[0].className = "chatIconOn fa fa-comment";
  
  

  
  //colr the chat icon of the relevant user in red
  //get the user
}

function backToCal(){   

    var requestedEvent = calendar1.getEvents();
    var origStartTime = moment(eventSingle.start);
    var newStartTime = moment(requestedEvent[0].start);
    var origEndTime = moment(eventSingle.end);
    var newEndTime = moment(requestedEvent[0].end);
    
    let checkOrigStart =  JSON.stringify(origStartTime); 
    let checkNewStart =  JSON.stringify(newStartTime); 
    let checkOrigEnd =  JSON.stringify(origEndTime); 
    let checkNewEnd =  JSON.stringify(newEndTime); 

    if(checkOrigStart != checkNewStart || checkOrigEnd != checkNewEnd){
      let r = confirm ("A CHANGE HAS BEEN MADE, DO YOU WANT TO KEEP IT?");
          if (r == true){
            console.log("change event");
            editEvent();

          }
    }
    else{
      returnToCal();
    }
}

  function returnToCal(){  
        console.log("backToCal");           
        document.getElementById('calendarSingle').style.display = "none";
        document.getElementById('calendar').style.display = "block";
        document.getElementById('backToCal').style.display = "none";
        document.getElementById('requestEv').style.display = "none";
        document.getElementById('label_AG').style.display = "";
        document.getElementById('acceptGuest_default').style.display = "";
        document.getElementById('label_AG_singlePage').style.display = "none";
        document.getElementById('acceptGuest_singlePage').style.display = "none";
        document.getElementById('deleteEvent').style.display = 'none';
        document.getElementById('AddEventManually').style.display = "block";
        
        calendar1.destroy();

        //set the bg color and acceptguest if changed!
        console.log(toggleGuestChangeinSingle);
        if (toggleGuestChangeinSingle == true){
          toggleGuestChangeinSingle = false;
          console.log(eventSingle.extendedProps.acceptGuest);
          if(eventSingle.extendedProps.acceptGuest == false){
            
            eventSingle.setExtendedProp('acceptGuest', true);
            eventSingle.setProp('backgroundColor', color_guest_me);
          }
          else{
            eventSingle.setExtendedProp('acceptGuest', false);
            eventSingle.setProp('backgroundColor', color_normal_me);
          }
          console.log(newSelfEventsJSON);
          for (e in newSelfEventsJSON){
            let tempe = JSON.parse(newSelfEventsJSON[e]);
            console.log(tempe.id);
            if (tempe.id == eventSingle.id){
              console.log("tempe found");
              newSelfEventsJSON[e] = JSON.stringify(eventSingle);
              break;

            }
          }
          console.log(eventSingle.id);
          writeEventsP();
          
        }

        myCalendar.refetchEvents();
        myCalendarAlt.refetchEvents();
        
}





function requestEvent(){
  openTextModalPC();
}

function sendRequestEvent(){
  console.log("request event");
  console.log(eventSingle);
  
  
  if(eventSingle.extendedProps.appId == currentUser.appId){
    console.log("should go to edit");    
    editEvent();
    return;
  }


  console.log("requestEvent");
  var requestedEvents = calendar1.getEvents();
  var requestedEve = [];
  if(requestedEvents.length == 1){
    requestedEve = requestedEvents[0];
    requestedEve.title = currentUser.name +" " +currentUser.lastName;
    requestedEve.description = "";
    requestedEve.backgroundColor = color_guest_me;
    requestedEve.setExtendedProp('acceptGuest',false);
    requestedEve.setExtendedProp('appId',currentUser.appId);
    requestedEve.setExtendedProp('auther',currentUser.name + " " + currentUser.lastName);    
  }
  else{
    requestedEve = requestedEvents[1];
  }
  console.log(requestedEve);
  // requestEventId  = requestedEve.id;
 
  
  const origStartTime = moment(eventSingle.start);
  const newStartTime = moment(requestedEve.start);
  const origEndTime = moment(eventSingle.end);
  const newEndTime = moment(requestedEve.end);

  //add the event to both auther and me as an invisible event(or red), once it will be confirmed it, will show up.
 
  let UniqueKey = Math.random().toString(36).substring(2);

  
//--Get the User who created the event!
  allUsersSnapShot.forEach(function(child) { 
    // console.log(child.val().appId + " : " + eventSingle.extendedProps.appId);
    
    if(child.val().appId == eventSingle.extendedProps.appId){
      nameTosend = child.val().name;
      emailTosend = child.val().email;
      requestAppId = currentUser.appId;
      
      var tempEventsArray = child.val().calArray;
      tempEventsArray = tempEventsArray.filter(function(e){return e}); 
      
        // console.log(tempEventsArray);
        //get the specific event for confirmation process
        for (let index = 0; index < tempEventsArray.length; index++) {
          const element = JSON.parse(tempEventsArray[index]);          
            if(element.id == eventSingle.id){

              element.extendedProps.description = UniqueKey;
              tempEventsArray[index] = JSON.stringify(element);

              console.log("event found: ",element.id);
               
              console.log (child.key);
              // console.log (child.
              firebase.database().ref('users/' + child.key).once('value').then(function(snapp){
                console.log(snapp.val().calArray);
              });
              allowInit = false;
              firebase.database().ref('users/' + child.key).update({
                calArray: tempEventsArray
              });
              break;                                
          }        
        }      
    }                                       
  });
  
  firebase.database().ref('requests/'+UniqueKey).set(
    {       
      requestBy: currentUser.luid,      
      origEvent: JSON.stringify(eventSingle),
      requestedEvent: JSON.stringify(requestedEve),      
    }   
    ,function(error)
    {
      if (error) {
        alert (error);
      
        // The write failed...
      }
    }).then(() => {
      

      //send an email to the auther
      let mailBody = "Hello " + nameTosend + ".\n " + currentUser.name + " would like to book your offered session\n"+
"please follow this link to approve it\n"
+ "roiwerner.com/gse5/singleEvent.html?&key="+UniqueKey;
// id="+eventSingle.id+"&id2="+requestEventId+"&id3="+requestAppId+"

        let textAreaField = document.getElementById("textAreaField");        
        if (textAreaField.value.length >0){
          mailBody += "\n \n A message was sent as well: \n"+textAreaField.value;
          textAreaField.value = "";
        }

        console.log(mailBody);
        Email.send({
              Host: "smtp.ipage.com",
              Username : "roi@roiwerner.com",
              Password : "Roki868686",
              To : emailTosend,
              From : "<roi@roiwerner.com>",
              Subject : "Session booking",
              Body : mailBody,
              }).then(
                message => alert("mail sent successfully")
            ); 

    });

//console.log("send to: " + emailTosend +" from: " + currentUser.email + "event id: "+eventId);

  
  // var tempiJ = JSON.stringify(requestedEve);
  var tempi = requestedEve;
  tempi.backgroundColor = color_special;
  // tempi.extendedProps.acceptGuest = "waiting";
  tempi.title = "pending approval";
  
  // console.log(tempiJ.title);
  console.log(tempi.title);
  tempi.title = 'pending approval';
  console.log(tempi.title);
  // let r = Math.random().toString(36).substring(2);

  newEvent = {
    resourceId: currentUser.appId,
    title: "pending approval",
    start: tempi.start,
    end: tempi.end,
    id: tempi.id,                              
    backgroundColor: "purple",
    extendedProps:{
      acceptGuest : 'waiting',
      appId: currentUser.appId,
      auther: currentUser.name,
      reqKey: UniqueKey,
      droppable: false
    }
  };
  console.log(newEvent);
  // return;
  myCalendar.addEvent(newEvent);        
  // currentUser.calArray.push (JSON.stringify(requestedEvent[1]));
  // console.log(currentUser.calArray);
  newSelfEventsJSON=newSelfEventsJSON.concat(JSON.stringify(newEvent));
  console.log(newSelfEventsJSON);
  
    
  writeEventsP();    
  
  document.getElementById('calendarSingle').style.display = "none";
  document.getElementById('calendar').style.display = "block";
  document.getElementById('backToCal').style.display = "none";
  document.getElementById('requestEv').style.display = "none";
  document.getElementById('label_AG').style.display = "";
  document.getElementById('acceptGuest_default').style.display = "";
  calendar1.destroy();  
    
  let allevents = myCalendar.getEvents(); 
  allevents.forEach(el => { el.remove(); });
  myCalendar.addEventSource(allevents);
  
  //take the time from the event
  
}

function editEvent(){
  console.log("editevent");

  var requestedEvent = calendar1.getEvents();
  
  //delete Event
  // newSelfEventsJSON
  for(e in newSelfEventsJSON){
    let tempvar = JSON.parse(newSelfEventsJSON[e]);
    //console.log(tempvar.id);
    if (tempvar.id == eventSingle.id){
      //console.log("event found at indes: " + e);
      newSelfEventsJSON.splice(e, 1);      
      break;
      
    }
  }
  requestedEvent[0].extendedProps = eventSingle.extendedProps;
  newSelfEventsJSON.push (JSON.stringify(requestedEvent[0]));
          
  eventSingle.remove();

  myCalendar.addEvent(requestedEvent[0]);        
            
  writeEventsP();    
          
  document.getElementById('calendarSingle').style.display = "none";
  document.getElementById('calendar').style.display = "block";
  document.getElementById('backToCal').style.display = "none";
  document.getElementById('requestEv').style.display = "none";
  calendar1.destroy();  
    // }
  let allevents = myCalendar.getEvents(); 
  allevents.forEach(el => { el.remove(); });
  myCalendar.addEventSource(allevents);
  returnToCal();
}




function test(){
  console.log("test");
  
}


function openTextModalPC(message){
  var modal = document.getElementById("textArea");  
  var span = document.getElementsByClassName("closeText")[0]; 
  modal.style.display = "block";

  // When the user clicks on <span> (x), close the modal
  span.onclick = function() {
    modal.style.display = "none";
  }

  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    if (event.target == modal) {
      // modal.style.display = "none";
    }
  }

}


function submitPC(){
   
  console.log("submit");
  var modal = document.getElementById("textArea");  
  modal.style.display = "none";
  
    sendRequestEvent();    
}

function clearTextPC(){  
  console.log("clearText");
  let textAreaField = document.getElementById("textAreaField");
  console.log(textAreaField.value);
  textAreaField.value = "";
}
var foiList = ["hypnosis", "nlp", "breath"];
// var valueList = "";
// valueList.addEvent(input, function(){
//   console.log(document.get_events('foiSelector1')[0]);
// })
 
function buildFOISelector(){
  

  var dynamicSelect = document.getElementById("foiSelector1");
  let filtered=foiList.filter((a,i)=>i%2===1);
  foiList.forEach(function(item)
  {
    
          var newOption = document.createElement("option");
          newOption.text = item;//item.whateverProperty
          dynamicSelect.appendChild(newOption);
  });  

  var mySelect = document.getElementById("foiSelector1");
 mySelect.onchange = (event) => {
     var fieldName = event.target.value;
     console.log(fieldName);
 
     
      console.log(fieldName.id);
          if (fieldName == "All_as_geusts"){
        
          }
          else{        
              // var i, tabcontent, tablinks;
              // tabcontent = document.getElementsByClassName("tabcontent");
              // for (i = 0; i < tabcontent.length; i++) {
              //   tabcontent[i].style.display = "none";
              // }
              // tablinks = document.getElementsByClassName("tablinks");
              // for (i = 0; i < tablinks.length; i++) {
              //   tablinks[i].className = tablinks[i].className.replace(" active", "");
              // }
              // // document.getElementById(fieldName.id).style.display = "block";
              // evt.currentTarget.className += " active";  
          
            filterResourcesFOI(fieldName);
              // filterCurrentInterest(fieldName)    
          }
    }
}





//================== SETTINGS =================//
 function settings(){
  var modal = document.getElementById("settingsModal");  
  var span = document.getElementsByClassName("closeSet")[0];
  
  modal.style.display = "block";
  modal.style['pointer-events'] = 'auto';
  document.body.style.overflow = 'hidden';
  document.body.style['pointer-events'] = "none";

  // When the user clicks on <span> (x), close the modal
  span.onclick = function() {
    modal.style.display = "none";
    document.body.style.overflow = 'auto';
    document.body.style['pointer-events'] = 'auto';
  }

 }
 
 var displayMode = 0;
 function changeDisplayMode(){
   console.log("changeDisplayMode");
   let currnetView = myCalendar.view.type;
   console.log(currnetView);
   if (displayMode == 1){
      displayMode = 0;
      
      document.getElementsByClassName("fc-timeGridDay-button")[0].style.display = "";
      document.getElementsByClassName("fc-timeGridWeek-button")[0].style.display = "";
      document.getElementsByClassName("fc-dayGridMonth-button")[0].style.display = "";
      document.getElementsByClassName("fc-resourceTimelineDay-button")[0].style.display = "none";
      document.getElementsByClassName("fc-resourceTimelineWeek-button")[0].style.display = "none";
      document.getElementsByClassName("fc-resourceTimelineMonth-button")[0].style.display = "none";
      if(currnetView == "resourceTimelineDay"){
        document.getElementsByClassName("fc-timeGridDay-button")[0].click();
      }
      else if(currnetView == "resourceTimelineWeek"){
        document.getElementsByClassName("fc-timeGridWeek-button")[0].click();
      }
      else{
        document.getElementsByClassName("fc-dayGridMonth-button")[0].click();
      }
      
   }
   else{
      displayMode = 1;
      document.getElementsByClassName("fc-timeGridDay-button")[0].style.display = "none";
      document.getElementsByClassName("fc-timeGridWeek-button")[0].style.display = "none";
      document.getElementsByClassName("fc-dayGridMonth-button")[0].style.display = "none";
      document.getElementsByClassName("fc-resourceTimelineDay-button")[0].style.display = "";
      document.getElementsByClassName("fc-resourceTimelineWeek-button")[0].style.display = "";
      document.getElementsByClassName("fc-resourceTimelineMonth-button")[0].style.display = "";
      

      if(currnetView == "timeGridDay"){
        document.getElementsByClassName("fc-resourceTimelineDay-button")[0].click();
      }
      else if(currnetView == "timeGridWeek"){
        document.getElementsByClassName("fc-resourceTimelineWeek-button")[0].click();
      }
      else{
        document.getElementsByClassName("fc-resourceTimelineMonth-button")[0].click();
      }
      // resourcesCSS();
   }
 }


 function openUserFromResource(someting){
   console.log("openUserFromResource", someting);
   console.log(usersResourceList[someting]);
 }


