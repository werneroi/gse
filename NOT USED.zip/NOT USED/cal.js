document.addEventListener('DOMContentLoaded', function() {  
  let today = new Date().toISOString().slice(0, 10)
  
  var calendarEl = document.getElementById('calendar');
  
  myCalendar = new FullCalendar.Calendar(calendarEl, {    
    now: today,    
    aspectRatio: 1.8,    
    initialView: 'timeGridWeek',    
    selectMinDistance: 15,
    events: [
      {
        title: 'TEST1',
        start: '2020-10-16T10:30:00',
        end: '2020-10-16T13:30:00',
      },
      {
        title: 'Test2',
        start: '2020-10-18T10:30:00',
        end: '2020-10-18T13:30:00',
      },
      {
        title: 'Test3',
        start: '2020-10-18T14:30:00',
        end: '2020-10-18T16:30:00',
      }
    ],
    
    eventDidMount: function(arg){
      console.log("call eventMount from calendar");
      eventMount(arg);            
    },

  });   
  myCalendar.render();
  myCalendar.scrollToTime('09:00');  
});


function eventMount(arg){
  console.log(arg.event.title);
  arg.event.setProp('title',"name changed");
  arg.event.setProp('backgroundColor','#666666');  
}








