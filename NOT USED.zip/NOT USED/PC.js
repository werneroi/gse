var currentUser = JSON.parse(localStorage.getItem("currentUser"));
allUsersNamesArray = [];
calAllEvents = [];
selectedUsers = [];
fbAllEvents = [];
myCalendar = FullCalendar;
var showFavsOnly = false;

var singleEventOriginalStart = "";
var singleEventOriginalEnd = "";

var currentdate = new Date();
var datetime = "Last Sync: " + currentdate.getDay() + "/" + currentdate.getMonth() 
+ "/" + currentdate.getFullYear() + " @ " 
+ currentdate.getHours() + ":" 
+ currentdate.getMinutes() + ":" + currentdate.getSeconds();

color_main = '#4ca8b8';
color_guest = '#18535e';
color_special = 'red';
color_normal_me = '#6aa059';
color_guest_me = '#285e18';

var showMySelfCheck = true;


document.addEventListener('DOMContentLoaded', function() {
    console.log("build cal 2");
    
    //create tabs according to the user field of interest.
    createTabsNamesByInterest();
    
    isGuestsOnlyActive = document.getElementById('guestOnly');

    //enable 'ENTER' on search
    var input = document.getElementById("myInput")
    input.addEventListener("keyup", function(event) {
    // Number 13 is the "Enter" key on the keyboard
      if (event.keyCode === 13) {
        // Cancel the default action, if needed
        event.preventDefault();
        // Trigger the button element with a click
        document.getElementById("searchB").click();
      }
    });
  // InitCal(); is called from Init!
         
});

function createTabsNamesByInterest (){
    let localFieldsOfInterest = [];
    for (i in currentUser.fieldsOfinterest){
      localFieldsOfInterest.push(currentUser.fieldsOfinterest[i]);
    }
    localFieldsOfInterest.push("All_as_guest");
    
    htmlString = '';
    tabsString = '';
    //console.log("create tabs local " + localFieldsOfInterest);
    //console.log("create tabs " + currentUser.fieldsOfinterest);
    
    for (i in localFieldsOfInterest){
        activeString = '';
        if(i == 0){
          activeString = " active";
        }
        currentField = localFieldsOfInterest[i]
        htmlString += "<button class='tablinks " + activeString + "' onclick='openTab(event, " +currentField + ")'>" + currentField + "</button>"
        tabsString += "<div id=" + currentField + " class='tabcontent'><h3>" + currentField + "</h3><div  id='allUsersDisplay'></div></div>"
    }
    htmlData = "<div id='tableTabsByInterest' class='tab'>"+htmlString+"</div>"+tabsString;
    document.getElementById("tabsNav").innerHTML = htmlData;
}
var newSelfEvents = [];
var newSelfEventsJSON = [];

function InitCal(){    
      
    console.log("create events database from snapShot");
    newSelfEvents = []; 
    newSelfEventsJSON =[];      
    var i =0;
    selfEvents = [];
    allUsersSnapShot.forEach(function(child) 
    {
                    
        //create a list of all users with out myself!
        
        let userFullName = child.val().name + " " + child.val().lastName
        if (child.val().appId != currentUser.appId){
        // //console.log("found: "+ child.val().appId);
            allUsersNamesArray.push({
                key:   child.val().appId,
                value: userFullName
            });  
        }

        else{
          // selfEvents = JSON.stringify(child.val().calArray);
          // if (child.val().calArray){
            
            let tempChildArray = child.val().calArray;

            if(tempChildArray.length != 0){                                        
                                                
                var localSelfCalArray = child.val().calArray;                  
                var tempEvent = [];
                for(v in localSelfCalArray){
                  // console.log(tempEvent.id + " "+ tempEvent.backgroundColor);
                  // console.log(JSON.stringify(tempEvent));
                  
                  tempEvent = JSON.parse(localSelfCalArray[v])
                  if (tempEvent.backgroundColor == "orange"){
                    tempEvent.editable = false;
                    tempEvent.droppable = false;
                  }
                  else if (tempEvent.extendedProps.acceptGuest == true){
                    tempEvent.backgroundColor = color_guest_me;
                    tempEvent.editable = true;
                    tempEvent.droppable = true;
                  }
                  else{
                    tempEvent.backgroundColor = color_normal_me;
                    tempEvent.editable = true;
                    tempEvent.droppable = true;
                  } 
                  
                  //GETTING THE EVENT FROM THE FIREBASE
                  console.log(tempEvent);
                  console.log(typeof(tempEvent));
                //   console.log(JSON.stringify(tempEvent));
                  
                                
                  selfEvents = selfEvents.concat(tempEvent);
                  newSelfEventsJSON = newSelfEventsJSON.concat(JSON.stringify(tempEvent));
                  console.log(newSelfEventsJSON);
                  console.log(typeof(newSelfEventsJSON[0]));
                  newSelfEvents.push(tempEvent);
                  console.log(newSelfEvents);
                  console.log(typeof(newSelfEvents[0]));
                  
                  // currentUser.calArray = selfEvents;
            //       // console.log(fbAllEvents);
                  
            //       fbAllEvents = fbAllEvents.concat(JSON.stringify(tempEvent));                                 
                }
              }                                              
        }
          
        
        //once finished populate the users table and make the calendar
        i = i+1;
        if (i== allUsersSnapShot.numChildren()){      
          allEventsFromFBOrigin = fbAllEvents;
            eventsToBuildArray_cache = fbAllEvents;
            // populateUsersTablePC(allUsersNamesArray);
            makeCal(fbAllEvents);
            filterCurrentInterest(currentUser.fieldsOfinterest[0]);                 
        };                            
      });
}


function makeCal(fbAllEvents){
    console.log("makecal");  
      
      var initView = 'timeGridWeek';
      if (myCalendar.view){
        initView = myCalendar.view.type;
        myCalendar.destroy();
      }
      
      var calendarEl = document.getElementById('calendar');
      //console.log("STOPPPPP");
      myCalendar = new FullCalendar.Calendar(calendarEl, {
        
        // Calendar Option
        initialView: initView,
        allDaySlot: false,      
        views: {
          timeGridDay: {
              type: 'timeGrid',
              scrollTime: '09:00:00',
          },
          timeGridWeek: {
              type: 'timeGrid',          
              scrollTime: '09:00:00',
          },
          dayGridMonth: {
              
          }
        },
        firstDay: moment().format('e'),
        dragScroll: false,
        now: moment().format(),
        nowIndicator: true,  
        editable: false,
        droppable: false,           
        selectable: true,
        selectOverlap: true,
        eventOverlap: true,
        aspectRatio: 1.8,
        scrollTime: '09:00', // undo default 6am scrollTime
        headerToolbar: {
          left: 'today prev,next',
          center: 'title',
          right: 'timeGridDay,timeGridWeek,dayGridMonth'
        },
  
        //------------------------
        //event Options
        
        drop: function(arg) {
          //console.log(arg);
  
        },
        eventResizeStart: function(arg){
          //console.log("eventResizeStart: ========",arg);
          var eventObj = arg.event;
  
          if (eventObj.extendedProps.appId != currentUser.appId){
            //console.log("Not your event, can't touch this.");
            // arg.revert();
            return;
          }
          
        },
        eventDrop: function(arg) { // called when an event (already on the calendar) is moved
          
          console.log('eventDrop', arg.event);          
          var eventObj = arg.event;
          if (eventObj.extendedProps.appId != currentUser.appId){
            //console.log("Not your event, can't touch this.");
            
            arg.revert();
            return;
          }
          else
          {
            var eventEnding = moment(eventObj.end);            
            //--check if the current time clicked is before the end of event, if so allow to click, else do nothing.
            var timeClickedDate = Date.parse(moment().format('YYYY-MM-DD'));
            let endDate = Date.parse(eventEnding.format('YYYY-MM-DD'));
            if (timeClickedDate>endDate){
              //console.log("event is in the past");
              alert("You can not move an event in the past!");
              arg.revert();
              return;
            }
            else if (timeClickedDate == endDate){
              var timeClickedTime = moment().format('HH:mm:ss');
              let endTime = eventEnding.format('HH:mm:ss');              
              str1 =  timeClickedTime.split(':');
              str2 =  endTime.split(':');
    
              //console.log(timeClickedTime + " " + endTime);
    
              totalSecondsTimeClicked = parseInt(str1[0] * 3600 + str1[1] * 60 + str1[0]);
              totalSecondsEndtime = parseInt(str2[0] * 3600 + str2[1] * 60 + str2[0]);
              //console.log(totalSecondsTimeClicked + " " + totalSecondsEndtime);
              if (totalSecondsTimeClicked > totalSecondsEndtime ){
                //console.log("event is in the past");
                alert("You can not move an event in the past!");
                return;
              }
              else{
                //console.log("event is in the future");
              }          
            } 
            for (let index = 0; index < newSelfEventsJSON.length; index++) {
                var element = JSON.parse(newSelfEventsJSON[index]);
                console.log(element.id + " / "  + eventObj.id);                
                if(element.id == eventObj.id){
                    console.log("found event - ", element);
                    console.log(eventObj.end);
                    
                    element.start = moment(eventObj.start);
                    element.end = moment(eventObj.end);

                    newSelfEventsJSON[index] = JSON.stringify(element);
                    console.log(JSON.parse(newSelfEventsJSON[index]));                    
                    break;
                }                
            }

            writeEventsP();
          }
        },
  
        eventResize: function(info) {
          console.log("Resize event: " ,info);
  
          var eventObj = info.event;
          if (eventObj.extendedProps.appId != currentUser.appId){
            //console.log("Not your event, can't touch this.");
            info.revert();
            return;
          }
          else
          {  
            var eventEnding = moment(eventObj.end);
                          
            //--check if the current time clicked is before the end of event, if so allow to click, else do nothing.
            var timeClickedDate = Date.parse(moment().format('YYYY-MM-DD'));
            let endDate = Date.parse(eventEnding.format('YYYY-MM-DD'));
            if (timeClickedDate>endDate){
              //console.log("event is in the past");
              alert("You can not edit an event in the past!");
              info.revert();
              return;
            }
            else if (timeClickedDate == endDate){
              console.log("same day");
              
              var timeClickedTime = moment().format('HH:mm:ss');
              let endTime = eventEnding.format('HH:mm:ss');

              str1 =  timeClickedTime.split(':');
              str2 =  endTime.split(':');
    
              //console.log(timeClickedTime + " " + endTime);
    
              totalSecondsTimeClicked = parseInt(str1[0] * 3600 + str1[1] * 60 + str1[0]);
              totalSecondsEndtime = parseInt(str2[0] * 3600 + str2[1] * 60 + str2[0]);
              //console.log(totalSecondsTimeClicked + " " + totalSecondsEndtime);
              if (totalSecondsTimeClicked > totalSecondsEndtime ){
                //console.log("event is in the past");
                alert("You can not edit an event in the past!");
                return;
              }                   
            }
            // else{

            //     //deal with updating event:
                
            //     //console.log("event is in the future");
            //   }     

            for (let index = 0; index < newSelfEventsJSON.length; index++) {
                var element = JSON.parse(newSelfEventsJSON[index]);
                console.log(element.id + " / "  + eventObj.id);                
                if(element.id == eventObj.id){
                    console.log("found event - ", element);
                    console.log(eventObj.end);
                    
                    element.start = moment(eventObj.start);
                    element.end = moment(eventObj.end);

                    newSelfEventsJSON[index] = JSON.stringify(element);
                    console.log(JSON.parse(newSelfEventsJSON[index]));                                        
                    break;
                }                
            }    
          writeEventsP();
          }
        },
        
        select: function(info){
          console.log("select_______________");
          
          var eventObj = info.event;
          var eventEnding = moment(info.startStr);
              
          //console.log(eventEnding.format('HH:mm:ss'));
          //console.log(eventEnding.format('YYYY-MM-DD'));
  
  
          //--check if the current time clicked is before the end of event, if so allow to click, else do nothing.
          var timeClickedDate = Date.parse(moment().format('YYYY-MM-DD'));
          let endDate = Date.parse(eventEnding.format('YYYY-MM-DD'));
          if (timeClickedDate>endDate){
          //console.log("event is in the past");
          alert("You can not create an event in the past!");
          return;
          }
          else if (timeClickedDate == endDate){
              var timeClickedTime = moment().format('HH:mm:ss');
              let endTime = eventEnding.format('HH:mm:ss');
              
              
              
              str1 =  timeClickedTime.split(':');
              str2 =  endTime.split(':');
  
              //console.log(timeClickedTime + " " + endTime);
  
              totalSecondsTimeClicked = parseInt(str1[0] * 3600 + str1[1] * 60 + str1[0]);
              totalSecondsEndtime = parseInt(str2[0] * 3600 + str2[1] * 60 + str2[0]);
              //console.log(totalSecondsTimeClicked + " " + totalSecondsEndtime);
              if (totalSecondsTimeClicked > totalSecondsEndtime ){
                  //console.log("event is in the past");
                  alert("You can not create an event in the past!");
                  return;
              }
              else{
                  //console.log("event is in the future");
              }          
          }
     
          //console.log(document.getElementById('acceptGuest_default').checked);
          // var currentUser = JSON.parse(localStorage.getItem("currentUser"));
          // let r = Math.random().toString(36).substring(2);
          var r = URL.createObjectURL(new Blob([])).slice(-36).replace(/-/g, "")
          var allowGuest = false;
          var bgColor = color_normal_me;
          if (document.getElementById('acceptGuest_default').checked==true){
            allowGuest = true;
            bgColor = color_guest_me;
          }
          myCalendar.addEvent({
                  id: r,
                  title: currentUser.name +" " +currentUser.lastName,
                  start: info.startStr,
                  end: info.endStr,
                  allDay: false,
                  editable: true,
                  droppable: true,
                  
                  backgroundColor: bgColor,
                  appId: currentUser.appId,
                  auther: currentUser.name,
                  acceptGuest : allowGuest
                });
    
          CurrentEvent = myCalendar.getEventById(r);                        
          
          // currentUser.calArray = [];
          // localStorage.setItem("currentUser", JSON.stringify(currentUser));
          var tempArrayOfAll = [];
          if(typeof(selfEvents)!==undefined){
  
            if(selfEvents.length>0){
              tempArrayOfAll = selfEvents;
            }                              
            //console.log("tempArrayOfAll defined " + tempArrayOfAll.length);
            
          }
          else{
            //console.log("tempArrayOfAll not defined" + tempArrayOfAll);
          }
          console.log(typeof(CurrentEvent));
          
          newSelfEventsJSON = newSelfEventsJSON.concat(JSON.stringify(CurrentEvent));
        //   newSelfEvents = newSelfEvents.concat(CurrentEvent);

          newSelfEvents = newSelfEvents.concat(JSON.stringify(CurrentEvent));
        //   selfEvents.push(JSON.stringify(CurrentEvent));
          console.log(newSelfEventsJSON);
          console.log(newSelfEvents);
          
          // //console.log("tempArrayOfAll: " ,tempArrayOfAll);
          
          // var tempArrayOfAll =  tempArrayOfAll.concat(JSON.stringify(CurrentEvent));
          // //console.log("tempArrayOfAll: " ,tempArrayOfAll);
          // //console.log(tempArrayOfAll);
          // currentUser.calArray = tempArrayOfAll;
  
          console.log("New Self Events ",newSelfEvents);
          
  
          //save all events to firebase
          // saveAllEvents(myCalendar);
          writeEventsP();
  
        },
  
        eventClick: function(info) {
          
          //console.log(info);
          
          var eventObj = info.event;
          userAppId = eventObj.extendedProps.appId;
          
          if (eventObj.url) {
            alert(
              'Clicked ' + eventObj.title + '.\n' +
              'Will open ' + eventObj.url + ' in a new tab'
            );
            window.open(eventObj.url);
            info.jsEvent.preventDefault(); // prevents browser from following link in current tab.
          } else {
  
            //--1/ check if the evnt autor is the suer                    
  
  
                $('#datetime15').combodate('setValue', moment(eventObj.start).format('hh:mm A'));
                $('#datetime16').combodate('setValue', moment(eventObj.end).format('hh:mm A'));
                
                singleEventOriginalStart = $('#datetime15').combodate('getValue');
                singleEventOriginalEnd = $('#datetime16').combodate('getValue');
                console.log("singleEventOriginalEnd",singleEventOriginalEnd);
                
                      
                var eventName = document.getElementById('eventName');
                var eventDate = moment(eventObj.start).format('YYYY/MM/DD');
                // var eventStart = moment(eventObj.start).format('hh:mm A');
                // var eventEnd = moment(eventObj.end).format('hh:mm A');
                eventAuther = eventObj.auther;
                // var eventId = eventObj.id;
                eventId = eventObj.id;
            
                document.getElementById('eventName').innerHTML = eventObj.title;
                document.getElementById('eventDate').innerHTML = moment(eventDate).format('DD - MMMM - YYYY');
                
                CurrentEvent=myCalendar.getEventById(eventId);
            
              var eventEnding = moment(eventObj.end);                        
  
              var timeClickedDate = Date.parse(moment().format('YYYY-MM-DD'));
              let endDate = Date.parse(eventEnding.format('YYYY-MM-DD'));
              
              if (timeClickedDate>endDate){
              //console.log("event is in the past");
              alert("You can not select an event in the past!");
              return;
              }
              else if (timeClickedDate == endDate){
                  var timeClickedTime = moment().format('HH:mm:ss');
                  let endTime = eventEnding.format('HH:mm:ss');                
                  
                  str1 =  timeClickedTime.split(':');
                  str2 =  endTime.split(':');
  
                  //console.log(timeClickedTime + " " + endTime);
  
                  totalSecondsTimeClicked = parseInt(str1[0] * 3600 + str1[1] * 60 + str1[0]);
                  totalSecondsEndtime = parseInt(str2[0] * 3600 + str2[1] * 60 + str2[0]);
                  //console.log(totalSecondsTimeClicked + " " + totalSecondsEndtime);
                  if (totalSecondsTimeClicked > totalSecondsEndtime ){
                      //console.log("event is in the past");
                      alert("You can not select an event in the past!");
                      return;
                  }
                  else{
                      //console.log("event is in the future");
                  }          
              }  
              
              // -------------
              makeOneDayCal(eventObj)             
          }
        },
        dateClick: function(info) {
          //console.log('clicked ' + info.dateStr);
        }         
      });
      
      
      myCalendar.render();    
  }

  function filterCurrentInterest(currentField){
    console.log("filterCurrentInterest: " ,currentField);    
     
      console.log("filtering now: " ,currentField);      
      tempUsersByInterestArray = [];
      tempEventForInterest=[];
      
      //--filter out the users based on FOI
      var localUsersArray = allUsersSnapShot.toJSON();
      allUsersSnapShot.forEach(function(child) {

      var tempFieldsArray = child.val().fieldsOfinterest;

      if (tempFieldsArray === undefined){
        // console.log("undifined tempFieldArray");
        
      }        
      else{
        // create the user list
        if(currentField == "All_as_guest"){
              tempUsersByInterestArray.push({
                key:   child.val().appId,
                value: child.val().name + " " + child.val().lastName
              }); 

            let tempArray = child.val().calArray;
            if (typeof(tempArray)=== undefined || tempArray === undefined){
              //console.log("no array found ");
            }
            else{
              if(tempArray === undefined){
                //console.log("emptry bastered");
                
              }
              else {
                if(child.val().appId == currentUser.appId){
                    var localSelfCalArray = child.val().calArray;

                    tempEvent = [];
                    console.log(tempEvent.backgroundColor);

                    //check if the event are by the current user and if so change the color
                  for(v in localSelfCalArray){
                    tempEvent = JSON.parse(localSelfCalArray[v])
                    if (tempEvent.extendedProps.acceptGuest == true){
                      tempEvent.backgroundColor = color_guest_me;
                      tempEvent.editable = true;
                      tempEvent.droppable = true;
                    }
                    else{
                      tempEvent.backgroundColor = color_normal_me;
                      tempEvent.editable = true;
                      tempEvent.droppable = true;
                    }                                      
                  }                    
                }
                else{
                    console.log(child.val().name);
                    
                    var localSelfCalArray = child.val().calArray;
                    //console.log(typeof(localSelfCalArray));
                    //console.log(localSelfCalArray);
                    //console.log("STOPPPPP");
                    
                    for (i in localSelfCalArray){
                      let tempVar = JSON.parse(localSelfCalArray[i]);
                        //console.log(tempVar.backgroundColor);
                        if (tempVar.backgroundColor == "orange"){
                          // tempVar.display = 'none';

                        }
                        else if (tempVar.extendedProps.acceptGuest == true){
                          tempVar.backgroundColor = color_guest;
                          tempEventForInterest = tempEventForInterest.concat(tempVar);  
                        }
                        else{
                          tempVar.backgroundColor = color_main;
                        } 
                                         
                    }                                             
                  }                
              } 
            } 
        }
        else{
            console.log("creating user list");
            
            if (Object.values(tempFieldsArray).includes(currentField)) {
                if(child.val().appId != currentUser.appId){
                  // console.log(child.val().name);
                  tempUsersByInterestArray.push({
                      key:   child.val().appId,
                      value: child.val().name + " " + child.val().lastName
                  }); 
                }
                
                console.log("tempUsersByInterestArray ",tempUsersByInterestArray);
                
                // create the Event lists for the relevent users
                let tempArray = child.val().calArray;
                if (typeof(tempArray)=== undefined || tempArray === undefined){
                  //console.log("no array found ");
                }
                else{
                  if(tempArray === undefined){
                    //console.log("emptry bastered");
                    
                  }
                  else {
                    if(child.val().appId == currentUser.appId){
                        var localSelfCalArray = child.val().calArray;

                        tempEvent = [];

                        //check if the event are by the current user and if so change the color
                      for(v in localSelfCalArray){
                        tempEvent = JSON.parse(localSelfCalArray[v])
                        if (tempEvent.extendedProps.acceptGuest == true){
                          tempEvent.backgroundColor = color_guest_me;
                          tempEvent.editable = true;
                          tempEvent.droppable = true;
                          // console.log(typeof(selfEvents));                        
                        }
                        else{
                          tempEvent.backgroundColor = color_normal_me;
                          tempEvent.editable = true;
                          tempEvent.droppable = true;
                        }                                          
                      }                    
                    }
                    else{
                        // console.log(child.val().name);
                        
                        var localSelfCalArray = child.val().calArray;                                                
                        for (i in localSelfCalArray){
                          let tempVar = JSON.parse(localSelfCalArray[i]);
                            //console.log(tempVar.backgroundColor);
                            if (tempVar.extendedProps.acceptGuest == true){
                              tempVar.backgroundColor = color_guest;
                            }
                            else{
                              tempVar.backgroundColor = color_main;
                            } 
                            tempEventForInterest = tempEventForInterest.concat(tempVar); 
                            // tempEventForInterest = tempEventForInterest.concat(JSON.stringify(tempVar));                   
                  
                        }                                             
                      }                
                  } 
                }                                         
              }  
            }
          }
      });

      //check if there are selected users
      console.log("selected Users: ",selectedUsers);
      if(selectedUsers.length>0){
        
        for (let index = 0; index < selectedUsers.length; index++) {
          const element = selectedUsers[index];
          console.log(element);
                    
          for (h in tempUsersByInterestArray) {
            console.log(h);
            
            console.log(tempUsersByInterestArray[h].key);
            if(tempUsersByInterestArray[h].key == element){
              console.log("Found a match");
              let filteredEventsByInterest = tempEventForInterest

              // c = a.filter( x => !b.filter( y => y.id === x.id).length);
              filterOne(tempUsersByInterestArray[h].key)

              break;
              
            } 
          }                            
                        
        populateUsersTablePC(tempUsersByInterestArray);
        keepSelectedUsersOn();
        return;
        // return;

      }                  
      populateUsersTablePC(tempUsersByInterestArray);
    }
      
    //refresh the calendar!
    // console.log("tempEventForInterest:____",tempEventForInterest);
    const unique = Array.from(new Set(tempEventForInterest.map(JSON.stringify))).map(JSON.parse);
    filterCal(unique);    
}

function filterCal(eventsToBuildArray){
    console.log("F I L T E R  C A L :", showMySelfCheck);
    // console.log(selfEvents)
    
    eventsToBuildArray_cache = JSON.stringify(eventsToBuildArray);
    console.log("eventsToBuildArray_cache: ",eventsToBuildArray_cache);
  
    //console.log("eventsToBuildArray: ",eventsToBuildArray);
    //if show self is on:
    if (showMySelfCheck == true){
      console.log("add myself to events");
      
      eventsToBuildArray = eventsToBuildArray.concat(newSelfEvents);
      console.log("eventsToBuildArray added: ",eventsToBuildArray);
      
    
    }
    else{
      // eventsToBuildArray = eventsToBuildArray.splice(selfEvents);
      eventsToBuildArray_cache = eventsToBuildArray_cache.filter( x => !newSelfEvents.filter( y => y.id === x.id).length);
    }
    
    const unique = Array.from(new Set(eventsToBuildArray.map(JSON.stringify))).map(JSON.parse);
  
    // const unique = [...new Map(eventsToBuildArray.map(item => [item[key], item])).values()];
    console.log(unique);
    
    // myCalendar.addEventSource(eventsToBuildArray)
    let allevents = myCalendar.getEvents(); 
    allevents.forEach(el => { el.remove(); })
    myCalendar.addEventSource(unique);
  
    // showAllFavs();
    
    // toggleAllFavsSelection();
    // console.log(runShowmyself);
    // if (runShowmyself == 1){
    //   // console.log("changing runShowmyself to 2");
    //   // runShowmyself=2;
    //   showMyself();
    // }
    
    // myCalendar.refetchEvents();  
    // console.log(myCalendar.getEvents());
    
    $('#loading').hide();
      
     
  }


  function makeOneDayCal(event1){
    console.log(event1);
          eventSingle = event1;
          var calendarEl = document.getElementById('calendarSingle');
          calendarEl.style.display = "block";
          document.getElementById('calendar').style.display = "none";
          document.getElementById('backToCal').style.display = "block";
          document.getElementById('requestEv').style.display = "block";
  
          
          var scrollT = moment(event1.start).format('HH:mm:ss');
          console.log(scrollT);
          
          
          calendar1 = new FullCalendar.Calendar(calendarEl, {
  
              initialView: 'timeGridDay',
              allDaySlot: false, 
              selectable: false,
              dragScroll:false,
              editable: true,
              droppable: false, 
              eventResizableFromStart: true,
              slotDuration: ('00:15:00'),                         
              scrollTime: (scrollT),                
              events: [
                  {
                    id: event1.id,
                    title: event1.title,
                    start: moment(event1.start).format(),
                    end: moment(event1.end).format(),  
                    backgroundColor: event1.backgroundColor,
                    display: 'background'               
                  },
                  {
                    id: event1.id,
                    title: event1.title,
                    start: moment(event1.start).format(),
                    end: moment(event1.end).format(),  
                    backgroundColor: "orange",
                    extendedProps:{
                      acceptGuest : event1.extendedProps.acceptGuest,
                      appId: currentUser.appId,
                      auther: currentUser.name,
                      droppable: true
                    },
                    // display: 'background'               
                  }
  
                ]                 
          });
  
          calendar1.render();
          calendar1.gotoDate(moment(event1.start).format());
          
          var timeSlotArray =document.getElementsByClassName("fc-event-draggable");
          var timeSlot = timeSlotArray[timeSlotArray.length-1];
          
          timeSlot.className = "fc-timegrid-event fc-v-event fc-event fc-event-resizable fc-event-start fc-event-end fc-event-today fc-event-future"
          
          
          if(event1.extendedProps.appId != currentUser.appId){
              calendar1.setOption("slotMaxTime", moment(event1.end).format('HH:mm'));
              calendar1.setOption("slotMinTime", moment(event1.start).format('HH:mm'));
          }       
  }

  function deleteEvent(){
    let eventObj = eventSingle;
    let answer= confirm("Are you sure you want to delete this event?")
    if (answer ==true){
      console.log("delet Event: " + eventObj.id);
      var eventTodelete = myCalendar.getEventById(eventObj.id);
      eventTodelete.remove();      
  
      for(e in newSelfEventsJSON){
        let tempvar = JSON.parse(newSelfEventsJSON[e]);
        // console.log(tempvar.id);
        if (tempvar.id == eventObj.id){
          console.log("event found at indes: " + e);
          // currentUser.calArray.splice(e, 1); 
          newSelfEventsJSON.splice(e ,1);     
          break;
          
        }
      }  
      console.log(newSelfEventsJSON);
      allowInit = false;
    //   firebase.database().ref('users/' + currentUser.luid).update(
    //     {        
    //       calArray: newSelfEventsJSON            
    //     });
      writeEventsP();
      backToCal();
      let allevents = myCalendar.getEvents(); 
      allevents.forEach(el => { el.remove(); });            
      myCalendar.addEventSource(allevents);
    }
    
  }

  


  function writeEventsP(){
    //TODO - fix the write events to have only the user's
    // array = selfEvents;
    // if (selfEvents.length == 0){
    //   array = "";
    // }
     
    // console.log(JSON.parse(newSelfEventsJSON));
    
    // jsonObject = (new Function('return ' + jsonFormatData))()
         
         
    firebase.database().ref('users/' + currentUser.luid).update(
      {
        calArray: newSelfEventsJSON      
    
        // calArray: JSON.stringify(newSelfEvents )       
      });
    //   localStorage.setItem("currentUser", JSON.stringify(currentUser));
}

function backToCal(){                
    document.getElementById('calendarSingle').style.display = "none";
    document.getElementById('calendar').style.display = "block";
    document.getElementById('backToCal').style.display = "none";
    document.getElementById('requestEv').style.display = "none";
    calendar1.destroy();
}