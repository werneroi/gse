var usersResourceList = [];
var allEvents =[];

myCalendar = FullCalendar;
myCalendarAlt = FullCalendar;


var toggleSelfCheck = false;
var toggleDisplay_check = false; // if false = myCalendarAlt cal if true = mycalendar
var currentField = "";
var foiList = ["hypnosis", "nlp", "breath"];
var sourceCal = "alt";



document.addEventListener('DOMContentLoaded', function() {
    console.log("allUsersSnapShot after DOM load: ",allUsersSnapShot);
    buildFOISelector();
    
    var mySelect = document.getElementById("foiSelector1");
    mySelect.onchange = (event) => {
       var fieldName = event.target.value;
       console.log(fieldName);
   
        if (fieldName == "All_as_geusts"){
        
        }
        else{                                 
            filterResourcesFOI(fieldName);
        }
    } 

     


    document.getElementById("calendarSingle").style.visibility = "hidden"; 
    document.getElementById("calendar").style.visibility = "visible"; 
    document.getElementById('label_AG').style.display = "";
    document.getElementById('acceptGuest_default').style.display = "";

    document.getElementById('label_AG_singlePage').style.display = "none";
    document.getElementById('acceptGuest_singlePage').style.display = "none"; 
    
    document.getElementById('trimB').style.display = "none"; 
    document.getElementById('confirmB').style.display = "none"; 
    document.getElementById('declineB').style.display = "none"; 
});

//------------ INIT FUNCTIONS --------------//
function InitCal(){ 
    document.getElementById('myself').innerHTML = currentUser.name + " " + currentUser.lastName;
    newSelfEventsJSON =[];
    console.log("initCal");
    buildresources();
    buildEvents();
    filterResourcesFOI("hypnosis");    
}

function filterResourcesFOI(currentField){
    console.log("filterResourcesFOI");
    tempUsersResourcesByInterestArray = [];
    tempEventsFromResources = [];
      
    var allResources = myCalendar.getResources();
    for(e in allResources) {
      allResources[e].remove();
    }

    var localUsersArray = allUsersSnapShot.toJSON();
    allUsersSnapShot.forEach(function(child) 
    {
        var tempFieldsArray = child.val().fieldsOfinterest;

        if (tempFieldsArray === undefined){                        
        }        
        else
        {
            if (Object.values(tempFieldsArray).includes(currentField)) 
            {
                resource = 
                {
                  id:   child.val().appId,
                title: child.val().name + " " + child.val().lastName
                  }
                myCalendar.addResource(resource);

                tempUsersResourcesByInterestArray.push({
                key:   child.val().appId,
                value: child.val().name + " " + child.val().lastName
                });  

                // console.log(child.val().calArray);
                if(child.val().calArray){
                    for (var i = 0; i < child.val().calArray.length; i++) {
                        if (child.val().appId == currentUser.appId){
                            child.val().calArray[i].editable = true;
                            child.val().calArray[i].draggable = true;
                        }
                        else{
                            child.val().calArray[i].editable = false;
                            child.val().calArray[i].draggable =false;
                        }
                        tempEventsFromResources.push(JSON.parse(child.val().calArray[i]));
                    }
                }
            }             
        }            
    });
      console.log(tempEventsFromResources);
      resetCalAlt(tempEventsFromResources); 
      resetCal(tempEventsFromResources);
      $('#loading').hide();
          
  }



  function buildresources(){
    usersResourceList = [];
    allUsersSnapShot.forEach(function(child) {
                  
        //create a list of all users with out myself!
        let userFullName = child.val().name + " " + child.val().lastName
        usersResourceList.push({
          
          id: child.val().appId,
          title: userFullName,
          fav: "b&^",
          view: "87h"     
        })
      });      
      makeCal();
      makeCalAlt();
      makeCalSingle();

    //   console.log(myCalendarAlt.view.title);
      document.getElementById('currentDate').innerHTML = myCalendarAlt.view.title;
      
}
 
function buildFOISelector(){
  
    console.log("buildFOISelector");  
    var dynamicSelect = document.getElementById("foiSelector1");
    let filtered=foiList.filter((a,i)=>i%2===1);
    foiList.forEach(function(item)
    {      
            var newOption = document.createElement("option");
            newOption.text = item;//item.whateverProperty
            dynamicSelect.appendChild(newOption);
    });      
}

function buildEvents(){

    allUsersSnapShot.forEach(function(child) {
        let calArray = child.val().calArray;
        if(calArray){
            for (e in calArray){
                // console.log(calArray[e]);
                // console.log(calArray[e]);
                let tempEvent = JSON.parse(calArray[e]);
                if(child.val().appId == currentUser.appId){
                    tempEvent.editable = true;
                    tempEvent.droppable = true;
                    //add the user events to seflEvents as JSON
                    // newSelfEventsJSON = newSelfEventsJSON.concat(JSON.stringify(tempEvent));
                }
                else{
                    tempEvent.editable = false;
                    tempEvent.droppable = false;
                }                
                allEvents.push(tempEvent);
            }
        }
    });
    myCalendar.addEventSource(allEvents);
    myCalendarAlt.addEventSource(allEvents);
}

//------ END INIT FUNCTIONS -----------------//
//------ BUILDING THE CALENDARS--------------//
function makeCal(){
    console.log("makecal");  
      
      var initView = 'resourceTimelineWeek';
      // var initView = 'resourceTimeline';
    //   if (myCalendar.view){
    //     initView = myCalendar.view.type;
    //     myCalendar.destroy();
    //   }
      
      var calendarEl = document.getElementById('calendar');      
      myCalendar = new FullCalendar.Calendar(calendarEl, {
        
        // filterResourcesWithEvents: true,
        // Calendar Option
        initialView: initView,
        allDaySlot: false,  
        eventResizableFromStart: true,    
        firstDay: moment().format('e'),
        // dragScroll: false,
        now: moment().format(),
        nowIndicator: true,  
        editable: false,
        // startEditable: true,
        selectMinDistance: 20,
        // droppable: false,           
        selectable: true,
        // selectOverlap: false,
        // eventOverlap: true,
        aspectRatio: 1.8,
        scrollTime: moment().format('HH:mm:ss'), // undo default 6am scrollTime
        headerToolbar: {
          left: 'today prev,next',
          center: 'title',
          right: 'resourceTimelineDay,resourceTimelineWeek,resourceTimelineMonth'
          // right: 'timeGridDay,timeGridWeek,dayGridMonth'
        },
        dayMaxEventRows: true,
        eventContent: { domNodes: [] },
        eventContent: function(arg) {
            let italicEl = document.createElement('p');
            
            italicEl.innerHTML = moment(arg.event.start).format('HH:mm')+" - " + moment(arg.event.end).format('HH:mm') + '<br/>' + arg.event.title;
            
           
            let arrayOfDomNodes = [ italicEl ]
            return { domNodes: arrayOfDomNodes }
        },

        eventDidMount: function(arg){
            eventMount(arg);  
                      
        },

        eventMouseEnter: function(arg){

        },
        resourceAreaColumns: [
            {
              field: 'title',
              headerContent: ' Name',
              
            },            
        ],

        viewClassNames: function (info) {
            //this is called whenever the calendar changes view!                        
            // console.log(info)
        },
        

        resources: usersResourceList,
  
        dateClick: function(info) {
          //console.log('clicked ' + info.dateStr);
        },
        resourceLabelContent: function (arg)
        {   
            let htmlText = "<i class='chatIcon fa fa-comment' onclick='openChat(&#039" + arg.resource.id + "&#039)'></i><i class='fa fa-star' id='toggleAllFavSelection' onclick='toggleAllFavsSelection(&#039" + arg.resource.id  +"&#039)'></i></div>";
            return { html: arg.resource.title + " " + htmlText };
        },
        resourceLabelDidMount: function(arg){
          arg.el.style.backgroundColor = 'orange';
        //   arg.el.innerHTML += "<i class='favIcon fa fa-star'>"
        //   console.log(arg.resource);
          arg.el.addEventListener("click", function () { console.log('clicked:' + arg.resource.id); });

        //   console.log(arg.el.innerHTML);
        //   let id = arg.event.getResources().id;
            //   arg.el.innerHTML += "<i class='chatIcon fa fa-comment' onclick='openChat(&#039" + "1" + "&#039)'></i><i class='fa fa-star' id='toggleAllFavSelection' onclick='toggleAllFavsSelection(&#039" + "1"  +"&#039)'></i></div>";
              
        //   let parent = arg.el.parentNode;
        //   let contents = parent.innerHTML ;
        //     parent.innerHTML = "<div id='holder' onclick='toggleUserSelection(" + arg.resource.id + ")'><i class='favIcon fa fa-star'" + contents + "</div>";
            
        //   <i class='fa fa-star' id='toggleAllFavSelection' onclick='toggleAllFavsSelection()'></i>
        }, 
        
        eventClick: function(arg) {
            respondTo_eventClick(toggleDisplay_check, arg);            
        },

        select: function(info){
            console.log("select_______________");
            respondTo_EventSelect(info);            
        },

        eventResize: function(info) {
            console.log("Resize event: " ,info);
            respondTo_EventResize(info);
          },

        eventDrop: function(arg) { // called when an event (already on the calendar) is moved
            console.log('eventDrop', arg.event);  
            respondTo_EventDrop(arg);     
        },
      });      
      myCalendar.render(); 
    //   resourcesCSS();
}



function makeCalAlt(){
    console.log("makecalAlt");  
      
      var initView = 'timeGridWeek';
    //   if (myCalendarAlt.view){
    //     initView = myCalendarAlt.view.type;
    //     myCalendarAlt.destroy();
    //   }
      
      var calendarEl = document.getElementById('calendarAlt');      
      myCalendarAlt = new FullCalendar.Calendar(calendarEl, {
        
        // Calendar Option
        initialView: initView,
        allDaySlot: false,    
        eventResizableFromStart: true,   
        firstDay: moment().format('e'),
        // backgroundColor :'white',
        // dragScroll: false,
        now: moment().format(),
        nowIndicator: true,  
        // editable: false,
        // droppable: false,           
        selectable: true,
        editable: false,
        // startEditable: true,
        selectMinDistance: 20,
        // selectOverlap: false,
        // eventOverlap: false,
        
        aspectRatio: 1.8,
        scrollTime: moment().format("HH:mm:ss"), // undo default 6am scrollTime
        headerToolbar: {
          left: 'today prev,next',
          center: 'title',
          right: 'timeGridDay,timeGridWeek,dayGridMonth'
          // right: 'timeGridDay,timeGridWeek,dayGridMonth'
        },
        
        // viewClassNames: function (info) {
        //     if(myCalendar){

        //         if (toggleDisplay_check == false){
        //             let currentViewType = myCalendarAlt.view.type;
        //             console.log(currentViewType);
        //             if (currentViewType == 'timeGridDay'){
        //                 console.log("day");
        //                 myCalendar.changeView('resourceTimelineDay');
        //             }
        //             else if (currentViewType == 'timeGridWeek'){
        //                 console.log("week");
        //                 myCalendar.changeView('resourceTimelineWeek');
        //             }
        //             if (currentViewType == 'dayGridMonth'){
        //                 console.log("month");
        //                 myCalendar.changeView('resourceTimelineMonth', moment().format());
        //             }
        //         }
        //     }
            
        // },
        dayMaxEventRows: true,
        eventContent: { domNodes: [] },
        eventContent: function(arg) {
            let italicEl = document.createElement('p')
            italicEl.innerHTML = moment(arg.event.start).format('HH:mm')+" - " + moment(arg.event.end).format('HH:mm') + '<br/>' + arg.event.title;
            let arrayOfDomNodes = [ italicEl ]
            return { domNodes: arrayOfDomNodes }
        },
        resources: usersResourceList,
  
        dateClick: function(info) {
          //console.log('clicked ' + info.dateStr);
        },
        eventDidMount: function(arg){
            // myCalendarAlt.setOption('editable',false);
            eventMount(arg);            
        },
        
        // resourceLabelDidMount: function(arg){
        //   arg.el.style.backgroundColor = 'orange';
        // //   console.log(arg.resource);
        //   arg.el.addEventListener("click", function () { console.log('clicked:' + arg.resource.id); });
        // }, 
        
        eventClick: function(arg) {
            respondTo_eventClick(toggleDisplay_check, arg);            
        },

        select: function(info){
            console.log("select_______________");
            respondTo_EventSelect(info);            
        }, 

        eventDrop: function(arg) { // called when an event (already on the calendar) is moved        
            console.log('eventDrop', arg.event);  
            respondTo_EventDrop(arg);     
        },

        eventResize: function(info) {
            console.log("Resize event: " ,info);
            respondTo_EventResize(info);
        },

      });      
      myCalendarAlt.render(); 
}

function today(){
    myCalendar.today();
    myCalendarAlt.today();
    document.getElementById('currentDate').innerHTML = myCalendarAlt.view.title;
}
function nextDate(){
    myCalendar.next();
    myCalendarAlt.next();
    document.getElementById('currentDate').innerHTML = myCalendarAlt.view.title;
}
function prevDate(){
    myCalendar.prev();
    myCalendarAlt.prev();
    document.getElementById('currentDate').innerHTML = myCalendarAlt.view.title;
}

function day(){
    myCalendar.changeView('resourceTimelineDay');
    myCalendarAlt.changeView('timeGridDay');
    myCalendar.setOption('scrollTime',moment().format());
    myCalendarAlt.scrollTime = moment().format();
    // myCalendar.scrollTime = moment().format();
    document.getElementById('currentDate').innerHTML = myCalendarAlt.view.title;
}
function week(){
    myCalendar.changeView('resourceTimelineWeek');
    myCalendarAlt.changeView('timeGridWeek');
    myCalendarAlt.scrollTime = moment().format();
    myCalendar.scrollTime = moment().format();
    document.getElementById('currentDate').innerHTML = myCalendarAlt.view.title;
}
function month(){
    // myCalendarAlt.destroy();
    // myCalendar.destroy();
    // myCalendar.render();
    // myCalendarAlt.render();
    myCalendar.changeView('resourceTimelineMonth');
    myCalendarAlt.changeView('dayGridMonth');
    myCalendarAlt.scrollTime = moment().format();
    myCalendar.setOption('scrollTime',moment().format());
    // myCalendar.scrollTime = moment().format();
    document.getElementById('currentDate').innerHTML = myCalendarAlt.view.title;
}
//--------- Calendar options for alt and regular ---------//
var allowTippy = true;
function showTippy(instance){
    console.log(instance);
    if(allowTippy == false){
        instance.hide();
    }
    else{
        instance.show(); 
    }
}
function eventMount(arg){
            
                const template = document.getElementById('template');
                tippy(arg.el, {                    
                    content: template.innerHTML,
                    allowHTML: true,
                    interactive: true,
                    onShow(instance){
                        if(allowTippy == false){
                            instance.popper.style.display ='none';
                        }
                        else{
                            instance.popper.style.display ='';;
                        }
                        
                    }                    
                });
            
            
            // console.log(arg.event);
            // arg.el.style.backgroundColor ="grey";

            if(arg.event.extendedProps.appId == currentUser.appId){
                arg.el.style.backgroundColor = color_normal_me;

                if(arg.event.extendedProps.status == "open"){
                    // arg.event.setProp("editable" , true);
                    if(arg.event.extendedProps.acceptGuest == true){
                        arg.el.style.backgroundColor = color_guest_me;
                    }
                    else{
                        arg.el.style.backgroundColor = color_normal_me;
                    }

                }
                else if(arg.event.extendedProps.status == "waiting"){
                    arg.el.style.backgroundColor = color_toBook;
                    let requestor = arg.event.extendedProps.description.split(":")[1];
                    // console.log(requestor);
                    // console.log(typeof(usersResourceList));
                    // console.log(usersResourceList)
                    var requestorName = usersResourceList.find(x => x.id === requestor).title;
                    arg.event.setProp(["title" , "Waiting for approval from: " + requestorName],[ "editable" , false]);
                    // arg.event.setProp("editable" , false);

                }

                else if(arg.event.extendedProps.status == "pending"){
                    arg.el.style.backgroundColor = color_toBook;
                    let requestor = arg.event.extendedProps.description.split(":")[1];                    
                    var requestorName = usersResourceList.find(x => x.id === requestor).title;                                        
                    arg.event.setProp("title" , "Waiting for your approval from: " + requestorName);

                }
                else if(arg.event.extendedProps.status == "booked"){
                    arg.el.style.backgroundColor = color_booked;
                    let newtitle = arg.event.title.replace('requested by: ',"");
                    // let requestor = arg.event.extendedProps.description.split(":")[1];                    
                    // var requestorName = usersResourceList.find(x => x.id === requestor).title;  
                    if(arg.event.title.includes('requested by')){
                        arg.event.setProp("title" , "Confirmed with: " + newtitle);
                    }  
                                                       
                }                            
            }
            else{
                // console.log(typeof(arg.el.className));
                let classi = arg.el.className;
                if(classi.includes('fc-event-draggable')){
                    classi.replace('fc-event-draggable',"");
                    classi = classi.replace(/fc-event-draggable/, '');
                }
                if(classi.includes('fc-event-resizable')){
                    classi = classi.replace(/fc-event-resizable/,'');
                }
                // console.log(classi);
                arg.el.className = classi;
                arg.el.style.backgroundColor = color_main;

                if(arg.event.extendedProps.status == "open"){

                    if(arg.event.extendedProps.acceptGuest == true){
                        arg.el.style.backgroundColor = color_guest;
                    }
                    else{
                        arg.el.style.backgroundColor = color_main;
                    }
                    arg.event.setProp('editable',false)

                }
                else if(arg.event.extendedProps.status == "waiting"){
                    arg.event.setProp('display','none');

                }

                else if(arg.event.extendedProps.status == "pending"){
                    arg.event.setProp('display','none');

                }
                else if(arg.event.extendedProps.status == "booked"){
                    arg.event.setProp('display','none');
                    
                }
                
                // if(arg.event.extendedProps.acceptGuest == "none"){

                // }
                // else if(arg.event.extendedProps.description.length > 1){
                //     arg.event.setProp('display','none');
                // }
                // else if(arg.event.extendedProps.acceptGuest == "waiting"){
                //     arg.el.style.backgroundColor = 'red';
                //     arg.event.setProp('display','none');                    
                // }
                // else if(arg.event.extendedProps.acceptGuest == "booked"){
                //     arg.el.style.backgroundColor = color_booked;

                // }
                // else if(arg.event.extendedProps.acceptGuest == true){
                //     arg.el.style.backgroundColor = color_guest;
                // }

                arg.event.editable = false;
            }
}

var eventSingle = [];


function respondTo_EventResize(info){

    console.log(currentUser.calArray);
    var eventObj = info.event;
    if (eventObj.extendedProps.appId != currentUser.appId){
        //console.log("Not your event, can't touch this.");
        info.revert();
        return;
    }
    else
    {  
        var eventEnding = moment(eventObj.end);
                    
        //--check if the current time clicked is before the end of event, if so allow to click, else do nothing.
        var timeClickedDate = Date.parse(moment().format('YYYY-MM-DD'));
        let endDate = Date.parse(eventEnding.format('YYYY-MM-DD'));
        if (timeClickedDate>endDate){
        //console.log("event is in the past");
        alert("You can not edit an event in the past!");
        info.revert();
        return;
        }
        else if (timeClickedDate == endDate){
        console.log("same day");
        
        var timeClickedTime = moment().format('HH:mm:ss');
        let endTime = eventEnding.format('HH:mm:ss');

        str1 =  timeClickedTime.split(':');
        str2 =  endTime.split(':');

        //console.log(timeClickedTime + " " + endTime);

        totalSecondsTimeClicked = parseInt(str1[0] * 3600 + str1[1] * 60 + str1[0]);
        totalSecondsEndtime = parseInt(str2[0] * 3600 + str2[1] * 60 + str2[0]);
        //console.log(totalSecondsTimeClicked + " " + totalSecondsEndtime);
            if (totalSecondsTimeClicked > totalSecondsEndtime ){
                //console.log("event is in the past");
                alert("You can not edit an event in the past!");
                return;
            }                   
        }
              // else{
    
              //     //deal with updating event:
                  
              //     //console.log("event is in the future");
              //   }     
    
        for (let index = 0; index < currentUser.calArray.length; index++) {
            var element = JSON.parse(currentUser.calArray[index]);
            console.log(element.id + " / "  + eventObj.id);                
            if(element.id == eventObj.id){
                console.log("found event - ", element);
                console.log(eventObj.end);
                
                element.start = moment(eventObj.start);
                element.end = moment(eventObj.end);

                currentUser.calArray[index] = JSON.stringify(element);
                console.log(JSON.parse(currentUser.calArray[index]));                                        
                break;
            }                
        }  
        myCalendar.getEventById(info.event.id).remove();
        myCalendarAlt.getEventById(info.event.id).remove();
        
        myCalendar.addEvent(eventObj);
        myCalendarAlt.addEvent(eventObj);  
        writeEventsP();
    }
}


function respondTo_EventSelect(info){
    var eventObj = info.event;
    var eventEnding = moment(info.startStr);
                    
    //--check if the current time clicked is before the end of event, if so allow to click, else do nothing.
    var timeClickedDate = Date.parse(moment().format('YYYY-MM-DD'));
    let endDate = Date.parse(eventEnding.format('YYYY-MM-DD'));
    if (timeClickedDate>endDate){
    //console.log("event is in the past");
    alert("You can not create an event in the past!");
    return;
    }
    else if (timeClickedDate == endDate){
        var timeClickedTime = moment().format('HH:mm:ss');
        let endTime = eventEnding.format('HH:mm:ss');                
        
        str1 =  timeClickedTime.split(':');
        str2 =  endTime.split(':');

        totalSecondsTimeClicked = parseInt(str1[0] * 3600 + str1[1] * 60 + str1[0]);
        totalSecondsEndtime = parseInt(str2[0] * 3600 + str2[1] * 60 + str2[0]);
        //console.log(totalSecondsTimeClicked + " " + totalSecondsEndtime);
        if (totalSecondsTimeClicked > totalSecondsEndtime ){
            //console.log("event is in the past");
            alert("You can not create an event in the past!");
            return;
        }                     
    }
       
    //console.log(document.getElementById('acceptGuest_default').checked);
    // var currentUser = JSON.parse(localStorage.getItem("currentUser"));
    let r = Math.random().toString(36).substring(2);
    var allowGuest = false;
    var bgColor = color_normal_me;
    if (document.getElementById('acceptGuest_default').checked==true){
      allowGuest = true;
      bgColor = color_guest_me;
    }

    let myEvent = {
        resourceId: currentUser.appId,
        id: r,
        title: currentUser.name +" " +currentUser.lastName,
        start: info.startStr,
        end: info.endStr,
        allDay: false,
        editable: true,
        draggable: true,
        eventStartEditable: true,
        droppable: true,
        backgroundColor: bgColor,
        extendedProps:{
        description :"", 
        status:"open",           
        appId: currentUser.appId,
        auther: currentUser.name,
        acceptGuest : allowGuest            
        }
    };
        
        

    myCalendar.addEvent(myEvent);
    myCalendarAlt.addEvent(myEvent);
            
    console.log(myEvent);
    console.log(JSON.stringify(myEvent));   
    CurrentEvent = myCalendar.getEventById(r);                        
                            
    // var tempArrayOfAll = [];
    // if(typeof(selfEvents)!==undefined){

    //   if(selfEvents.length>0){
    //     tempArrayOfAll = selfEvents;
    //   }                              
    //   //console.log("tempArrayOfAll defined " + tempArrayOfAll.length);
        
    // }
    // else{
    //   //console.log("tempArrayOfAll not defined" + tempArrayOfAll);
    // }
    
    console.log(myEvent);
    if(currentUser.calArray == "" || currentUser.calArray == undefined){
        currentUser.calArray = [];
    }
    // newSelfEvents = newSelfEvents.concat(JSON.stringify(myEvent));   
    currentUser.calArray.push(JSON.stringify(myEvent))         
    // console.log(newSelfEventsJSON);            
    // console.log("New Self Events ",newSelfEvents);
    

    //save all events to firebase
    // saveAllEvents(myCalendar);
    writeEventsP();
}
function respondTo_EventDrop(arg){
        var eventObj = arg.event;
        if (eventObj.extendedProps.appId != currentUser.appId){
            //console.log("Not your event, can't touch this.");
            
            arg.revert();
            return;
        }
        else
        {
            var eventEnding = moment(eventObj.end);            
            //--check if the current time clicked is before the end of event, if so allow to click, else do nothing.
            var timeClickedDate = Date.parse(moment().format('YYYY-MM-DD'));
            let endDate = Date.parse(eventEnding.format('YYYY-MM-DD'));
            if (timeClickedDate>endDate){
            //console.log("event is in the past");
            alert("You can not move an event in the past!");
            arg.revert();
            return;
            }
            else if (timeClickedDate == endDate){
            var timeClickedTime = moment().format('HH:mm:ss');
            let endTime = eventEnding.format('HH:mm:ss');              
            str1 =  timeClickedTime.split(':');
            str2 =  endTime.split(':');
    
            //console.log(timeClickedTime + " " + endTime);
    
            totalSecondsTimeClicked = parseInt(str1[0] * 3600 + str1[1] * 60 + str1[0]);
            totalSecondsEndtime = parseInt(str2[0] * 3600 + str2[1] * 60 + str2[0]);
            //console.log(totalSecondsTimeClicked + " " + totalSecondsEndtime);
            if (totalSecondsTimeClicked > totalSecondsEndtime ){
                //console.log("event is in the past");
                alert("You can not move an event in the past!");
                return;
            }
            else{
                //console.log("event is in the future");
            }          
        } 
        for (let index = 0; index < currentUser.calArray.length; index++) {
            var element = JSON.parse(currentUser.calArray[index]);
            console.log(element.id + " / "  + eventObj.id);                
            if(element.id == eventObj.id){
                console.log("found event - ", element);
                console.log(eventObj.end);
                
                element.start = moment(eventObj.start);
                element.end = moment(eventObj.end);

                currentUser.calArray[index] = JSON.stringify(element);
                console.log(JSON.parse(currentUser.calArray[index]));                    
                break;
            }                
        }

        myCalendar.getEventById(arg.event.id).remove();
        myCalendarAlt.getEventById(arg.event.id).remove();
        
        myCalendar.addEvent(eventObj);
        myCalendarAlt.addEvent(eventObj);
        writeEventsP();
    }
}

function respondTo_eventClick(source, arg){
    console.clear();
    // console.log('eventClick: ',source + " " ,JSON.stringify(arg.event.getResources()));
    console.log("the clicked event is: ", JSON.stringify(arg.event));
    document.getElementById("toggleSelf").style.display = "none";
    document.getElementById("toggleDisplay").style.display = "none";
    document.getElementById("toggleResources").style.display = "none";
    document.getElementById('AddEventManually').style.display = "none";
    
    

    eventSingle = arg.event;
    let elements =calendarSingle.getEvents();
    for (e in elements){ 
        let element = elements[e];
        element.remove();
    }    

    if(eventSingle.extendedProps.status == "pending"){        
        console.log("loading pending event");
        loadEventToConfirm();
        return;        
    }

    else if(eventSingle.extendedProps.status == "waiting"){        
        console.log("loading waiting event");
    }

    else if(eventSingle.extendedProps.status == "booked"){        
        console.log("loading booked event");
    }
    
    calendarSingle.addEvent("eventSingle: ",eventSingle);
    sourceCal = "single";
    if(eventSingle.extendedProps.appId == currentUser.appId){
        document.getElementById("deleteEvent").style.display = "inline-block";
        document.getElementById('label_AG_singlePage').style.display = "";
        document.getElementById('acceptGuest_singlePage').style.display = "";
        calendarSingle.setOption("scrollTime", moment(eventSingle.start).format('HH:mm'));
        calendarSingle.setOption("slotMaxTime", "24:00:00");
        calendarSingle.setOption("slotMinTime", "00:00:00");

        
    }
    else{
        document.getElementById("requestEv").style.display = "inline-block";
        document.getElementById('label_AG_singlePage').style.display = "none";
        document.getElementById('acceptGuest_singlePage').style.display = "none";
        calendarSingle.setOption("slotMaxTime", moment(eventSingle.end).format('HH:mm'));
        calendarSingle.setOption("slotMinTime", moment(eventSingle.start).format('HH:mm'));
        // event.display =  'background';
    }

    document.getElementById("calendar").style.visibility = "hidden"; 
    document.getElementById("calendarAlt").style.visibility = "hidden";
    document.getElementById("calendarSingle").style.visibility = "visible";
    document.getElementById("backToCal").style.display = "";
    document.getElementById('label_AG').style.display = "none";
    document.getElementById('acceptGuest_default').style.display = "none";
    

    calendarSingle.addEvent(eventSingle);
    calendarSingle.render();
    calendarSingle.gotoDate(moment(eventSingle.start).format());

    //disable dragging
    var timeSlotArray =document.getElementsByClassName("fc-event-draggable");
    var timeSlot = timeSlotArray[timeSlotArray.length-1];
    if(timeSlot !== undefined){
        timeSlot.className = "fc-timegrid-event fc-v-event fc-event fc-event-resizable fc-event-start fc-event-end fc-event-today fc-event-future";
    }
    
    

    document.getElementById('acceptGuest_default').style.display = "none";

    document.getElementById('label_AG_singlePage').style.display = "";
    document.getElementById('acceptGuest_singlePage').style.display = "";

    if (eventSingle.extendedProps.acceptGuest == true){          
        document.getElementById('acceptGuest_singlePage').checked = true;
    }
    else{          
        document.getElementById('acceptGuest_singlePage').checked = false;
    }
}

 


function makeCalSingle(){
    console.log("makeCalSingle");

    
    
    

    
    // var scrollT = moment(event1.start).format('HH:mm:ss');
    // console.log(scrollT);
    
    // let r = Math.random().toString(36).substring(2);

    // let backgroundColor = color_toBook;
    // let editable = true;
    // if (event1.extendedProps.acceptGuest == "booked"){
    //   console.log("Found accepted guest booked");
    //   backgroundColor = color_booked;
    //   editable = false;
    // }

    // let displayForm = 'background'
    // if(event1.extendedProps.appId == currentUser.appId){
    //   console.log("Found as self event");
    //   displayForm = 'block'
    // }
    // var eventsToCal = [];
    // if(event1.extendedProps.acceptGuest != "booked"){
    //   console.log("Found not booked");
    //   eventsToCal =[
    //     {
    //     resourceId: currentUser.appId,
    //     id: event1.id,
    //     title: event1.title,
    //     start: moment(event1.start).format(),
    //     end: moment(event1.end).format(),  
    //     backgroundColor: event1.backgroundColor,
    //     display: displayForm ,
    //     extendedProps:{
    //           acceptGuest : event1.extendedProps.acceptGuest,
    //           appId: currentUser.appId,
    //           auther: currentUser.name + " " + currentUser.lastName,
    //           droppable: false,
              
    //         },                        
    //   }          
    // ];
    // }
    // else{
    //   eventsToCal=[{
    //     resourceId: currentUser.appId,
    //     id: r,
    //     title: event1.title,
    //     start: moment(event1.start).format(),
    //     end: moment(event1.end).format(),  
    //     backgroundColor: backgroundColor,
    //     extendedProps:{
    //       acceptGuest : event1.extendedProps.acceptGuest,
    //       appId: currentUser.appId,
    //       auther: currentUser.name + " " + currentUser.lastName,
    //       droppable: false
    //     }}]

    // }

    
    
    
    let calendarEl = document.getElementById('calendarSingle')
    calendarSingle = new FullCalendar.Calendar(calendarEl, {

      

        displayEventTime:true,
        initialView: 'timeGridDay',
        // initialView:'resourceTimeline',
        allDaySlot: false, 
        // allDay:false,
        editable: false,
        selectable: true,
        dragScroll:false,
        // editable: editable,
        droppable: false, 
        eventResizableFromStart: true,
        slotDuration: ('00:15:00'), 
        dayMaxEventRows: true,                        
        // scrollTime: (scrollT), 
        eventContent: { domNodes: [] },            
        eventContent: function(arg) {
              let italicEl = document.createElement('p')                  
              italicEl.innerHTML = moment(arg.event.start).format('HH:mm')+" - " + moment(arg.event.end).format('HH:mm') + '<br/>' + arg.event.title;
            //   let id = arg.event.getResources().id;
            //   italicEl.innerHTML += "<i class='chatIcon fa fa-comment' onclick='openChat(&#039" + id + "&#039)'></i><i class='fa fa-star' id='toggleAllFavSelection' onclick='toggleAllFavsSelection(&#039" + id  +"&#039)'></i></div>";
              let arrayOfDomNodes = [ italicEl ]
              return { domNodes: arrayOfDomNodes }
        },

        resources: usersResourceList,             
        events: [
            {
                
            }
        ],
        eventDidMount: function(arg){
            eventMount(arg); 
            let event = arg.event;
            if(event.extendedProps.appId == currentUser.appId){
                // event.setProp('selectabe','false');
                calendarSingle.setOption('selectable','false');
                console.log(calendarSingle);

            }   
            else{
                calendarSingle.setOption('selectable','true');
                event.setProp('display','background');
            }        
        },

        select: function(info){
            
            if(calendarSingle.getEvents()[0].extendedProps.appId == currentUser.appId){
                return;
            }
            console.log(calendarSingle.getEvents().length);
            if (calendarSingle.getEvents().length > 1){
                calendarSingle.getEvents()[1].remove();
            }
            var eventObj = info.event;
            var eventEnding = moment(info.startStr);
            console.log(eventEnding);   
                                          
            // var allowGuest = false;
            // var bgColor = color_toBook;
            let r = Math.random().toString(36).substring(2);

            
            calendarSingle.addEvent({
              resourceId: currentUser.appId,
              id: r,
              title: currentUser.name +" " +currentUser.lastName,
              start: moment(info.start).format(),
              end: moment(info.end).format(),              
              editable: true,
            //   droppable: true,
              description :"",
              status: "open",
              backgroundColor: color_toBook,  
              draggable: false,            
              extendedProps:{
                acceptGuest : false,
                appId: currentUser.appId,
                auther: currentUser.name + " " + currentUser.lastName,
                // droppable: false
              }              
            })
          },


          eventResize: function(info){
              console.log("Single eventResize: ")
              if (info.event.extendedProps.appId == currentUser.appId){
                respondTo_EventResize(info);
              }
              else{
                info.revert()
              }
                

          }
                                    
    });

    
    // calendar1.eventRender.;
    
    
    // var timeSlotArray =document.getElementsByClassName("fc-event-draggable");
    // var timeSlot = timeSlotArray[timeSlotArray.length-1];
    
    // if(event1.extendedProps.acceptGuest != "booked"){
    //     timeSlot.className = "fc-timegrid-event fc-v-event fc-event fc-event-resizable fc-event-start fc-event-end fc-event-today fc-event-future";
    // }

    
    
    // var addEventB = document.getElementById('AddEventManually');
    //     addEventB.style.display = 'none';
    
    // if(event1.extendedProps.appId != currentUser.appId){
    //     calendar1.setOption("slotMaxTime", moment(event1.end).format('HH:mm'));
    //     calendar1.setOption("slotMinTime", moment(event1.start).format('HH:mm'));

    //     var deleteB = document.getElementById('deleteEvent');
    //     deleteB.style.display = 'none';
    //     document.getElementById('requestEv').style.display = "block"; 
    //     document.getElementById('label_AG_singlePage').style.display = "none";
    //     document.getElementById('acceptGuest_singlePage').style.display = "none";                       
        
    // } 
    // else if (event1.extendedProps.acceptGuest == "waiting"){
    //   document.getElementById('label_AG_singlePage').style.display = "none";
    //     document.getElementById('acceptGuest_singlePage').style.display = "none";
    //     var deleteB = document.getElementById('deleteEvent');
    //     deleteB.style.display = 'block';

    // }
    // else if (event1.extendedProps.acceptGuest == "booked"){
    //     calendar1.setOption("slotMaxTime", moment(event1.end).format('HH:mm'));
    //     calendar1.setOption("slotMinTime", moment(event1.start).format('HH:mm'));
    //     document.getElementById('label_AG_singlePage').style.display = "none";
    //     document.getElementById('acceptGuest_singlePage').style.display = "none";
    //     var deleteB = document.getElementById('deleteEvent');
    //     deleteB.style.display = 'block';
    // }
    // else{
      
    //   var deleteB = document.getElementById('deleteEvent');
    //     deleteB.style.display = 'block';        
    // } 
    
    // calendarSingle.render();
    // calendarSingle.gotoDate(moment(arg.event.start).format()); 
}

function resourcesCSS(){
    // fc-datagrid-cell fc-resource
    // fc-datagrid-expander fc-datagrid-expander-placeholder
    let resourcesIDss = document.getElementById('calendar').getElementsByClassName("fc-resource");
    let resourcesIds = document.getElementById('calendar').getElementsByClassName("fc-datagrid-cell");
    let resourcesDivs = document.getElementById('calendar').getElementsByClassName("fc-datagrid-expander");

    for (let i = 0; i < resourcesIds.length; i++) {
        if(resourcesIds[i].getAttribute('data-resource-id')){
            console.log(resourcesIds[i].getAttribute('data-resource-id'));
            let id = resourcesIds[i].getAttribute('data-resource-id');
            resourcesDivs[i].innerHTML ="<i class='chatIcon fa fa-comment' onclick='openChat(&#039" + id + "&#039)'></i><i class='fa fa-star' id='toggleAllFavSelection' onclick='toggleAllFavsSelection(&#039" + id  +"&#039)'></i></div>";
        }
        
    }

    // for (e in resourcesDivs){
    //     let nameString = resourcesIDss[e].innerText;
    //     // console.log(nameString);
        
    //   if (nameString)
    //   {
    //     // console.log(resourcesIDss[e].getAttribute('data-resource-id'));
    //       let id = resourcesIds[e].getAttribute('data-resource-id')
    //     // let id = resourcesIds[e].getAttribute('data-resource-id');
    //    resourcesDivs[e].innerHTML ="<i class='chatIcon fa fa-comment' onclick='openChat(&#039" + id + "&#039)'></i><i class='fa fa-star' id='toggleAllFavSelection' onclick='toggleAllFavsSelection(&#039" + id  +"&#039)'></i></div>";
    //   }
    // }

    // let resourcesIds = document.getElementsByClassName("fc-datagrid-cell");
    // let resourcesDivs = document.getElementsByClassName("fc-datagrid-cell-main");
    // // let resourcesDivs = document.getElementsByClassName("fc-datagrid-cell-cushion");
    // for (e in resourcesDivs){
    //   let nameString = resourcesDivs[e].innerText;
    //   if (nameString)
    //   {
    //       let id = resourcesIds[e].getAttribute('data-resource-id')
    //     // console.log("++++++++++++++++",resourcesIds[e].getAttribute('data-resource-id'));
  
    //       parent = resourcesDivs[e].parentNode,
    //       contents = parent.innerHTML ;
          
          
    //     //   parent.innerHTML = "<div id='holder' onclick='toggleUserSelection(" + fbUserAppId + ")'>"<i class="favIcon fa fa-star"' + contents + '</div>';
    //       parent.innerHTML ="<div id='holder'>" + contents + "<i class='chatIcon fa fa-comment' onclick='openChat(&#039" + id + "&#039)'></i><i class='fa fa-star' id='toggleAllFavSelection' onclick='toggleAllFavsSelection(&#039" + id  +"&#039)'></i></div>";
    //       // resourcesDivs[e].innerHTML = "<p style='display: inline-block'>" + nameString +'</p>';
    //   }    
    // }
  }


function writeEventsP(){
    console.log("writeEvent sP");  
    console.log(currentUser.calArray); 
    console.log(currentUser.luid);         
    allowInit = false; //forbid init from loading initcal!        
    firebase.database().ref('users/' + currentUser.luid).update(
      {        
        calArray: currentUser.calArray        
      });
    //   localStorage.setItem("currentUser", JSON.stringify(currentUser));
}

//------ END BUILDING THE CALENDARS--------------//

function resetCalAlt(events){
    // console.log(events);
    let elements =myCalendarAlt.getEvents();
    for (e in elements){ 
        let element = elements[e];
        element.remove();
    }
    myCalendarAlt.addEventSource(events);
}

function resetCal(events){
    // console.log(events);
    let elements =myCalendar.getEvents();
    for (e in elements){ 
        let element = elements[e];
        element.remove();
    }
    myCalendar.addEventSource(events);
}


//---------- BUTTONS ACTIONS -----------//


function toggleAllFavsSelection(id){
    console.log("toggleAffFavs ",id);
    event.stopPropagation(); 
}

function openChat(id){
    console.log("openChat ",id);
    event.stopPropagation(); 
    allowInit = false;
    
    // let tempChatIcon = document.getElementById(passedUserAppId.id).getElementsByClassName('fa-comment');
    // console.log(tempChatIcon[0]);
      
    // tempChatIcon[0].className = "chatIcon fa fa-comment";
  
    document.getElementById("singleUserPage").innerHTML='<object type="text/html" style="width:100vw; height:100vh;" data="../gse5/singleUser.html?id='+id+'"></object>';
  
    // let url="../gse5/singleUser.html?id="+passedUserAppId.id;
    // popupWindow = window.open(url,'popUpWindow','height=500,width=500,left=100,top=100,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no, status=yes').focus();
    var modal = document.getElementById("singleUser");  
    
    var span = document.getElementsByClassName("closeSingleUser")[0];
    
    modal.style.display = "block";
  
    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
      modal.style.display = "none";
    }
  
    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
      if (event.target == modal) {
        // modal.style.display = "none";
      }
    }
  }
  var onlyResourcesWithEventsCheck = false;
  function showOnlyResourcesWithEvents(){
      console.log(onlyResourcesWithEventsCheck);
      if(onlyResourcesWithEventsCheck == false){
          onlyResourcesWithEventsCheck = true;
          myCalendar.setOption('filterResourcesWithEvents','true');
      }
      else{
        onlyResourcesWithEventsCheck = false;
        myCalendar.setOption('filterResourcesWithEvents','false');
        buildresources();
        var mySelect = document.getElementById("foiSelector1");
        var fieldName = mySelect.value;
        console.log(fieldName);
        filterResourcesFOI(fieldName);
                         
      }
     

    
    //filter only with events 

  }
function toggleDisplay(){
      if (toggleDisplay_check == true){
            toggleDisplay_check =false;
            // myCalendar.destroy();
            // myCalendarAlt.destroy();
            // myCalendarAlt.render();
            // myCalendarAlt.refetchEvents();
            sourceCal = "alt";
            // document.getElementById('calendar').style.visibility = 'hidden';
            document.getElementById('calendarAlt').style.visibility = 'visible';
            document.getElementById('myList').style.visibility = 'hidden';  
      }
      else{
            toggleDisplay_check = true;
            sourceCal = "source";
            // document.getElementById('calendar').style.visibility = 'visible';
            document.getElementById('calendarAlt').style.visibility = 'hidden';
            document.getElementById('myList').style.visibility = 'hidden';
            // myCalendarAlt.destroy();
            // myCalendar.render();
            // myCalendar.refetchEvents();
            // resourcesCSS();
      }                
}


function toggleSelf(){
    console.log("toggleSelf");

    var allResources = myCalendar.getResources();
    //Show only myself and my events
    if (toggleSelfCheck === false){          
        toggleSelfCheck = true;
        for(e in allResources) {
            allResources[e].remove();
            }

        resourceA = 
                {
                    id:   currentUser.appId,
                    title: currentUser.name + " " + currentUser.lastName
                }
        myCalendar.addResource(resourceA);

        var resourceA = myCalendar.getResourceById(currentUser.appId);        
        allEvents = resourceA.getEvents();

        tempEventsFromResources = resourceA.getEvents();        
        resetCalAlt(tempEventsFromResources);
        resetCal(tempEventsFromResources); 
                      
    }
    else{
        //Show all users according to selected field of interest
          toggleSelfCheck = false;
            for(e in allResources) {
                allResources[e].remove();
            };         
            for (e in usersResourceList){            
                myCalendar.addResource(usersResourceList[e]);   
            };  

            var mySelect = document.getElementById("foiSelector1");
            var fieldName = mySelect.value;            
            filterResourcesFOI(fieldName);      
    }  
}

function backToCal(){
    //myCalendar
    console.log("backtoCal ", sourceCal);
    if(sourceCal == "single"){
        calendarSingle.destroy();
    }else if(sourceCal == "singleConfirm"){
        calendarConfirm.destroy();
    }
    
    
    document.getElementById("requestEv").style.display = "none";
    document.getElementById("backToCal").style.display = "none";
    document.getElementById("deleteEvent").style.display = "none";

    document.getElementById('trimB').style.display = "none"; 
    document.getElementById('confirmB').style.display = "none" 
    document.getElementById('declineB').style.display = "none"

    document.getElementById("toggleSelf").style.display = "";
    document.getElementById("toggleDisplay").style.display = "";
    document.getElementById("toggleResources").style.display = "";

    document.getElementById('label_AG').style.display = "";
    document.getElementById('acceptGuest_default').style.display = "";

    document.getElementById('label_AG_singlePage').style.display = "none";
    document.getElementById('acceptGuest_singlePage').style.display = "none";
    document.getElementById('AddEventManually').style.display = "";

    document.getElementById("calendar").style.visibility = "visible"; 
    document.getElementById("calendarAlt").style.visibility = "visible";

    toggleDisplay();
    if (toggleSelfCheck === true){
        toggleSelfCheck = false;
        toggleDisplay();
    }
    else{
        toggleSelfCheck = true;
        toggleDisplay();
    }

}



function requestEvent(){
    openTextModalPC();
}
  
// function sendRequestEventOld(){
//     console.log("request event");
    
//     var requestedEvents = calendar1.getEvents();
//     var requestedEve = [];
//     if(requestedEvents.length == 1){
//       requestedEve = requestedEvents[0];
//       requestedEve.title = currentUser.name +" " +currentUser.lastName;
//       requestedEve.description = "";
//       requestedEve.backgroundColor = color_guest_me;
//       requestedEve.setExtendedProp('acceptGuest',false);
//       requestedEve.setExtendedProp('appId',currentUser.appId);
//       requestedEve.setExtendedProp('auther',currentUser.name + " " + currentUser.lastName);    
//     }
//     else{
//       requestedEve = requestedEvents[1];
//     }
//     console.log(requestedEve);
//     // requestEventId  = requestedEve.id;
   
    
//     const origStartTime = moment(eventSingle.start);
//     const newStartTime = moment(requestedEve.start);
//     const origEndTime = moment(eventSingle.end);
//     const newEndTime = moment(requestedEve.end);
  
//     //add the event to both auther and me as an invisible event(or red), once it will be confirmed it, will show up.
   
//     let UniqueKey = Math.random().toString(36).substring(2);
  
    
//   //--Get the User who created the event!
//     allUsersSnapShot.forEach(function(child) { 
//       // console.log(child.val().appId + " : " + eventSingle.extendedProps.appId);
      
//       if(child.val().appId == eventSingle.extendedProps.appId){
//         nameTosend = child.val().name;
//         emailTosend = child.val().email;
//         requestAppId = currentUser.appId;
        
//         var tempEventsArray = child.val().calArray;
//         tempEventsArray = tempEventsArray.filter(function(e){return e}); 
        
//           // console.log(tempEventsArray);
//           //get the specific event for confirmation process
//           for (let index = 0; index < tempEventsArray.length; index++) {
//             const element = JSON.parse(tempEventsArray[index]);          
//               if(element.id == eventSingle.id){
  
//                 element.extendedProps.description = UniqueKey;
//                 tempEventsArray[index] = JSON.stringify(element);
  
//                 console.log("event found: ",element.id);
                 
//                 console.log (child.key);
//                 // console.log (child.
//                 firebase.database().ref('users/' + child.key).once('value').then(function(snapp){
//                   console.log(snapp.val().calArray);
//                 });
//                 allowInit = false;
//                 firebase.database().ref('users/' + child.key).update({
//                   calArray: tempEventsArray
//                 });
//                 break;                                
//             }        
//           }      
//       }                                       
//     });
    
//     firebase.database().ref('requests/'+UniqueKey).set(
//       {       
//         requestBy: currentUser.luid,      
//         origEvent: JSON.stringify(eventSingle),
//         requestedEvent: JSON.stringify(requestedEve),      
//       }   
//       ,function(error)
//       {
//         if (error) {
//           alert (error);
        
//           // The write failed...
//         }
//       }).then(() => {
        
  
//         //send an email to the auther
//         let mailBody = "Hello " + nameTosend + ".\n " + currentUser.name + " would like to book your offered session\n"+
//   "please follow this link to approve it\n"
//   + "roiwerner.com/gse5/singleEvent.html?&key="+UniqueKey;
  
//           let textAreaField = document.getElementById("textAreaField");        
//           if (textAreaField.value.length >0){
//             mailBody += "\n \n A message was sent as well: \n"+textAreaField.value;
//             textAreaField.value = "";
//           }
  
//           console.log(mailBody);
//           Email.send({
//                 Host: "smtp.ipage.com",
//                 Username : "roi@roiwerner.com",
//                 Password : "Roki868686",
//                 To : emailTosend,
//                 From : "<roi@roiwerner.com>",
//                 Subject : "Session booking",
//                 Body : mailBody,
//                 }).then(
//                   message => alert("mail sent successfully")
//               ); 
  
//       });
  
//   //console.log("send to: " + emailTosend +" from: " + currentUser.email + "event id: "+eventId);
  
    
//     // var tempiJ = JSON.stringify(requestedEve);
//     var tempi = requestedEve;
//     tempi.backgroundColor = color_special;
//     // tempi.extendedProps.acceptGuest = "waiting";
//     tempi.title = "pending approval";
    
//     // console.log(tempiJ.title);
//     console.log(tempi.title);
//     tempi.title = 'pending approval';
//     console.log(tempi.title);
//     // let r = Math.random().toString(36).substring(2);
  
//     newEvent = {
//       resourceId: currentUser.appId,
//       title: "pending approval",
//       start: tempi.start,
//       end: tempi.end,
//       id: tempi.id,                              
//       backgroundColor: "purple",
//       extendedProps:{
//         acceptGuest : 'waiting',
//         appId: currentUser.appId,
//         auther: currentUser.name,
//         reqKey: UniqueKey,
//         droppable: false
//       }
//     };
//     console.log(newEvent);
//     // return;
//     myCalendar.addEvent(newEvent);        
//     currentUser.calArray.push (JSON.stringify(newEvent));
//     // console.log(currentUser.calArray);
//     // newSelfEventsJSON=newSelfEventsJSON.concat(JSON.stringify(newEvent));
//     // console.log(newSelfEventsJSON);
    
      
//     writeEventsP();    
    
//     document.getElementById('calendarSingle').style.display = "none";
//     document.getElementById('calendar').style.display = "block";
//     document.getElementById('backToCal').style.display = "none";
//     document.getElementById('requestEv').style.display = "none";
//     document.getElementById('label_AG').style.display = "";
//     document.getElementById('acceptGuest_default').style.display = "";
//     calendar1.destroy();  
      
//     let allevents = myCalendar.getEvents(); 
//     allevents.forEach(el => { el.remove(); });
//     myCalendar.addEventSource(allevents);
    
//     //take the time from the event
    
// }

function openTextModalPC(message){
    var modal = document.getElementById("textArea");  
    var span = document.getElementsByClassName("closeText")[0]; 
    modal.style.display = "block";
  
    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
      modal.style.display = "none";
    }
  
    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
      if (event.target == modal) {
        // modal.style.display = "none";
      }
    }
  
}
  
function clearTextPC(){  
    console.log("clearText");
    let textAreaField = document.getElementById("textAreaField");
    console.log(textAreaField.value);
    textAreaField.value = "";
}

function deleteEvent(){
    console.log("Delete event: ",eventSingle)
    
       
    if(eventSingle.extendedProps.status === "waiting"){
        console.log("delete waiting event");
        let answer= confirm("This event is waiting confirmation, if you delete it, the request will be deleted.");
      
        if (answer ==false){ //cancel deletion
            return;
        }
        //get the request so i have the events ids:
        requestKey = eventSingle.extendedProps.description.split(":")[0];
        console.log(requestKey);
        firebase.database().ref('/requests/'+requestKey).once('value').then(function(snapshot){            
            let  originaleventToDelete = JSON.parse(snapshot.val().origEvent);            
            let requestEventToDelete = JSON.parse(snapshot.val().requestedEvent);            

            //-delete the request
            firebase.database().ref('/requests/'+requestKey).remove();

            //-delete the request from the asking user
            for(e in currentUser.calArray){
                let tempvar = JSON.parse(currentUser.calArray[e]);
                // console.log(tempvar.id);
                if (tempvar.id == eventSingle.id){
                    console.log("event found at index: " + e);
                    currentUser.calArray.splice(e ,1); 
                    allowInit = false;
                    myCalendar.getEventById(requestEventToDelete.id).remove();
                    myCalendarAlt.getEventById(requestEventToDelete.id).remove();                        
                    myCalendar.getEventById(originaleventToDelete.id).remove();
                    myCalendarAlt.getEventById(originaleventToDelete.id).remove(); 

                    break;
                    
                }
            }  
            console.log(currentUser.calArray);
            allowInit = false;
            firebase.database().ref('users/' + currentUser.luid).update(
            {        
                calArray: currentUser.calArray            
            });
                        

            //-update the event on the original side
            let creatorId = originaleventToDelete.extendedProps.appId;
            console.log(creatorId);
            allUsersSnapShot.forEach(function(child) { 
                // console.log(child.val().appId + " : " + eventSingle.extendedProps.appId);
                
                if(child.val().appId == creatorId){

                    console.log(child.key);
                    firebase.database().ref('/users/' + child.key).once('value').then(function(snapshot){
                        let originalUser = snapshot.val();
                        console.log(originalUser.calArray);
                        let localTempArray = originalUser.calArray;
                        for (e in localTempArray){
                            let element = JSON.parse(localTempArray[e]);                            
                            if (element.id == originaleventToDelete.id){
                                element.extendedProps.status = "open";
                                console.log(element);
                                localTempArray[e] = JSON.stringify(element);
                                myCalendar.addEvent(element);
                                myCalendarAlt.addEvent(element);
                                break;                               
                                
                            }
                        }
                        console.log(localTempArray);
                        //update the Firebase array of the user with the new info
                        allowInit = false;
                        firebase.database().ref('/users/'+child.key).update({
                            calArray: localTempArray
                        });
                        
                    });
                }
            
            });                          
        });  
        // writeEventsP();       
    }  
     
    else if (eventSingle.extendedProps.status == "pending"){

        let question = "This is a requested event!\nAre you sure you want to delete this event?\nIf you do, the event will be cancelled \nand a message will be sent to the other person!";
        
        
        let answer= confirm(question);
      
        if (answer ==false){ //cancel deletion
        return;
        }
        else
        {
            requestKey = eventSingle.extendedProps.description.split(":")[0];
            console.log(requestKey);
            firebase.database().ref('/requests/'+requestKey).once('value').then(function(snapshot){            
                let  originaleventToDelete = JSON.parse(snapshot.val().origEvent);            
                let requestEventToDelete = JSON.parse(snapshot.val().requestedEvent);            

                //-delete the request
                firebase.database().ref('/requests/'+requestKey).remove();
                
                //GET REQUESTOR EMAIL
                let requestorId = requestEventToDelete.extendedProps.appId;
                console.log(requestorId);
                allUsersSnapShot.forEach(function(child) { 
                    // console.log(child.val().appId + " : " + eventSingle.extendedProps.appId);
                    
                    if(child.val().appId == requestorId){
                        userEmail = child.val().email;
                        nameTosend = child.val().name;
                        console.log(nameTosend + ' ' + child.key);

                        //open Text
                        let textAreaField = document.getElementById("textAreaField");
                        let eventDate = moment(eventSingle.start).format("dddd, MMMM Do YYYY, h:mm:ss a");
                    
                        let mailBody = "Hello " + nameTosend + ".\n " + currentUser.name + " has deleted the event on "+ eventDate + 
                                        ". The request has been updated in your calendar";
                    
                            if (textAreaField.value.length >0){
                            mailBody += "\n \n A message was sent as well: \n"+textAreaField.value;
                            textAreaField.value = "";
                            }
                            // console.log(mailBody);       
                            
                            Email.send({
                                Host: "smtp.ipage.com",
                                Username : "roi@roiwerner.com",
                                Password : "Roki868686",
                                To : userEmail,
                                From : "<roi@roiwerner.com>",
                                Subject : "Session deleted",
                                Body : mailBody,
                                }).then(
                                  message => alert("mail sent successfully")
                              ); 

                            var tempArray = child.val().calArray
                            console.log(tempArray);
                                
                            for (e in tempArray){
                            let element = JSON.parse(tempArray[e])
                            console.log(element.id + ":" + eventSingle.id);
                                if(element.id == eventSingle.id){
                                // IN CASE I WANT TO CHNAGE THE EVENT FOR THE REQUESTER TO FREE TIME?
                                // element.title = "Confirmed by "+currentUser.name + " " + currentUser.lastName;
                                // element.backgroundColor = "red";
                                // element.extendedProps.acceptGuest = "booked";
                                // element.extendedProps.approvedBy = currentUser.luid;
                                // tempArray[e] = JSON.stringify(element);
                                    tempArray.splice(e,1);
                                    console.log("tempArray ",tempArray);
                                    console.log(child.key);
                                    allowInit = false;
                                        firebase.database().ref('/users/' + child.key).update({
                                            calArray: tempArray
                                        });
                                    break;        
                                }      
                            }
                    }
                });

                //delete the event from currentUser
                for(e in currentUser.calArray){
                    let tempvar = JSON.parse(currentUser.calArray[e]);
                    console.log(tempvar.id + " :: " + eventSingle.id );
                    if (tempvar.id == eventSingle.id){
                        console.log("event found at index: " + e);
                        currentUser.calArray.splice(e ,1);  
                        firebase.database().ref('/users/' + currentUser.luid).update({
                            calArray: currentUser.calArray
                        });   
                        break;
                        
                    }
                }
            });
            
            // remove the event from the calendars 
            myCalendar.getEventById(eventSingle.id).remove();
            myCalendarAlt.getEventById(eventSingle.id).remove();

        } 
    
    }
     
    else if(eventSingle.extendedProps.status == "booked"){
         let requestId = eventSingle.extendedProps.requestby;
         let approveId = eventSingle.extendedProps.approvedBy;
                        
        question = "This is a confirmed event!\nAre you sure you want to delete this event?\nIf you do, the event will be cancelled \nand a message will be sent to the other person!";
        let answer= confirm(question);
        if (answer ==false){ //cancel deletion
            return;
            }
        else
        {
            if(approveId != undefined){
                //I am the creator of this event                

                firebase.database().ref('/users/'+approveId).once('value').then(function(snapshot){

                    //send Email to the other side
                    userEmail = snapshot.val().email;
                    nameTosend = snapshot.val().name;
                    console.log(nameTosend + ' ' + userEmail);
                    //open Text
                    let textAreaField = document.getElementById("textAreaField");
                    let eventDate = moment(eventSingle.start).format("dddd, MMMM Do YYYY, h:mm:ss a");
                
                    let mailBody = "Hello " + nameTosend + ".\n " + currentUser.name + " has deleted the event on "+ eventDate + 
                                ". The request has been updated in your calendar";
            
                    if (textAreaField.value.length >0){
                    mailBody += "\n \n A message was sent as well: \n"+textAreaField.value;
                    textAreaField.value = "";
                    }
                    console.log(mailBody); 

                    Email.send({
                        Host: "smtp.ipage.com",
                        Username : "roi@roiwerner.com",
                        Password : "Roki868686",
                        To : userEmail,
                        From : "<roi@roiwerner.com>",
                        Subject : "Session deleted",
                        Body : mailBody,
                        }).then(
                            message => alert("mail sent successfully")
                        ); 

                    //open the event on the other side
                    let userToFindCalArray = snapshot.val().calArray;
                    console.log(userToFindCalArray);
                    for (let i = 0; i < userToFindCalArray.length; i++) {
                        let eventToUpdate = JSON.parse(userToFindCalArray[i]);
                        console.log(eventToUpdate.id);
                        console.log(eventSingle.id);
                        if (eventToUpdate.id == eventSingle.id){
                            console.log(eventToUpdate);
                            eventToUpdate.title = snapshot.val().name + " " + snapshot.val().lastName;
                            eventToUpdate.extendedProps.description="";
                            eventToUpdate.extendedProps.status = "open";
                            eventToUpdate.extendedProps.approvedBy = "";
                            userToFindCalArray.splice(i,1);
                            userToFindCalArray.push(JSON.stringify(eventToUpdate));
                            console.log(userToFindCalArray);
                            allowInit = false;
                            firebase.database().ref('/users/'+approveId).update({
                                calArray:userToFindCalArray
                            });
                            myCalendar.getEventById(eventSingle.id).remove();
                            myCalendarAlt.getEventById(eventSingle.id).remove();
                            break;
                        }
                    }                  
                });
            }
            else if(requestId != undefined){
                //I am the requestor of this event                
                                
                firebase.database().ref('/users/'+requestId).once('value').then(function(snapshot){

                    //send Email to the other side
                    userEmail = snapshot.val().email;
                    nameTosend = snapshot.val().name;
                    console.log(nameTosend + ' ' + userEmail);

                    //open Text
                    let textAreaField = document.getElementById("textAreaField");
                    let eventDate = moment(eventSingle.start).format("dddd, MMMM Do YYYY, h:mm:ss a");
                
                    let mailBody = "Hello " + nameTosend + ".\n " + currentUser.name + " has deleted the event on "+ eventDate + 
                                ". The request has been updated in your calendar";
            
                    if (textAreaField.value.length >0){
                    mailBody += "\n \n A message was sent as well: \n"+textAreaField.value;
                    textAreaField.value = "";
                    }
                    console.log(mailBody);       
                    
                    Email.send({
                        Host: "smtp.ipage.com",
                        Username : "roi@roiwerner.com",
                        Password : "Roki868686",
                        To : userEmail,
                        From : "<roi@roiwerner.com>",
                        Subject : "Session deleted",
                        Body : mailBody,
                        }).then(
                            message => alert("mail sent successfully")
                        ); 

                    //open the event on the other side
                    let userToFindCalArray = snapshot.val().calArray;
                    console.log(userToFindCalArray);
                    for (let i = 0; i < userToFindCalArray.length; i++) {
                        let eventToUpdate = JSON.parse(userToFindCalArray[i]);
                        console.log(eventToUpdate.id);
                        console.log(eventSingle.id);
                        if (eventToUpdate.id == eventSingle.id){
                            console.log(eventToUpdate);
                            eventToUpdate.title = snapshot.val().name + " " + snapshot.val().lastName;
                            eventToUpdate.extendedProps.description="";
                            eventToUpdate.extendedProps.status = "open";
                            eventToUpdate.extendedProps.approvedBy = "";
                            userToFindCalArray.splice(i,1);
                            userToFindCalArray.push(JSON.stringify(eventToUpdate));
                            console.log(userToFindCalArray);
                            allowInit = false;
                            firebase.database().ref('/users/'+requestId).update({
                                calArray : userToFindCalArray
                            });
                            myCalendar.getEventById(eventSingle.id).remove();
                            myCalendarAlt.getEventById(eventSingle.id).remove();
                            break;
                        }                      
                    }                    
                });
                
            }
            else{
                console.log("THERE IS AN ERROR HERE");
            }            
        }            

        //delete the event from currentUser
        for(e in currentUser.calArray){
            let tempvar = JSON.parse(currentUser.calArray[e]);
            console.log(tempvar.id + " :: " + eventSingle.id );
            if (tempvar.id == eventSingle.id){
                console.log("event found at index: " + e);
                currentUser.calArray.splice(e ,1); 
                allowInit = false;
                firebase.database().ref('/users/' + currentUser.luid).update({
                    calArray: currentUser.calArray
                });   
                break;                
            }
        }
        
        console.log("NOW DELETING EVENTS FROM CALS");
        // remove the event from the calendars 
        
    
    }

    else{
        //-delete the request from the asking user
        for(e in currentUser.calArray){
            let tempvar = JSON.parse(currentUser.calArray[e]);
            // console.log(tempvar.id);
            if (tempvar.id == eventSingle.id){
                console.log("event found at index: " + e);
                currentUser.calArray.splice(e ,1); 
                allowInit = false;
                firebase.database().ref('users/' + currentUser.luid).update(
                    {        
                        calArray: currentUser.calArray            
                    });
                myCalendar.getEventById(eventSingle.id).remove();
                myCalendarAlt.getEventById(eventSingle.id).remove();                                         
                break;
                
            }
        } 
    }
    // }
  
    // else if(eventSingle.extendedProps.acceptGuest == "waiting"){
    //   let answer= confirm("This event is waiting confirmation, if you delete it, the request will be deleted.");
      
    //   if (answer ==false){ //cancel deletion
    //     return;
    //   }
    //   //delete the request
    //   let requestKey = eventSingle.extendedProps.description.split(":")[0];
    //   console.log(requestKey);
    //   return;
    //   firebase.database().ref('/requests/'+requestKey).remove();    
    // }
    // else{
    //   let answer= confirm("Are you sure you want to delete this event?")
    //   if (answer ==false){ //CANCEL DELETION
    //     return;
    //   }
    // }
    
     
    // console.log(currentUser.calArray);
    // allowInit = false;
    
      
      
    
    // writeEventsP();    
    
    backToCal();
      
      // REMOVE THE 2 EVENTS WITH THE SAME ID BECASUE OF CONFIRMATION!
    //   var eventTodelete = myCalendar.getEventById(eventSingle.id);
    //   eventTodelete.remove();
    //   var eventTodelete1 = myCalendar.getEventById(eventSingle.id);
    //   eventTodelete1.remove();    
    //   let allevents = myCalendar.getEvents();
    //   allevents.forEach(el => { el.remove(); });            
    //   myCalendar.addEventSource(allevents);
}

function submitPC(){
   
    console.log("submit");
    if(sourceCal == "singleConfirm"){
        submit();
    }
    else{
        var modal = document.getElementById("textArea");  
        modal.style.display = "none";    
        sendRequestEvent();
    }
        
}

function sendRequestEvent(){
    console.log("request event: ",JSON.stringify( eventSingle));
    
    if(eventSingle.extendedProps.appId == currentUser.appId){
      console.log("should go to edit");    
      editEvent();
      return;
    }
  
  
    var requestedEvents = calendarSingle.getEvents();    
    var requestedEve = [];
    var origianlEvent = eventSingle;
    
    // console.log(origianlEvent);
    // console.log(JSON.parse(origianlEvent));
    
    if(requestedEvents.length == 1){
      requestedEve = requestedEvents[0];
          
    }
    else{
      requestedEve = requestedEvents[1];
    }
    let UniqueKey = Math.random().toString(36).substring(2);  
    
    newEvent = {
        resourceId: currentUser.appId,
        title: "pending approval",
        start: moment(requestedEve.start).format(),
        end: moment(requestedEve.end).format(),
        id: requestedEve.id,                              
        backgroundColor: color_toBook,
        extendedProps:{
          acceptGuest : false,
          appId: currentUser.appId,
          auther: currentUser.name,
          description: UniqueKey + ":" + origianlEvent.extendedProps.appId,
          status : "waiting",
          auther: currentUser.name + " " + currentUser.lastName
          
        }
      };    
    // console.log("NEW EVENT TO REQUEST"),JSON.stringify(newEvent));
    
    //add the event to both auther and me as an invisible event(or red), once it will be confirmed it, will show up.
   
    
  
    
  //--Get the User who created the event!
    allUsersSnapShot.forEach(function(child) { 
      // console.log(child.val().appId + " : " + eventSingle.extendedProps.appId);
      
      if(child.val().appId == origianlEvent.extendedProps.appId){
        nameTosend = child.val().name;
        emailTosend = child.val().email;
        requestAppId = currentUser.appId;
        
        var tempEventsArray = child.val().calArray;
        tempEventsArray = tempEventsArray.filter(function(e){return e}); 
        
          // console.log(tempEventsArray);
          //get the specific event for confirmation process
          for (let index = 0; index < tempEventsArray.length; index++) {
            const element = JSON.parse(tempEventsArray[index]);          
              if(element.id == origianlEvent.id){

                element.extendedProps.description = UniqueKey + ":" + currentUser.appId; 
                element.extendedProps.status = "pending";   
                // element.resourceId = eventSingle.getResources(),            
                tempEventsArray[index] = JSON.stringify(element);
                myCalendar.getEventById(origianlEvent.id).remove();
                myCalendarAlt.getEventById(origianlEvent.id).remove();
                myCalendar.addEvent(element);
                myCalendarAlt.addEvent(element);
                console.log(element);
                console.log("event found: ",element.id);
                origianlEvent = element;
                 
                console.log (child.key);
                // console.log (child.
                firebase.database().ref('users/' + child.key).once('value').then(function(snapp){
                  console.log(snapp.val().calArray);
                });
                allowInit = false;
                firebase.database().ref('users/' + child.key).update({
                  calArray: tempEventsArray
                });
                break;                                
            }        
          }      
      }                                       
    });
    
    firebase.database().ref('requests/'+UniqueKey).set(
      {       
        requestBy: currentUser.luid,      
        origEvent: JSON.stringify(origianlEvent),
        requestedEvent: JSON.stringify(newEvent),      
      }   
      ,function(error)
      {
        if (error) {
          alert (error);
        
          // The write failed...
        }
      }).then(() => {
        
  
        //send an email to the auther
        let mailBody = "Hello " + nameTosend + ".\n " + currentUser.name + " would like to book your offered session\n"+
                        "please follow this link to approve it\n"
                        + "roiwerner.com/gse5/singleEvent.html?&key="+UniqueKey;
                        // id="+eventSingle.id+"&id2="+requestEventId+"&id3="+requestAppId+"
  
          let textAreaField = document.getElementById("textAreaField");        
          if (textAreaField.value.length >0){
            mailBody += "\n \n A message was sent as well: \n"+textAreaField.value;
            textAreaField.value = "";
          }
  
          console.log(mailBody);
          Email.send({
                Host: "smtp.ipage.com",
                Username : "roi@roiwerner.com",
                Password : "Roki868686",
                To : emailTosend,
                From : "<roi@roiwerner.com>",
                Subject : "Session booking",
                Body : mailBody,
                }).then(
                  message => alert("mail sent successfully")
              ); 
  
      });
  
  //console.log("send to: " + emailTosend +" from: " + currentUser.email + "event id: "+eventId);
  
    
    // var tempi = requestedEve;
    // tempi.backgroundColor = color_special;    
    // tempi.title = 'pending approval';
    // console.log(tempi.title);
    // // let r = Math.random().toString(36).substring(2);
  
    // newEvent = {
    //   resourceId: currentUser.appId,
    //   title: "pending approval",
    //   start: tempi.start,
    //   end: tempi.end,
    //   id: tempi.id,                              
    //   backgroundColor: "purple",
    //   extendedProps:{
    //     acceptGuest : 'waiting',
    //     appId: currentUser.appId,
    //     auther: currentUser.name,
    //     reqKey: UniqueKey,
    //     droppable: false
    //   }
    // };
    // console.log(newEvent);
    // return;

    console.log("here I am");
    myCalendar.addEvent(newEvent); 
    myCalendarAlt.addEvent(newEvent);       
    // currentUser.calArray.push (JSON.stringify(requestedEvent[1]));
    // console.log(currentUser.calArray);
    console.log("THIS IS THE CALARRAY BEFORE ADDING:");
    console.log(currentUser.calArray);
    if(currentUser.calArray === undefined){
        currentUser.calArray = [];
      }
    
    currentUser.calArray.push(JSON.stringify(newEvent));    
          
    writeEventsP();    
    
    // document.getElementById('calendarSingle').style.display = "none";
    // document.getElementById('calendar').style.display = "block";
    // document.getElementById('backToCal').style.display = "none";
    // document.getElementById('requestEv').style.display = "none";
    // document.getElementById('label_AG').style.display = "";
    // document.getElementById('acceptGuest_default').style.display = "";
    backToCal(); 
      
    // let allevents = myCalendar.getEvents(); 
    // allevents.forEach(el => { el.remove(); });
    // myCalendar.addEventSource(allevents);
    
    //take the time from the event
    
}

//---------- END BUTTONS ACTIONS -----------//

//---------- CONFIRMATION CAL -------------//

function makeCalConfirm(){
        var calendarEl = document.getElementById('calendarSingle');
        calendarConfirm = new FullCalendar.Calendar(calendarEl, {
  
              initialView: 'timeGridDay',
              allDaySlot: false, 
              selectable: false,
              editable: false,
              droppable: false, 
              eventResizableFromStart: false,
              slotDuration: ('00:15:00'),
            //   slotMinTime: moment(eventi.start).format('HH:mm:ss'),
            //   slotMaxTime: moment(eventi.end).format('HH:mm:ss'),
              // height: (window.innerHeight)/2,
              
              eventContent: { domNodes: [] },
              eventContent: function(arg) {
                  let italicEl = document.createElement('p')
  
                      // if (arg.event.id == '1') {
                      //     italicEl.innerHTML = arg.event.title
                      // } else {
                      //     italicEl.innerHTML = arg.event.title
                      // }
                      italicEl.innerHTML = arg.event.title
                      let arrayOfDomNodes = [ italicEl ]
                      return { domNodes: arrayOfDomNodes }
              },
                  
              events: [
                  {                    
                  }                  
                ]                 
          });                           
          var timeSlotArray =document.getElementsByClassName("fc-event-draggable");
          var timeSlot = timeSlotArray[timeSlotArray.length-1];
}

var eventi = []; //originaleventToConfirm
var reqEvent=[];    // requestEventToConfirm

var event1 = [];
var event2 = [];
var event3 = [];
var eventi = [];
var reqEvent=[];
var requestKey = "";
calendarConfirm = FullCalendar;

function loadEventToConfirm(){
    sourceCal = "singleConfirm";
    requestKey = eventSingle.extendedProps.description.split(":")[0];
    console.log("loadEventToConfirm" ,requestKey);
    firebase.database().ref('/requests/'+requestKey).once('value').then(function(snapshot){            
        // let  originaleventToDelete = JSON.parse(snapshot.val().origEvent);            
        // let requestEventToDelete = JSON.parse(snapshot.val().requestedEvent); 
        eventi = JSON.parse(snapshot.val().origEvent);
        console.log(eventi.extendedProps.acceptGuest);

        reqEvent = JSON.parse(snapshot.val().requestedEvent);
        console.log(reqEvent);

        requestingUserId = snapshot.val().requestBy;
        

        makeCalConfirm();
        calendarConfirm.setOption("slotMaxTime", moment(eventi.end).format('HH:mm'));
        calendarConfirm.setOption("slotMinTime", moment(eventi.start).format('HH:mm'));

        document.getElementById("calendar").style.visibility = "hidden"; 
        document.getElementById("calendarAlt").style.visibility = "hidden";
        document.getElementById("calendarSingle").style.visibility = "visible";

        document.getElementById('deleteEvent').style.display = "inline-block";
        document.getElementById('label_AG_singlePage').style.display = "none";
        document.getElementById('acceptGuest_singlePage').style.display = "none";
        document.getElementById('AddEventManually').style.display = "none";
        document.getElementById('label_AG').style.display = "none";
        document.getElementById('acceptGuest_default').style.display = "none";
        document.getElementById('trimB').style.display = ""; 
        document.getElementById('confirmB').style.display = ""; 
        document.getElementById('declineB').style.display = "";
        document.getElementById("backToCal").style.display = "";

        
        // calendarConfirm.addEvent(eventi);
        // calendarConfirm.addEvent(reqEvent);
        

        let myself = currentUser.name + " " + currentUser.lastName;
        console.log(myself);
        let bookedTitled = "requested by: " + reqEvent.extendedProps.auther;
        console.log(bookedTitled);

        if (eventi.start == reqEvent.start && eventi.end == reqEvent.end){
            console.log("same time");
            event1= {resourceId:currentUser.appId, id:1 , title: bookedTitled, start: eventi.start, end: eventi.end, backgroundColor: 'red',extendedProps:{
              acceptGuest : eventi.extendedProps.acceptGuest,
              appId: currentUser.appId,
              auther: currentUser.name,
              requestby: requestingUserId,
              status: 'booked'
    
            //   droppable: false
            },};
            
            calendarConfirm.addEvent(event1);
            ccase = 1;
            
          }
          else if (eventi.start < reqEvent.start && eventi.end == reqEvent.end){
            console.log("start later");
    
            event1= {resourceId:currentUser.appId, id:1 , title: myself, start: eventi.start, end: reqEvent.start, backgroundColor: color_normal_me, extendedProps:{
              acceptGuest : eventi.extendedProps.acceptGuest,
              appId: currentUser.appId,
              auther: currentUser.name,
              status: 'open'
            //   droppable: false
            },
          
          };
            event2= {resourceId:currentUser.appId, id:2 , title: bookedTitled, start: reqEvent.start, end: eventi.end, backgroundColor: 'red',extendedProps:{
              acceptGuest : eventi.extendedProps.acceptGuest,
              appId: currentUser.appId,
              auther: currentUser.name,
              requestby: requestingUserId,
              status: 'booked'
            //   droppable: false
            },};
                                
            calendarConfirm.addEvent(event1);                    
            calendarConfirm.addEvent(event2);                                                           
            ccase = 2;
            
          }
          else if (eventi.start < reqEvent.start && eventi.end > reqEvent.end){
            console.log("start later end before");
            const tempEvent = eventi;
    
            event1= {resourceId:currentUser.appId, id:1 , title: myself, start: eventi.start, end: reqEvent.start, backgroundColor: color_normal_me, extendedProps:{
              acceptGuest : eventi.extendedProps.acceptGuest,
              appId: currentUser.appId,
              auther: currentUser.name,
              status: 'open'
            //   droppable: false
            },};
            event2= {resourceId:currentUser.appId, id:2 , title: bookedTitled, start: reqEvent.start, end: reqEvent.end,backgroundColor: 'red',extendedProps:{
              acceptGuest : eventi.extendedProps.acceptGuest,
              appId: currentUser.appId,
              auther: currentUser.name,
              requestby: requestingUserId,
              status: 'booked'
            //   droppable: false
            },};
            event3= {resourceId:currentUser.appId, id:3 , title: myself, start: reqEvent.end, end: eventi.end, backgroundColor: color_normal_me, extendedProps:{
              acceptGuest : eventi.extendedProps.acceptGuest,
              appId: currentUser.appId,
              auther: currentUser.name,
              status: 'open'
            //   droppable: false
            },};
                                
            calendarConfirm.addEvent(event1);                    
            calendarConfirm.addEvent(event2);                                                           
            calendarConfirm.addEvent(event3);
            ccase =3;
    
            
          }
          else if (eventi.start == reqEvent.start && eventi.end > reqEvent.end){
            console.log("start same end before");
            event1= {resourceId:currentUser.appId, id:1 , title: bookedTitled, start: eventi.start, end: reqEvent.end, backgroundColor: 'red',extendedProps:{
              acceptGuest : eventi.extendedProps.acceptGuest,
              appId: currentUser.appId,
              auther: currentUser.name,
              requestby: requestingUserId,
              status: 'booked'
            //   droppable: false
            },};
            event2= {resourceId:currentUser.appId, id:2 , title: myself, start: reqEvent.end, end: eventi.end,backgroundColor: color_normal_me, extendedProps:{
              acceptGuest : eventi.extendedProps.acceptGuest,
              appId: currentUser.appId,
              auther: currentUser.name,  
              status: 'open'      
            //   droppable: false
            },};
                                
            calendarConfirm.addEvent(event1);                    
            calendarConfirm.addEvent(event2);                     
            ccase =4;
            
          }

        calendarConfirm.render();
        calendarConfirm.gotoDate(moment(eventSingle.start).format());


    });

    
}

var confirmed = true;
var requestingUserId = "";

function confirmEvent(){
  console.log("confirm");
  confirmed = true;
  //open Text
  openTextModal();
}


function sendConfirmation(){
  console.log("sendConfirmation ", requestKey);
  

  //get requesting user email
  firebase.database().ref('/users/'+requestingUserId).once('value').then(function(snapshot){
    
    userEmail = snapshot.val().email;
    nameTosend = snapshot.val().name;

    //open Text
    let textAreaField = document.getElementById("textAreaField");

    let mailBody = "Hello " + nameTosend + ".\n " + currentUser.name + " approved your session request\n"+
                    "The request has been updated in your calendar";

    if (textAreaField.value.length >0){
      mailBody += "\n \n A message was sent as well: \n"+textAreaField.value;
      textAreaField.value = "";
    }
    console.log(mailBody);       
    Email.send({
        Host: "smtp.ipage.com",
        Username : "roi@roiwerner.com",
        Password : "Roki868686",
        To : userEmail,
        From : "<roi@roiwerner.com>",
        Subject : "Session request approved",
        Body : mailBody,
        }).then(
          message => alert("mail sent successfully")
      ); 

    //--update the reqested event on the requestBy side
    
    var tempArray = snapshot.val().calArray
    console.log(tempArray);
    

    for (e in tempArray){
      let element = JSON.parse(tempArray[e])
      console.log(element.id + ":" + reqEvent.id);
      if(element.id == reqEvent.id){
        element.resourceId = element.extendedProps.appId;
        element.title = "Confirmed by "+currentUser.name + " " + currentUser.lastName;
        element.backgroundColor = "red";
        element.extendedProps.status = "booked";
        element.extendedProps.approvedBy = currentUser.luid;
        tempArray[e] = JSON.stringify(element);
        console.log("tempArray ",tempArray);
        
        firebase.database().ref('/users/'+requestingUserId).update({
          calArray: tempArray
        });
        break;        
      }      
    }
    // return;
    //--update the event on the currentUser based on the split choice
    console.log(currentUser.luid);
    var tempUserArray = [];

    firebase.database().ref('/users/'+currentUser.luid).once('value').then(function(snap){
      tempUserArray = snap.val().calArray;

      for (e in tempUserArray){
        let element = JSON.parse(tempUserArray[e]);
        
        if (element.id == eventi.id){
          console.log(element);
          tempUserArray.splice(e,1);        
  
          if (event1Trimmed == false & event1.length != 0){ 
            event1.id = Math.random().toString(36).substring(2); 
            if(event1.extendedProps.status == "booked"){
              event1.id = reqEvent.id;
            }                    
            tempUserArray.push(JSON.stringify(event1));
          }
          if (event2Trimmed == false & event2.length != 0){
            event2.id = Math.random().toString(36).substring(2); 
            if(event2.extendedProps.status == "booked"){
              event2.id = reqEvent.id;
            } 
            tempUserArray.push(JSON.stringify(event2));
          }
          if (event3Trimmed == false & event3.length != 0){
            event3.id = Math.random().toString(36).substring(2); 
            if(event3.extendedProps.status == "booked"){
              event3.id = reqEvent.id;
            } 
            tempUserArray.push(JSON.stringify(event3));
          } 
          console.log("tempUserArray ",tempUserArray);  
          
          // -- update the current user in firebase
          currentUser.calArray = tempUserArray;
          firebase.database().ref('/users/'+currentUser.luid).update({
            calArray: tempUserArray
          },function(error, committed, snapshot) {
            if (error) {
              console.error(error);
            } else {
              //delete the request from 'requests'
              firebase. database().ref('/requests/'+requestKey).remove(); 
              console.log("tempUserArray ",tempUserArray); 
              // tempUserArray = currentUser.calArray;
              
              //go back to main window
                backToCal();
            }
            
          });
          break;          
        }      
      }
      
    });
  });  
}

function decline(){
  console.log("decline");
  confirmed = false;
  openTextModal();

}
function sendDecline(){
  console.log("sendDecline");
  //get requesting user email
  firebase.database().ref('/users/'+requestingUserId).once('value').then(function(snapshot){
    console.log(requestingUserId);
    
    userEmail = snapshot.val().email;
    nameTosend = snapshot.val().name;
    console.log(userEmail);

    

    let mailBody = "Hello " + nameTosend + ".\n " + currentUser.name + " has declined your session request\n"+
                    "The request has been deleted from your calendar";
    console.log(mailBody);

    //open Text
    let textAreaField = document.getElementById("textAreaField");        
    if (textAreaField.value.length >0){
      mailBody += "\n \n A message was sent as well: \n"+textAreaField.value;
      textAreaField.value = "";
    }
        
    Email.send({
        Host: "smtp.ipage.com",
        Username : "roi@roiwerner.com",
        Password : "Roki868686",
        To : userEmail,
        From : "<roi@roiwerner.com>",
        Subject : "Session request not approved",
        Body : mailBody,
        }).then(
          message => alert("mail sent successfully")
      ); 

    //delete the reqested event from firebase
    var tempArray = snapshot.val().calArray
    for (e in tempArray){
      let element = JSON.parse(tempArray[e])
      // console.log(element);
      if(element.id == reqEvent.id){
        console.log("event to delete found ", element.id + " " + snapshot.key);
        tempArray.splice(e ,1);
        console.log(tempArray);
        
        firebase.database().ref('/users/'+requestingUserId).update({
          calArray: tempArray
        });
        break;        
      }      
    }

    // set the event back to open state on user cal




    console.log(currentUser.luid);
    var tempUserArray = [];

    firebase.database().ref('/users/'+currentUser.luid).once('value').then(function(snap){
      tempUserArray = snap.val().calArray;

      for (e in tempUserArray){
        let element = JSON.parse(tempUserArray[e]);
        
        if (element.id == eventi.id){
          console.log(element);
          tempUserArray.splice(e,1); 
          // origEvent.extendedProps.description = "";
          element.extendedProps.description = "";

          console.log(element);
          // console.log(origEvent);
          // origEvent.setExtendedProp('description', "");                
          tempUserArray.push(JSON.stringify(element));
          
          console.log("tempUserArray ",tempUserArray);  
          
          // -- update the current user in firebase
          firebase.database().ref('/users/'+currentUser.luid).update({
            calArray: tempUserArray
          },function(error, committed, snapshot) {
            if (error) {
              console.error(error);
            } 
            
          });
          break;          
        }      
      }
      
    });

    //delete the request from 'requests'
    firebase.database().ref('/requests/'+requestKey).remove();

  });
  backToCal();
//   window.location.href = "../gse5/publicCalendar.html";

}
var isTrimmed = false;
var event1Trimmed = false;
var event2Trimmed = false;
var event3Trimmed = false;

function trimEvent(){
  isTrimmed = true;
  console.log("trim " ,ccase);
  let trimB = document.getElementById('trimB');
  trimB.innerHTML = "Undo trim";
  trimB.setAttribute('onclick', 'undoTrim()');

  if(ccase == 0){

  }
  else if(ccase == 1){ //same time
    // eventt1.remove();
    // event1="";

  }
  else if(ccase ==2){ //start later
    var eventTodelete = calendarConfirm.getEventById('1');
    eventTodelete.remove();
    event1Trimmed = true;
    // event1=[];
  }
  else if(ccase ==3){ //start later end early
    
    var eventTodelete = calendarConfirm.getEventById('1');
    eventTodelete.remove();
    var eventTodelete = calendarConfirm.getEventById('3');
    eventTodelete.remove();
    // event1 = [];
    // event3 = [];
    event1Trimmed = true;
    event3Trimmed = true;

  }
  else{ //end early
    var eventTodelete = calendarConfirm.getEventById('2');
    eventTodelete.remove();
    event2Trimmed = true;
    // event2=[];

  }
}

function undoTrim(){
  isTrimmed = false;
  event1Trimmed = false;
  event2Trimmed = false;
  event3Trimmed = false;

  let trimB = document.getElementById('trimB');
  trimB.innerHTML = "Trim";
  trimB.setAttribute('onclick', 'trimEvent()');
  if(ccase == 0){

  }
  else if(ccase == 1){ //same time
    // eventt1.remove();
    // event1="";

  }
  else if(ccase ==2){ //start later
    // var eventTodelete = calendarConfirm.getEventById('1');
    // eventTodelete.remove();
    // event1=[];
    calendarConfirm.addEvent(event1);
  }
  else if(ccase ==3){ //start later end early
    
    // var eventTodelete = calendar.getEventById('1');
    // eventTodelete.remove();
    // var eventTodelete = calendar.getEventById('3');
    // eventTodelete.remove();
    // event1 = [];
    // event3 = [];

    calendarConfirm.addEvent(event1);
    calendarConfirm.addEvent(event3);

  }
  else{ //end early
    // var eventTodelete = calendarConfirm.getEventById('2');
    // eventTodelete.remove();
    // event2=[];
    calendarConfirm.addEvent(event2);

  }
}

function cancel(){
 let r =  confirm ("Cacnel - you will be redirected to the calendar and can choose to confirm at another time"); 
  if (r == true){
      backToCal();
    // window.location.href = "../gse5/publicCalendar.html";
  }
}

function openTextModal(message){
    var modal = document.getElementById("textArea");  
    var span = document.getElementsByClassName("closeText")[0]; 
    modal.style.display = "block";
  
    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
      modal.style.display = "none";
    }
  
    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
      if (event.target == modal) {
        // modal.style.display = "none";
      }
    }
  
}
  
  var textTosend = "";
function submit(){
     
    console.log("submit");
    var modal = document.getElementById("textArea");  
    modal.style.display = "none";
    if (confirmed == true){
      sendConfirmation();
    }
    else{
      sendDecline();
    }
    
}
  
function clearText(){  
console.log("clearText");
let textAreaField = document.getElementById("textAreaField");
console.log(textAreaField.value);
textAreaField.value = "";
}


function toggleToolTip(){
    console.log(allowTippy)
    // var instance = tippy(document.querySelector('button'));
    if(allowTippy == true){
        allowTippy = false;
        
    }
    else{
        allowTippy = true;
        
    }
}

function deleteEvent1(){
    console.log("delete");
}


//---------- COLORS ----------
// is seperate script colors.js



//---------- no needed???? -----------//
// function toggleEvent(){      
//     let currentAllEvents = myCalendar.getEvents();
//     for (e in currentAllEvents){
//       currentAllEvents[e].remove();
//     }
//     myCalendar.addEventSource(allEvents);
// }

  