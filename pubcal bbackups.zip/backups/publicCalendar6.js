var currentUser = JSON.parse(localStorage.getItem("currentUser"));
allUsersNamesArray = [];
calAllEvents = [];
selectedUsers = [];
fbAllEvents = [];
myCalendar = FullCalendar;
var showFavsOnly = false;

var singleEventOriginalStart = "";
var singleEventOriginalEnd = "";

var currentdate = new Date();
var datetime = "Last Sync: " + currentdate.getDay() + "/" + currentdate.getMonth() 
+ "/" + currentdate.getFullYear() + " @ " 
+ currentdate.getHours() + ":" 
+ currentdate.getMinutes() + ":" + currentdate.getSeconds();

color_main = '#4ca8b8';
color_guest = '#18535e';
color_special = 'red';
color_normal_me = '#6aa059';
color_guest_me = '#285e18'


document.addEventListener('DOMContentLoaded', function() {
    console.log("build cal 2");
    
    //create tabs according to the user field of interest.
    createTabsNamesByInterest();
    
    isGuestsOnlyActive = document.getElementById('guestOnly');

    //enable 'ENTER' on search
    var input = document.getElementById("myInput")
    input.addEventListener("keyup", function(event) {
    // Number 13 is the "Enter" key on the keyboard
      if (event.keyCode === 13) {
        // Cancel the default action, if needed
        event.preventDefault();
        // Trigger the button element with a click
        document.getElementById("searchB").click();
      }
    });
  // InitCal(); is called from Init!
         
});


//----TABS-----//

function createTabsNamesByInterest (){
    let localFieldsOfInterest = [];
    for (i in currentUser.fieldsOfinterest){
      localFieldsOfInterest.push(currentUser.fieldsOfinterest[i]);
    }
    localFieldsOfInterest.push("All_as_guest");
    
    htmlString = '';
    tabsString = '';
    //console.log("create tabs local " + localFieldsOfInterest);
    //console.log("create tabs " + currentUser.fieldsOfinterest);
    
    for (i in localFieldsOfInterest){
        activeString = '';
        if(i == 0){
          activeString = " active";
        }
        currentField = localFieldsOfInterest[i]
        htmlString += "<button class='tablinks " + activeString + "' onclick='openTab(event, " +currentField + ")'>" + currentField + "</button>"
        tabsString += "<div id=" + currentField + " class='tabcontent'><h3>" + currentField + "</h3><div  id='allUsersDisplay'></div></div>"
    }
    htmlData = "<div id='tableTabsByInterest' class='tab'>"+htmlString+"</div>"+tabsString;
    document.getElementById("tabsNav").innerHTML = htmlData;
}

function openTab(evt, fieldName) {
    console.log(fieldName.id);
        if (fieldName.id == "All_as_geusts"){
      
    }
    else{        
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
          tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
          tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        // document.getElementById(fieldName.id).style.display = "block";
        evt.currentTarget.className += " active";  
    }

    filterCurrentInterest(fieldName.id)    
  }

var allEventsFromFBOrigin=[];
//   ------------------- CALENDAR ------------------
function InitCal(){    
      
      console.log("create events database from snapShot");
          
      var i =0;
      selfEvents = [];
      allUsersSnapShot.forEach(function(child) 
      {
                      
          //create a list of all users with out myself!
          let userFullName = child.val().name + " " + child.val().lastName
          if (child.val().appId != currentUser.appId){
          // //console.log("found: "+ child.val().appId);
              allUsersNamesArray.push({
                  key:   child.val().appId,
                  value: userFullName
              });  
          }

          else{
            // selfEvents = JSON.stringify(child.val().calArray);
            // if (child.val().calArray){
              
              let tempChildArray = child.val().calArray;

              if(tempChildArray.length != 0){                                        
                                                  
                  var localSelfCalArray = child.val().calArray;                  
                  var tempEvent = [];
                  for(v in localSelfCalArray){
                    // console.log(tempEvent.id + " "+ tempEvent.backgroundColor);
                    // console.log(JSON.stringify(tempEvent));
                    
                    tempEvent = JSON.parse(localSelfCalArray[v])
                    if (tempEvent.backgroundColor == "orange"){
                      tempEvent.editable = false;
                      tempEvent.droppable = false;
                    }
                    else if (tempEvent.extendedProps.acceptGuest == true){
                      tempEvent.backgroundColor = color_guest_me;
                      tempEvent.editable = true;
                      tempEvent.droppable = true;
                    }
                    else{
                      tempEvent.backgroundColor = color_normal_me;
                      tempEvent.editable = true;
                      tempEvent.droppable = true;
                    }                 
                    selfEvents = selfEvents.concat(tempEvent);
                    // currentUser.calArray = selfEvents;
              //       // console.log(fbAllEvents);
                    
              //       fbAllEvents = fbAllEvents.concat(JSON.stringify(tempEvent));                                 
                  }
                }                                              
          }
            
          // check if the user has a calendar including self!
          // if (child.val().calArray){
          //     let tempChildArray = child.val().calArray;

          //     //if there is no calenadar - do nothing 
          //     if(tempChildArray.length != 0){                                        

          //       //this is checking the current user (self)
          //       if(child.val().appId == currentUser.appId){
                  
          //         var localSelfCalArray = child.val().calArray;                  
          //         var tempEvent = [];
          //         for(v in localSelfCalArray){
          //           // console.log(tempEvent.id + " "+ tempEvent.backgroundColor);
          //           // console.log(JSON.stringify(tempEvent));
                    
          //           tempEvent = JSON.parse(localSelfCalArray[v])
          //           if (tempEvent.backgroundColor == "orange"){
          //             tempEvent.editable = false;
          //             tempEvent.droppable = false;
          //           }
          //           else if (tempEvent.extendedProps.acceptGuest == true){
          //             tempEvent.backgroundColor = color_guest_me;
          //             tempEvent.editable = true;
          //             tempEvent.droppable = true;
          //           }
          //           else{
          //             tempEvent.backgroundColor = color_normal_me;
          //             tempEvent.editable = true;
          //             tempEvent.droppable = true;
          //           }                 
          //           selfEvents = selfEvents.concat(tempEvent);
          //           // console.log(fbAllEvents);
                    
          //           fbAllEvents = fbAllEvents.concat(JSON.stringify(tempEvent));                                 
          //         }            
                  
          //       }
          //       //adding all the other users to the allEvents.
          //       else{                             
          //           var localSelfCalArray = child.val().calArray;                  
          //           var tempEvent = [];
          //           for(v in localSelfCalArray){
          //             // console.log(tempEvent.id + " "+ tempEvent.backgroundColor);
          //             // console.log(JSON.stringify(tempEvent));
                      
          //             tempEvent = JSON.parse(localSelfCalArray[v])
          //             if (tempEvent.backgroundColor == "orange"){
          //               tempEvent.display = 'none';
          //             }
          //             else if (tempEvent.extendedProps.acceptGuest == true){
          //               tempEvent.backgroundColor = color_guest;                        
          //             }
          //             else{
          //               tempEvent.backgroundColor = color_main;                        
          //             }                                                             
          //             fbAllEvents = fbAllEvents.concat(JSON.stringify(tempEvent));                                 
          //           } 
          //       }    
              // }                                  
          // };
          //once finished populate the users table and make the calendar
          i = i+1;
          if (i== allUsersSnapShot.numChildren()){      
            allEventsFromFBOrigin = fbAllEvents;
              eventsToBuildArray_cache = fbAllEvents;
              populateUsersTablePC(allUsersNamesArray);
              makeCal(fbAllEvents);
              filterCurrentInterest(currentUser.fieldsOfinterest[0]);                 
          };                            
        });
    // });
}


var runShowmyself = 0;
console.log("changing runShowmyself to 0");
var indexxxx=0;

function makeOneDayCal(event1){
  console.log(event1);
        eventSingle = event1;
        var calendarEl = document.getElementById('calendarSingle');
        calendarEl.style.display = "block";
        document.getElementById('calendar').style.display = "none";
        document.getElementById('backToCal').style.display = "block";
        document.getElementById('requestEv').style.display = "block";

        
        var scrollT = moment(event1.start).format('HH:mm:ss');
        console.log(scrollT);
        
        
        calendar1 = new FullCalendar.Calendar(calendarEl, {

            initialView: 'timeGridDay',
            allDaySlot: false, 
            selectable: false,
            dragScroll:false,
            editable: true,
            droppable: false, 
            eventResizableFromStart: true,
            slotDuration: ('00:15:00'),                         
            scrollTime: (scrollT),                
            events: [
                {
                  id: event1.id,
                  title: event1.title,
                  start: moment(event1.start).format(),
                  end: moment(event1.end).format(),  
                  backgroundColor: event1.backgroundColor,
                  display: 'background'               
                },
                {
                  id: event1.id,
                  title: event1.title,
                  start: moment(event1.start).format(),
                  end: moment(event1.end).format(),  
                  backgroundColor: "orange",
                  extendedProps:{
                    acceptGuest : event1.extendedProps.acceptGuest,
                    appId: currentUser.appId,
                    auther: currentUser.name,
                    droppable: true
                  },
                  // display: 'background'               
                }

              ]                 
        });

        calendar1.render();
        calendar1.gotoDate(moment(event1.start).format());
        
        var timeSlotArray =document.getElementsByClassName("fc-event-draggable");
        var timeSlot = timeSlotArray[timeSlotArray.length-1];
        
        timeSlot.className = "fc-timegrid-event fc-v-event fc-event fc-event-resizable fc-event-start fc-event-end fc-event-today fc-event-future"
        
        
        if(event1.extendedProps.appId != currentUser.appId){
            calendar1.setOption("slotMaxTime", moment(event1.end).format('HH:mm'));
            calendar1.setOption("slotMinTime", moment(event1.start).format('HH:mm'));
        }       
}


function makeCal(fbAllEvents){
  console.log("makecal");  
    
    var initView = 'timeGridWeek';
    if (myCalendar.view){
      initView = myCalendar.view.type;
      myCalendar.destroy();
    }
    
    var calendarEl = document.getElementById('calendar');
    //console.log("STOPPPPP");
    myCalendar = new FullCalendar.Calendar(calendarEl, {
      
      // Calendar Option
      initialView: initView,
      allDaySlot: false,      
      views: {
        timeGridDay: {
            type: 'timeGrid',
            scrollTime: '09:00:00',
        },
        timeGridWeek: {
            type: 'timeGrid',          
            scrollTime: '09:00:00',
        },
        dayGridMonth: {
            
        }
      },
      firstDay: moment().format('e'),
      dragScroll: false,
      now: moment().format(),
      nowIndicator: true,  
      editable: false,
      droppable: false,           
      selectable: true,
      selectOverlap: true,
      eventOverlap: true,
      aspectRatio: 1.8,
      scrollTime: '09:00', // undo default 6am scrollTime
      headerToolbar: {
        left: 'today prev,next',
        center: 'title',
        right: 'timeGridDay,timeGridWeek,dayGridMonth'
      },

      //------------------------
      //event Options
      
      drop: function(arg) {
        //console.log(arg);

      },
      eventResizeStart: function(arg){
        //console.log("eventResizeStart: ========",arg);
        var eventObj = arg.event;

        if (eventObj.extendedProps.appId != currentUser.appId){
          //console.log("Not your event, can't touch this.");
          // arg.revert();
          return;
        }
        
      },
      eventDrop: function(arg) { // called when an event (already on the calendar) is moved
        
        //console.log('eventDrop', arg.event);
        
        var eventObj = arg.event;

        if (eventObj.extendedProps.appId != currentUser.appId){
          //console.log("Not your event, can't touch this.");
          
          arg.revert();
          return;
        }
        else{
        var eventEnding = moment(eventObj.end);
            
          //console.log(eventEnding.format('HH:mm:ss'));
          //console.log(eventEnding.format('YYYY-MM-DD'));
  
  
          //--check if the current time clicked is before the end of event, if so allow to click, else do nothing.
          var timeClickedDate = Date.parse(moment().format('YYYY-MM-DD'));
          let endDate = Date.parse(eventEnding.format('YYYY-MM-DD'));
          if (timeClickedDate>endDate){
            //console.log("event is in the past");
            alert("You can not move an event in the past!");
            arg.revert();
            return;
          }
          else if (timeClickedDate == endDate){
            var timeClickedTime = moment().format('HH:mm:ss');
            let endTime = eventEnding.format('HH:mm:ss');
            
          
            
            str1 =  timeClickedTime.split(':');
            str2 =  endTime.split(':');
  
            //console.log(timeClickedTime + " " + endTime);
  
            totalSecondsTimeClicked = parseInt(str1[0] * 3600 + str1[1] * 60 + str1[0]);
            totalSecondsEndtime = parseInt(str2[0] * 3600 + str2[1] * 60 + str2[0]);
            //console.log(totalSecondsTimeClicked + " " + totalSecondsEndtime);
            if (totalSecondsTimeClicked > totalSecondsEndtime ){
              //console.log("event is in the past");
              alert("You can not move an event in the past!");
              return;
            }
            else{
              //console.log("event is in the future");
            }          
          }        
          writeEventsP();
        }
      },

      eventResize: function(info) {
        //console.log("Resize event: " ,info);

        var eventObj = info.event;
        if (eventObj.extendedProps.appId != currentUser.appId){
          //console.log("Not your event, can't touch this.");
          info.revert();
          return;
        }
        else{

        
        
        var eventEnding = moment(eventObj.end);
            
          //console.log(eventEnding.format('HH:mm:ss'));
          //console.log(eventEnding.format('YYYY-MM-DD'));
  
  
          //--check if the current time clicked is before the end of event, if so allow to click, else do nothing.
          var timeClickedDate = Date.parse(moment().format('YYYY-MM-DD'));
          let endDate = Date.parse(eventEnding.format('YYYY-MM-DD'));
          if (timeClickedDate>endDate){
            //console.log("event is in the past");
            alert("You can not edit an event in the past!");
            info.revert();
            return;
          }
          else if (timeClickedDate == endDate){
            //console.log("same day");
            
            var timeClickedTime = moment().format('HH:mm:ss');
            let endTime = eventEnding.format('HH:mm:ss');
            
          
            
            str1 =  timeClickedTime.split(':');
            str2 =  endTime.split(':');
  
            //console.log(timeClickedTime + " " + endTime);
  
            totalSecondsTimeClicked = parseInt(str1[0] * 3600 + str1[1] * 60 + str1[0]);
            totalSecondsEndtime = parseInt(str2[0] * 3600 + str2[1] * 60 + str2[0]);
            //console.log(totalSecondsTimeClicked + " " + totalSecondsEndtime);
            if (totalSecondsTimeClicked > totalSecondsEndtime ){
              //console.log("event is in the past");
              alert("You can not edit an event in the past!");
              return;
            }
            else{
              //console.log("event is in the future");
            }          
          }
  
  
  
  
        writeEventsP();
        }
      },
      
      select: function(info){
        console.log("select_______________");
        
        var eventObj = info.event;
        var eventEnding = moment(info.startStr);
            
        //console.log(eventEnding.format('HH:mm:ss'));
        //console.log(eventEnding.format('YYYY-MM-DD'));


        //--check if the current time clicked is before the end of event, if so allow to click, else do nothing.
        var timeClickedDate = Date.parse(moment().format('YYYY-MM-DD'));
        let endDate = Date.parse(eventEnding.format('YYYY-MM-DD'));
        if (timeClickedDate>endDate){
        //console.log("event is in the past");
        alert("You can not create an event in the past!");
        return;
        }
        else if (timeClickedDate == endDate){
            var timeClickedTime = moment().format('HH:mm:ss');
            let endTime = eventEnding.format('HH:mm:ss');
            
            
            
            str1 =  timeClickedTime.split(':');
            str2 =  endTime.split(':');

            //console.log(timeClickedTime + " " + endTime);

            totalSecondsTimeClicked = parseInt(str1[0] * 3600 + str1[1] * 60 + str1[0]);
            totalSecondsEndtime = parseInt(str2[0] * 3600 + str2[1] * 60 + str2[0]);
            //console.log(totalSecondsTimeClicked + " " + totalSecondsEndtime);
            if (totalSecondsTimeClicked > totalSecondsEndtime ){
                //console.log("event is in the past");
                alert("You can not create an event in the past!");
                return;
            }
            else{
                //console.log("event is in the future");
            }          
        }
   
        //console.log(document.getElementById('acceptGuest_default').checked);
        // var currentUser = JSON.parse(localStorage.getItem("currentUser"));
        let r = Math.random().toString(36).substring(2);
        var allowGuest = false;
        var bgColor = color_normal_me;
        if (document.getElementById('acceptGuest_default').checked==true){
          allowGuest = true;
          bgColor = color_guest_me;
        }
        myCalendar.addEvent({
                id: r,
                title: currentUser.name +" " +currentUser.lastName,
                start: info.startStr,
                end: info.endStr,
                allDay: false,
                editable: true,
                droppable: true,
                
                backgroundColor: bgColor,
                appId: currentUser.appId,
                auther: currentUser.name,
                acceptGuest : allowGuest
              });
  
        CurrentEvent = myCalendar.getEventById(r);                        
        
        // currentUser.calArray = [];
        // localStorage.setItem("currentUser", JSON.stringify(currentUser));
        var tempArrayOfAll = [];
        if(typeof(selfEvents)!==undefined){

          if(selfEvents.length>0){
            tempArrayOfAll = selfEvents;
          }                              
          //console.log("tempArrayOfAll defined " + tempArrayOfAll.length);
          
        }
        else{
          //console.log("tempArrayOfAll not defined" + tempArrayOfAll);
        }
         
        
        selfEvents.push(JSON.stringify(CurrentEvent));
        // //console.log("tempArrayOfAll: " ,tempArrayOfAll);
        
        // var tempArrayOfAll =  tempArrayOfAll.concat(JSON.stringify(CurrentEvent));
        // //console.log("tempArrayOfAll: " ,tempArrayOfAll);
        // //console.log(tempArrayOfAll);
        // currentUser.calArray = tempArrayOfAll;

        console.log("selfEvents ",selfEvents);
        

        //save all events to firebase
        // saveAllEvents(myCalendar);
        writeEventsP();

      },

      eventClick: function(info) {
        
        //console.log(info);
        
        var eventObj = info.event;
        userAppId = eventObj.extendedProps.appId;
        
        if (eventObj.url) {
          alert(
            'Clicked ' + eventObj.title + '.\n' +
            'Will open ' + eventObj.url + ' in a new tab'
          );
          window.open(eventObj.url);
          info.jsEvent.preventDefault(); // prevents browser from following link in current tab.
        } else {

          //--1/ check if the evnt autor is the suer                    


              $('#datetime15').combodate('setValue', moment(eventObj.start).format('hh:mm A'));
              $('#datetime16').combodate('setValue', moment(eventObj.end).format('hh:mm A'));
              
              singleEventOriginalStart = $('#datetime15').combodate('getValue');
              singleEventOriginalEnd = $('#datetime16').combodate('getValue');
              console.log("singleEventOriginalEnd",singleEventOriginalEnd);
              
                    
              var eventName = document.getElementById('eventName');
              var eventDate = moment(eventObj.start).format('YYYY/MM/DD');
              // var eventStart = moment(eventObj.start).format('hh:mm A');
              // var eventEnd = moment(eventObj.end).format('hh:mm A');
              eventAuther = eventObj.auther;
              // var eventId = eventObj.id;
              eventId = eventObj.id;
          
              document.getElementById('eventName').innerHTML = eventObj.title;
              document.getElementById('eventDate').innerHTML = moment(eventDate).format('DD - MMMM - YYYY');
              
              CurrentEvent=myCalendar.getEventById(eventId);
          
            var eventEnding = moment(eventObj.end);                        

            var timeClickedDate = Date.parse(moment().format('YYYY-MM-DD'));
            let endDate = Date.parse(eventEnding.format('YYYY-MM-DD'));
            
            if (timeClickedDate>endDate){
            //console.log("event is in the past");
            alert("You can not select an event in the past!");
            return;
            }
            else if (timeClickedDate == endDate){
                var timeClickedTime = moment().format('HH:mm:ss');
                let endTime = eventEnding.format('HH:mm:ss');                
                
                str1 =  timeClickedTime.split(':');
                str2 =  endTime.split(':');

                //console.log(timeClickedTime + " " + endTime);

                totalSecondsTimeClicked = parseInt(str1[0] * 3600 + str1[1] * 60 + str1[0]);
                totalSecondsEndtime = parseInt(str2[0] * 3600 + str2[1] * 60 + str2[0]);
                //console.log(totalSecondsTimeClicked + " " + totalSecondsEndtime);
                if (totalSecondsTimeClicked > totalSecondsEndtime ){
                    //console.log("event is in the past");
                    alert("You can not select an event in the past!");
                    return;
                }
                else{
                    //console.log("event is in the future");
                }          
            }  
            
            // -------------
            makeOneDayCal(eventObj)             
        }
      },
      dateClick: function(info) {
        //console.log('clicked ' + info.dateStr);
      }         
    });
    console.log("stop?");
    
    myCalendar.render();    
}

function populateUsersTablePC(usersToPopulateTable){
    //console.log(usersToPopulateTable);
    
    //populate the names table as an HTML 
    
    let tempString = '';
    let dataHtml = '';
    var displayedNamesArray = [];
    mainDiv = document.getElementById('external-events');
    
    k=0;
    //check inside all the users if there is a fav
    for (var i in usersToPopulateTable){      

      // check if the user is selected (for filtering) and mark the check box on
      for (var temp in selectedUsers){
        if (selectedUsers[temp] == usersToPopulateTable[i] )
        {
          tempString="checked";
          break;
        }
      }
      k = k+1;

      displayedNamesArray = displayedNamesArray.concat(usersToPopulateTable[i].value);
      //create the HTML code
      let fbUserAppId = JSON.stringify(usersToPopulateTable[i].key);
      
      fbUserAppIdTrimed = fbUserAppId.slice(1, -1);
      dataHtml += "<div id='" + fbUserAppIdTrimed + "'class='user_row' onclick='toggleUserSelection(" + fbUserAppId + ")'>"+
      "<i class='fa fa-eye-slash' id='toggleUserSelection" + fbUserAppIdTrimed + "' onclick='toggleUserSelection(" + fbUserAppId + ")'>"+
      "</i>"+
      "<p onclick='openUser(" + fbUserAppIdTrimed + ")'>" + usersToPopulateTable[i].value + "</p>";      
      myFavArray = currentUser.favoritesArray;
      //check if the user is a favorite and check the box on
      var string = "<i class='favIcon fa fa-star'";
      // //console.log("HELLLLLLLOOOOOOO! "+currentUser.favoritesArray);
        if (typeof myFavArray === 'undefined' || myFavArray === null) {

        }
        else {
          for (i in myFavArray){
            // //console.log(myFavArray[i] + "  " + fbUserAppIdTrimed);
              if (myFavArray[i] == fbUserAppIdTrimed){
              //   document.getElementById("toggleUserSelection",fbUserAppIdTrimed).checked = true;
              string = "<i class='favIcon fa fa-heart'";
              break;
              }                                             
          }
        }
      dataHtml += "<i class='chatIcon fa fa-comment' onclick='openUser(" + fbUserAppIdTrimed + ")'></i>" + string + " id='toggleFavorite1"+ fbUserAppIdTrimed +"' onclick='toggleFavorite1(" + fbUserAppId + ")'></i></div>"; 
            
    };
    if (k == usersToPopulateTable.length){
      //update the users table and fill in the autocomplete for search
      mainDiv.innerHTML += dataHtml;
      // console.log("usersToPopulateTable++++++++++++++",typeof(usersToPopulateTable),usersToPopulateTable);
      autocomplete(document.getElementById("myInput"), displayedNamesArray);      
    };
  }

  

  var tempUsersByInterestArray = [];
  var tempEventForInterest=[];
  var selfEvents = [];
  
  function filterCurrentInterest(currentField){
    console.log("filterCurrentInterest: " ,currentField);    
     
      console.log("filtering now: " ,currentField);      
      tempUsersByInterestArray = [];
      tempEventForInterest=[];
      
      //--filter out the users based on FOI
      var localUsersArray = allUsersSnapShot.toJSON();
      allUsersSnapShot.forEach(function(child) {

      var tempFieldsArray = child.val().fieldsOfinterest;

      if (tempFieldsArray === undefined){
        // console.log("undifined tempFieldArray");
        
      }        
      else{
        // create the user list
        if(currentField == "All_as_guest"){
              tempUsersByInterestArray.push({
                key:   child.val().appId,
                value: child.val().name + " " + child.val().lastName
              }); 

            let tempArray = child.val().calArray;
            if (typeof(tempArray)=== undefined || tempArray === undefined){
              //console.log("no array found ");
            }
            else{
              if(tempArray === undefined){
                //console.log("emptry bastered");
                
              }
              else {
                if(child.val().appId == currentUser.appId){
                    var localSelfCalArray = child.val().calArray;

                    tempEvent = [];
                    console.log(tempEvent.backgroundColor);

                    //check if the event are by the current user and if so change the color
                  for(v in localSelfCalArray){
                    tempEvent = JSON.parse(localSelfCalArray[v])
                    if (tempEvent.extendedProps.acceptGuest == true){
                      tempEvent.backgroundColor = color_guest_me;
                      tempEvent.editable = true;
                      tempEvent.droppable = true;
                      console.log(typeof(selfEvents));                        
                    }
                    else{
                      tempEvent.backgroundColor = color_normal_me;
                      tempEvent.editable = true;
                      tempEvent.droppable = true;
                    }                                      
                  }                    
                }
                else{
                    console.log(child.val().name);
                    
                    var localSelfCalArray = child.val().calArray;
                    //console.log(typeof(localSelfCalArray));
                    //console.log(localSelfCalArray);
                    //console.log("STOPPPPP");
                    
                    for (i in localSelfCalArray){
                      let tempVar = JSON.parse(localSelfCalArray[i]);
                        //console.log(tempVar.backgroundColor);
                        if (tempVar.backgroundColor == "orange"){
                          // tempVar.display = 'none';

                        }
                        else if (tempVar.extendedProps.acceptGuest == true){
                          tempVar.backgroundColor = color_guest;
                          tempEventForInterest = tempEventForInterest.concat(tempVar);  
                        }
                        else{
                          tempVar.backgroundColor = color_main;
                        } 
                                         
                    }                                             
                  }                
              } 
            } 







        }
        else{
            if (Object.values(tempFieldsArray).includes(currentField)) {
                if(child.val().appId != currentUser.appId){
                  // console.log(child.val().name);
                  tempUsersByInterestArray.push({
                      key:   child.val().appId,
                      value: child.val().name + " " + child.val().lastName
                  }); 
                }
              
                // create the Event lists for the relevent users
                let tempArray = child.val().calArray;
                if (typeof(tempArray)=== undefined || tempArray === undefined){
                  //console.log("no array found ");
                }
                else{
                  if(tempArray === undefined){
                    //console.log("emptry bastered");
                    
                  }
                  else {
                    if(child.val().appId == currentUser.appId){
                        var localSelfCalArray = child.val().calArray;

                        tempEvent = [];

                        //check if the event are by the current user and if so change the color
                      for(v in localSelfCalArray){
                        tempEvent = JSON.parse(localSelfCalArray[v])
                        if (tempEvent.extendedProps.acceptGuest == true){
                          tempEvent.backgroundColor = color_guest_me;
                          tempEvent.editable = true;
                          tempEvent.droppable = true;
                          // console.log(typeof(selfEvents));                        
                        }
                        else{
                          tempEvent.backgroundColor = color_normal_me;
                          tempEvent.editable = true;
                          tempEvent.droppable = true;
                        }                                          
                      }                    
                    }
                    else{
                        // console.log(child.val().name);
                        
                        var localSelfCalArray = child.val().calArray;                                                
                        for (i in localSelfCalArray){
                          let tempVar = JSON.parse(localSelfCalArray[i]);
                            //console.log(tempVar.backgroundColor);
                            if (tempVar.extendedProps.acceptGuest == true){
                              tempVar.backgroundColor = color_guest;
                            }
                            else{
                              tempVar.backgroundColor = color_main;
                            } 
                            tempEventForInterest = tempEventForInterest.concat(tempVar);                   
                        }                                             
                      }                
                  } 
                }                                         
              }  
            }
          }
      });

      //check if there are selected users
      console.log("selected Users: ",selectedUsers);
      if(selectedUsers.length>0){
        
        for (let index = 0; index < selectedUsers.length; index++) {
          const element = selectedUsers[index];
          console.log(element);
                    
          for (h in tempUsersByInterestArray) {
            console.log(h);
            
            console.log(tempUsersByInterestArray[h].key);
            if(tempUsersByInterestArray[h].key == element){
              console.log("Found a match");
              let filteredEventsByInterest = tempEventForInterest

              // c = a.filter( x => !b.filter( y => y.id === x.id).length);
              filterOne(tempUsersByInterestArray[h].key)

              break;
              
            } 
          }                            
        
        
        // console.log("sortedEventsArra 4: ",sortedEventsArray);        
        // load the selected state!
        // populateUsersTablePC(tempUsersByInterestArray);
        // filterCal(sortedEventsArray);
        populateUsersTablePC(tempUsersByInterestArray);
        keepSelectedUsersOn();
        return;
        // return;

      }      
      
      // filterCal(tempEventForInterest);
      //console.log(tempEventForInterest);
      populateUsersTablePC(tempUsersByInterestArray);

    }
      
    //refresh the calendar!
    console.log("tempEventForInterest:____",tempEventForInterest);
    const unique = Array.from(new Set(tempEventForInterest.map(JSON.stringify))).map(JSON.parse);
    filterCal(unique);
    // let allevents = myCalendar.getEvents(); 
    // allevents.forEach(el => { el.remove(); })
    // myCalendar.addEventSource(tempEventForInterest);
  
    
}

function returnTable(){
    //console.log(JSON.stringify(CurrentEvent));
    // CurrentEvent.remove();
    calendarDiv.style.display = "block";
    document.getElementById('singleEvent').style.display = "none";  
    myCalendar.render();
}

function writeEventsP(){
    //TODO - fix the write events to have only the user's
    array = selfEvents; 
    console.log(array);
         
         
    // firebase.database().ref('users/' + currentUser.luid).update(
    //   {
    //     calArray: array        
    //   });
    //   localStorage.setItem("currentUser", JSON.stringify(currentUser));
}



function openUser(passedUserAppId){

  event.stopPropagation();  
  console.log(passedUserAppId.id);
  
  let tempChatIcon = document.getElementById(passedUserAppId.id).getElementsByClassName('fa-comment');
  console.log(tempChatIcon[0]);
    
  tempChatIcon[0].className = "chatIcon fa fa-comment";

  document.getElementById("singleUserPage").innerHTML='<object type="text/html" style="width:100vw; height:100vh;" data="../gse5/singleUser.html?id='+passedUserAppId.id+'"></object>';

  // let url="../gse5/singleUser.html?id="+passedUserAppId.id;
  // popupWindow = window.open(url,'popUpWindow','height=500,width=500,left=100,top=100,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no, status=yes').focus();
  var modal = document.getElementById("singleUser");  
  var span = document.getElementsByClassName("close")[2];
  // document.getElementById("sendOrdelete").innerHTML = "Delete Event";
  // document.getElementById("sendOrdelete").onclick = function(){
  //   deleteEvent(eventObj);
  // }
  modal.style.display = "block";

  // When the user clicks on <span> (x), close the modal
  span.onclick = function() {
    modal.style.display = "none";
  }

  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    if (event.target == modal) {
      // modal.style.display = "none";
    }
  }


}


function editEventOld(eventObj){
  //console.log("edit Event");
  // var modal = document.getElementById("myModal");  
  // var span = document.getElementsByClassName("close")[0];
  // document.getElementById("sendOrdelete").innerHTML = "Delete Event";
  // document.getElementById("sendOrdelete").onclick = function(){
  //   deleteEvent(eventObj);
  // }
  // modal.style.display = "block";

  // // When the user clicks on <span> (x), close the modal
  // span.onclick = function() {
  //   modal.style.display = "none";
  // }

  // // When the user clicks anywhere outside of the modal, close it
  // window.onclick = function(event) {
  //   if (event.target == modal) {
  //     // modal.style.display = "none";
  //   }
  // }

}


function popUpEvent(eventObj){
  //console.log("Pop Event");
  
  // var modal = document.getElementById("myModal");  
  // var span = document.getElementsByClassName("close")[0];
  
  // document.getElementById("sendOrdelete").innerHTML = "Request Event";

  // document.getElementById("sendOrdelete").onclick = function(){
  //   requestEvent(eventObj);
  // }
  
  
  // modal.style.display = "block";
  // // When the user clicks on the button, open the modal
  // // btn.onclick = function() {
  // //   modal.style.display = "block";
  // // }

  // // When the user clicks on <span> (x), close the modal
  // span.onclick = function() {
  //   modal.style.display = "none";
  // }

  // // When the user clicks anywhere outside of the modal, close it
  // window.onclick = function(event) {
  //   if (event.target == modal) {
  //     // modal.style.display = "none";
  //   }
  // }
  // let url="../gse5/singleEvent.html";
  // popupWindow = window.open(url,'popUpWindow','height=500,width=500,left=100,top=100,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no, status=yes');
  
}


function requestEventOld(eventObj){

  console.log(eventObj);
    //TODO:
    // get the times
    var eventDate = document.getElementById('eventDate').innerHTML;
    // var eventDate = eventObj.date;
    
    let tempStart = $('#datetime15').combodate('getValue');    
    var startTime = moment(eventDate).format('MM DD YYYY') + " " + tempStart;
    var origStart = moment(eventDate).format('MM DD YYYY') + " " + singleEventOriginalStart;
    console.log(moment(startTime).format());

    let tempEnd = $('#datetime16').combodate('getValue');
    var endTime = moment(eventDate).format('MM DD YYYY') + " " + tempEnd;
    var origEnd = moment(eventDate).format('MM DD YYYY') + " " + singleEventOriginalEnd;
    
    if (moment(startTime).isBefore(moment(origStart))){
      alert ("Please make sure the start time is after "+moment(origStart).format('hh:mm A'))  ; 
      return;        
    }
    
    if (moment(endTime).isAfter(moment(origEnd))){
      alert ("Please make sure the end time is before "+moment(origEnd).format('hh:mm A')) ;
      return;            
    }
    
    // let startTime = moment(eventDate) + " " + moment(tempStart);
    
    
    alert ("an email will be sent");
    // return;
    var i =0;
    //-- find the relevant calendar by user and then find the relevant event!
    //-- find item in JSON example !!!!
    allUsersSnapShot.forEach(function(child) { 
      // //console.log(child.val().appId);
      
      if(child.val().appId == eventObj.extendedProps.appId){
        nameTosend = child.val().name;
        emailTosend = child.val().email;
        // if (child.val().calArray){
        //   var fbUserEventsArray = child.val().calArray;
          
        //   // let obj = JSON.parse(fbUserEventsArray);
        //   // for (i in obj){
        //   //   if (obj[i].id == eventId){
        //   //     //console.log(obj[i]);
        //   //   }            
        //   // }             
        // };
      }                                       
    });
  
  //console.log("send to: " + emailTosend +" from: " + currentUser.email + "event id: "+eventId);

  let mailBody = "Hello " + nameTosend + ".\n " + currentUser.name + "would like to book you offered session\n"+
  "please follow this link to approve it\n"
  + "roiwerner.com/gse5/singleEvent.html?id="+eventObj.id;
    
  Email.send({
    Host: "smtp.ipage.com",
    Username : "roi@roiwerner.com",
    Password : "Roki868686",
    To : emailTosend,
    From : "<roi@roiwerner.com>",
    Subject : "Session booking",
    Body : mailBody,
    }).then(
      message => alert("mail sent successfully")
    );    
}


function deleteEvent1(){
  let eventObj = eventSingle;
  let answer= confirm("Are you sure you want to delete this event?")
  if (answer ==true){
    //console.log("delet Event: " + eventObj.id);
    var eventTodelete = myCalendar.getEventById(eventObj.id);
    eventTodelete.remove();

    // var modal = document.getElementById("myModal");
    // modal.style.display = "none";

    for(e in selfEvents){
      let tempvar = JSON.parse(selfEvents[e]);
      //console.log(tempvar.id);
      if (tempvar.id == eventObj.id){
        //console.log("event found at indes: " + e);
        // currentUser.calArray.splice(e, 1); 
        selfEvents.splice(e ,1);     
        break;
        
      }
    }
    
    writeEventsP();
    backToCal();
    let allevents = myCalendar.getEvents(); 
    allevents.forEach(el => { el.remove(); });
    myCalendar.addEventSource(allevents);

    
  
  }
  //remove from currentUser.calArray
  
  
  
  
  //remove from calendar
  //remove from firebase
  
}

var tempFilteredEvents = [];
//------------- TOGGLE USER SELECTION ------------------//

function filterOne(appId){
  console.log("filterOne");
  
  // if (calAllEvents.length==0){
  //   calAllEvents = myCalendar.getEvents();
  // }


  // if (showMyself)
   
  //   console.log(calAllEvents);

    // console.log("filter one:" ,appId);
    console.log(tempEventForInterest);
    
  var newFilteredArray =  tempEventForInterest.filter(function(filter) {
  return filter.extendedProps.appId == appId;
    });
  console.log(newFilteredArray);
  
  if (selectedUsers.length>1){

    console.log("more then 1 user");    
    sortedEventsArray = sortedEventsArray.concat(newFilteredArray);
    console.log("sortedEventsArra 1: ",sortedEventsArray);
    //console.log("filter call 1");
    tempFilteredEvents = sortedEventsArray;
    // filterCal(sortedEventsArray);  
  
    
  }
  else{
    console.log("first selected user");
    
      sortedEventsArray = newFilteredArray;
      tempFilteredEvents = sortedEventsArray;
      //console.log("sorted array: ",sortedEventsArray);
      //console.log("filter call 2");
      console.log(selfEvents);
        
      console.log("sortedEventsArra 2: ",sortedEventsArray);
      // filterCal(sortedEventsArray);
      
      
  }
  
  // let SortedEventWithSelf = sortedEventsArray.concat(selfEvents);
  filterCal(sortedEventsArray);

}
sortedEventsArray = [];

function unfilterOne(appId){
console.log("unfilterOne");

    
  var newFilteredArray =  sortedEventsArray.filter(function(filter) {
  return filter.extendedProps.appId == appId;
  });
  // //console.log(newFilteredArray);
  for(g in newFilteredArray){
    var tempFilteredEvent = newFilteredArray[g];
    sortedEventsArray.splice( sortedEventsArray.indexOf(tempFilteredEvent), 1 );
      // sortedEventsArray = sortedEventsArray.concat(JSON.parse(tempFilteredEvent));
  }
  console.log("sortedEventsArra 3: ",sortedEventsArray);
      //console.log("filter call 3");
      // let SortedEventWithSelf = sortedEventsArray.concat(selfEvents);
      filterCal(sortedEventsArray);
}

function toggleAllUserSelection(){
  //--check if any users are filtered
  console.log(selectedUsers.length);
  //no users are filtered
    if (selectedUsers.length == 0){
      return;
    
  }
  
    filterCal(tempEventForInterest);  
    
 
  
  // filterCal(calAllEvents)

  

  //show the events based on the tab selected


  //load the relevent events only
  
  // clear all users selction eyes and color
  tempDiv = document.getElementsByClassName("user_row");
  for (let l = 0; l < tempDiv.length; l++) {    
    let element = tempDiv[l];
    // console.log(element);
    
    element.style.backgroundColor = "";
    var tempButton = document.getElementById('toggleUserSelection'+element.id);        
    tempButton.className = "fa fa-eye-slash";

  }
  selectedUsers = [];
}

function keepSelectedUsersOn(){
  console.log("keepSelectedUsersOn");
  
  for (let index = 0; index < selectedUsers.length; index++) {
    
    console.log(index);
    
    const element = selectedUsers[index];
    console.log(element);
    tempDiv = document.getElementById(element);
    if(tempDiv == null){

      //selected user does not exsit here, so show all
      filterCal(tempEventForInterest);

    }else{
      console.log(tempDiv);
      tempDiv.style.backgroundColor = "lightGrey";
      var tempButton = document.getElementById('toggleUserSelection'+element);        
      tempButton.className = "fa fa-eye";
    }    
  }
}

function toggleUserSelection(number){
  
  console.log("toggleUserSelection" + number);
  tempDiv = document.getElementById(number);
  // //console.log(tempDiv);
  // //console.log("selectedUsers: ",selectedUsers);
  if (tempDiv.style.backgroundColor != ""){
    tempDiv.style.backgroundColor = "";
    var tempButton = document.getElementById('toggleUserSelection'+number);        
    tempButton.className = "fa fa-eye-slash";
    selectedUsers.splice( selectedUsers.indexOf(number), 1 );
    //console.log(selectedUsers);
    if (selectedUsers === undefined || selectedUsers.length == 0){        
      filterCal(tempEventForInterest)              
    }
    else{
      unfilterOne(number);
    }
  }
  else{
    //console.log("filter only user: ",number);
    
    selectedUsers = selectedUsers.concat(number);
    //console.log("selectedUsers: " + selectedUsers);
    tempDiv.style.backgroundColor = "lightGrey";
    var tempButton = document.getElementById('toggleUserSelection'+number);        
    tempButton.className = "fa fa-eye";
    // "<button class='btn' id='toggleUserSelection" + fbUserAppIdTrimed + "' onclick='toggleUserSelection(" + fbUserAppId + ")'>"+
    //   "<i class='far fa-eye' aria-hidden='true'></i></button>"+


    filterOne(number);
  }

}


function toggleFavorite1(userAppid){
  event.stopPropagation();
  tempFavIcon = document.getElementById("toggleFavorite1"+userAppid);
  //console.log("Toggle favs from Icon " + userAppid +"with value: "+ tempFavIcon.className);
  
  if (showFavsOnly === true){
    tempDiv = document.getElementById(userAppid);
    //console.log(tempDiv);
    tempDiv.style.display = "none";
    const index = myFavArray.indexOf(userAppid);
      if (index > -1) {
        myFavArray.splice(index, 1);
      }
  }
  else{
    //--check if user is a fav already
    if (tempFavIcon.className == "favIcon fa fa-star"){ //not a fav yet
      tempFavIcon.className = "favIcon fa fa-heart";
      if (typeof myFavArray === 'undefined' || myFavArray === null) {
        myFavArray = [];
      }
      myFavArray = myFavArray.concat(userAppid); 
    }
    else{ //already a fav
      tempFavIcon.className = "favIcon fa fa-star";
      const index = myFavArray.indexOf(userAppid);
      if (index > -1) {
        myFavArray.splice(index, 1);
      }
    }
    //console.log("favoritesArray: " + myFavArray);
    writeFavsToFB();
    
  }
}

function writeFavsToFB(){
  // array = myCalendar.getEvents();
  // jasonArray = JSON.stringify(array);
  // //console.log(currentUser.luid + " " + favoritesArray);
  currentUser.favoritesArray = myFavArray;
  firebase.database().ref('users/' + currentUser.luid).update(
    {
      favoritesArray: myFavArray
      // test: "passed"
    });
    localStorage.setItem("currentUser", JSON.stringify(currentUser));

}

var eventsToBuildArray_cache = [];


function filterCal(eventsToBuildArray){
  console.log("F I L T E R  C A L :", showMySelfCheck);
  console.log(selfEvents)
  
  eventsToBuildArray_cache = eventsToBuildArray;
  console.log("eventsToBuildArray_cache: ",eventsToBuildArray_cache);

  //console.log("eventsToBuildArray: ",eventsToBuildArray);
  //if show self is on:
  if (showMySelfCheck == true){
    console.log("add myself to events");
    
    eventsToBuildArray = eventsToBuildArray.concat(selfEvents);
    console.log("eventsToBuildArray added: ",eventsToBuildArray);
    
  
  }
  else{
    // eventsToBuildArray = eventsToBuildArray.splice(selfEvents);
    eventsToBuildArray_cache = eventsToBuildArray_cache.filter( x => !selfEvents.filter( y => y.id === x.id).length);
  }
  
  const unique = Array.from(new Set(eventsToBuildArray.map(JSON.stringify))).map(JSON.parse);

  // const unique = [...new Map(eventsToBuildArray.map(item => [item[key], item])).values()];
  console.log(unique);
  
  // myCalendar.addEventSource(eventsToBuildArray)
  let allevents = myCalendar.getEvents(); 
  allevents.forEach(el => { el.remove(); })
  myCalendar.addEventSource(unique);

  // showAllFavs();
  
  // toggleAllFavsSelection();
  // console.log(runShowmyself);
  // if (runShowmyself == 1){
  //   // console.log("changing runShowmyself to 2");
  //   // runShowmyself=2;
  //   showMyself();
  // }
  
  myCalendar.refetchEvents();  
  // console.log(myCalendar.getEvents());
  
  $('#loading').hide();
    
   
}

  

  


function toggleAllFavsSelection(){

  var toggleAllFavB = document.getElementById("toggleFavsOnly");
  var allCheckFavBox = document.getElementById('external-events').getElementsByClassName("favIcon");

  if (showFavsOnly == false){ //show only favorites 
    toggleFavsOnly.innerHTML = "show all users"
    //console.log("ToggleFavsOnly false");
    showFavsOnly = true; 
    for (i = 0; i < allCheckFavBox.length; i++){
      allCheckFavBox[i].parentElement.style.display = "none";
      // //console.log("allCheckFavBox: " + i +" "+allCheckFavBox[i].checked);      
      if(allCheckFavBox[i].className == "favIcon fa fa-heart"){
        allCheckFavBox[i].parentElement.style.display = "block";
      }         
    }
  }
  else{
    toggleFavsOnly.innerHTML = "show only favs"
    showFavsOnly = false;  
    
    i = 0;
    var tempFavPeople = [];
    for (i = 0; i < allCheckFavBox.length; i++){
      // //console.log("tempElement: " + i +" "+tempElement);
      // //console.log("allCheckFavBox: " + i +" "+allCheckFavBox[i].checked);            
        allCheckFavBox[i].parentElement.style.display = "block"; 
    }
  }
    
  showAllFavs();
  
}
var tempAllEvents=[];


function showAllFavs(){
  var tempAllFavEvents=[];
  console.log("toggle All Favs: ",showFavsOnly);
  if (tempAllEvents.length == 0){
    tempAllEvents = myCalendar.getEvents();
  }
  console.log("found this tempAllEvents: ",tempAllEvents);
  

  console.log("showFavsOnly: ",showFavsOnly);
  if (showFavsOnly == true){ //show only favorites    
        
    // tempAllEvents   
    for(ev in tempAllEvents){
      //console.log(tempAllEvents[ev].extendedProps.appId);
      for (j in currentUser.favoritesArray){
        // //console.log(currentUser.favoritesArray[j]);
        
        if (currentUser.favoritesArray[j] == tempAllEvents[ev].extendedProps.appId || currentUser.appId ==  tempAllEvents[ev].extendedProps.appId){
          // //console.log("there is a match");
          tempAllFavEvents.push(tempAllEvents[ev]);
          break;          
        }
      } 
    }
    console.log("use this tempAllEvents: ",tempAllFavEvents);
  }
  else{
    tempAllFavEvents = tempAllEvents;
    // if (tempAllFavEvents.length>0){
    //   console.log("use this tempAllEvents: ",tempAllFavEvents);

    // }
    // else{
      
    // }
    // let tempAllEvents = myCalendar.getEvents()
    //console.log(tempAllFavEvents);
    // var tempAllEvents = JSON.parse(localStorage.getItem("tempAllEvents"));
    // //console.log(tempAllEvents);
    
    //console.log("ToggleFavsOnly true");
    // let allevents = myCalendar.getEvents(); 
    // allevents.forEach(el => { el.remove(); })
    // myCalendar.addEventSource(tempAllEvents);
    // tempAllEvents=;
    // tempAllFavEvents=[];
    //console.log(tempAllEvents); 

    
  }

  let allevents = myCalendar.getEvents(); 
    allevents.forEach(el => { el.remove(); })
    myCalendar.addEventSource(tempAllFavEvents);
    // myCalendar.refetchEvents();
    console.log("shoud see");
    
}


var showMySelfCheck = true;
var eventsWithMyself = [];
var hideOthersCheck = false;
var eventsBeforeHideOthers = [];
function respondToHideOtheresClick(){
  console.log("HIDE OTHERS TOGGLE");
  
  console.log("eventsToBuildArray_cache: ",eventsToBuildArray_cache);
  var hideOthersButton = document.getElementById("hideOthers");
  if (hideOthersCheck == true){
    hideOthersCheck = false;      
    hideOthersButton.innerText="hide others";   
    filterCal(eventsBeforeHideOthers);         
  }
  else{
    eventsBeforeHideOthers = eventsToBuildArray_cache;
    hideOthersCheck = true;
    hideOthersButton.innerText="Show others";
    filterCal(selfEvents)
  }
  
  
  // showMyself();
}


function respondToshowMySelfClick(){
  var showSelfButton = document.getElementById("showSelf");
  if (showMySelfCheck == true){
    showMySelfCheck = false;      
    showSelfButton.innerText="Show myself";            
  }
  else{
    showMySelfCheck = true;
    showSelfButton.innerText="Hide myself";
  }
  
  console.log("eventsToBuildArray_cache: ",eventsToBuildArray_cache);
  showMyself();
}
  
function showMyself(){
  console.log(typeof(eventsToBuildArray_cache));
  console.log(selfEvents);
  console.log(typeof(selfEvents));
  
  
  if(showMySelfCheck==false){

    eventsToBuildArray_cache = eventsToBuildArray_cache.filter( x => !selfEvents.filter( y => y.id === x.id).length);



    // eventsToBuildArray_cache = eventsToBuildArray_cache.filter(function(x) { 
    //   return selfEvents.indexOf(x) < 0;
    
    console.log(eventsToBuildArray_cache);
    
  }
  else{
    // eventsToBuildArray_cache = eventsToBuildArray_cache.concat(selfEvents);
    console.log(eventsToBuildArray_cache);
  }
  
  
  
  filterCal(eventsToBuildArray_cache);            
}


function AddEventManually(){

  //response to clicking "add event"
  console.log("AddEventManually");
  
  
  $('#datetime12').combodate({
    minYear: 2020,
    maxYear: 2022,
    smartDays: true,    
  });
  let ct = moment().format('DD-MM-YYYY')
  console.log(ct);
  
   
  $('#datetime12').combodate('setValue', ct);
  $('#datetime13').combodate('setValue', moment().format('hh:mm A'));
  $('#datetime14').combodate('setValue', moment().format('hh:mm A'));

  var modal = document.getElementById("addEvent");  
  var span = document.getElementsByClassName("close")[1];  
  
  
  modal.style.display = "block";
  // When the user clicks on the button, open the modal
  // btn.onclick = function() {
  //   modal.style.display = "block";
  // }

  // When the user clicks on <span> (x), close the modal
  span.onclick = function() {
    console.log("close");
    
    modal.style.display = "none";
  }

  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    if (event.target == modal) {
      modal.style.display = "none";
    }
  }

}

function writeManualEvent(){
    //get all the events and save them
    let tmpAllEventsFromCal = myCalendar.getEvents();

      
    //verify time input 
    let tempDate = $('#datetime12').combodate('getValue');
    // console.log(tempDate);
    // console.log(moment(tempDate)format('YYYY-DD-MMMM'));
    
    
    let tempStart = $('#datetime13').combodate('getValue');
    // console.log(tempDate + " " + tempStart);
    
    let startTime = moment(tempDate + " " + tempStart);
    // console.log(startTime.format('YYYY-DD-MMMM'));
    
    // var startTime = moment(tempStart).format('MM DD YYYY') + ' ' + moment(tempStart, "HH:mm a");
    var t2 = moment(startTime).format();
    console.log(t2);
    t1 = moment(t2).format('YYYY-DD-MM')+t2.slice(10);
    

    let tempEnd = $('#datetime14').combodate('getValue');
    var endTime = moment(tempDate + " " + tempEnd);
    var t3 = moment(endTime).format();
    // console.log(t3);
    // console.log(t3.slice(10));
    t4 = moment(t3).format('YYYY-DD-MM')+t3.slice(10);
    console.log(t1 + " / " + t4);
    
    
    if(startTime.isAfter(endTime)){
      console.log("oops");
      alert("Please set a proper start and end time.")
    }
    else if (endTime.isAfter(startTime)){
        console.log("time is ok");
               
        
        let r = Math.random().toString(36).substring(2);
        var allowGuest = false;
        var bgColor = color_normal_me;
        if (document.getElementById('acceptGuest_default').checked==true){
          allowGuest = true;
          bgColor = color_guest_me;
        }

              
        //delete all the events from the cal
        let allevents = myCalendar.getEvents(); 
        allevents.forEach(el => { el.remove(); })
        
        //creat the new event
        var event1 =({
                id: r,
                title: currentUser.name + " " +currentUser.lastName,
                start: t1,
                end: t4,
                allDay: false,
                editable: true,
                
                extendedProps:{
                  acceptGuest : allowGuest,
                  appId: currentUser.appId,
                  auther: currentUser.name,
                  droppable: true
                },
                backgroundColor: bgColor                
              });
        console.log(myCalendar.getEvents());
              
        //add the event to calendar
        myCalendar.addEvent(event1);
        let singleEvent = myCalendar.getEvents;
        console.log(myCalendar.getEvents());
        
        // selfEvents.push (JSON.stringify(event1));
        selfEvents=selfEvents.concat(event1);
        tmpAllEventsFromCal=tmpAllEventsFromCal.concat(singleEvent);        
        myCalendar.addEventSource(tmpAllEventsFromCal); 
        
        //write the event to fb
        writeEventsP();

        var modal = document.getElementById("addEvent");
        modal.style.display = 'none';
    }
    else {
      console.log("efqueel");
      alert("Please set a proper start and end time.")
      
    }
}

function convert(date){
  console.log("convert");
  
  var datearray = date.split("-");
  var newdate = datearray[2] + '-' + datearray[1] + '-' + datearray[0];

  return newdate;
  
}

function timeConversionSlicker(s) {
  let AMPM = s.slice(-2);
  let timeArr = s.slice(0, -2).split(":");
  if (AMPM === "AM" && timeArr[0] === "12") {
      // catching edge-case of 12AM
      timeArr[0] = "00";
  } else if (AMPM === "PM") {
      // everything with PM can just be mod'd and added with 12 - the max will be 23
      timeArr[0] = (timeArr[0] % 12) + 12
  }  
  return timeArr.join(":");
}

var eventsBeforeSearch = [];
function search(){


  

  eventsBeforeSearch = myCalendar.getEvents();
  console.log("search");
  var searchForm = document.getElementById("searchForm");
  
  //clear the search bar

  //find the user and display him
  var searchResult = document.getElementById("myInput").value;
  // const index = usersNamesArray.indexOf(searchResult);
  // console.log(index);

  var allDisplayedEvents = document.getElementsByClassName("user_row");
  for (i = 0; i < allDisplayedEvents.length; i++){
    console.log(allDisplayedEvents[i].id);
    console.log((allDisplayedEvents[i].textContent).replace('filterFavorite',''));
    let tempResult = (allDisplayedEvents[i].textContent).replace('filterFavorite','');
    allDisplayedEvents[i].style.display="none";
    if (searchResult == tempResult)
    {
      allDisplayedEvents[i].style.display="block";
      
      filterOne(allDisplayedEvents[i].id)
      searchForm.action = "javascript:cancelSearch("+allDisplayedEvents[i].id+")";
      
    }
    //--change looking glass to x and make into a cancel search function
    var searchB = document.getElementById("searchB");
    var cancelS = document.getElementById("cancelS");
    // searchB.classList.add("fa-ban");
    // searchB.onclick = "cancelSearch()";
    searchB.style.display = "none";
    cancelS.style.display = "";
    
    
  }
  // action="javascript:search()"
}




function cancelSearch(appId){
  console.log("cancel search ",appId.id);
  
  var searchB = document.getElementById("searchB");
  var cancelS = document.getElementById("cancelS");
  var searchForm = document.getElementById("searchForm");
  searchForm.action = "javascript:search()";
  
  console.log("cancael search");
  searchB.style.display = "";
  cancelS.style.display = "none";

  

  var allDisplayedEvents = document.getElementsByClassName("user_row");
  for (i = 0; i < allDisplayedEvents.length; i++){
    allDisplayedEvents[i].style.display="";
  }

  let allevents = myCalendar.getEvents(); 
  allevents.forEach(el => { el.remove(); })
  myCalendar.addEventSource(eventsBeforeSearch);
  // filterCal(eventsToBuildArray_cache);  
}


function toggleGuestsOnly(){
  console.log(selectedUsers.length + " toggleGuestsOnly ",isGuestsOnlyActive.checked );
  if (selectedUsers.length>0){
      console.log("few users")
      console.log("filter call 4");
      filterCal(sortedEventsArray);
  }
  else{  
    console.log('no users')  
    console.log("filter call 5");    
      filterCal(calAllEvents); 
      // console.log(calAllEvents)       
    }
}


function notifyMessageWaiting(snapshot){
  console.log("notifyMessageWaiting");
  let messageAuther = "";
  if (snapshot.val().creator == currentUser.appId){
    messageAuther = snapshot.val().to;
  }
  else{
    messageAuther = snapshot.val().creator
  }

  let tempChatIcon = document.getElementById(messageAuther).getElementsByClassName('fa-comment');
  console.log(tempChatIcon[0]);
  
  
    tempChatIcon[0].className = "chatIconOn fa fa-comment";
  
  

  
  //colr the chat icon of the relevant user in red
  //get the user
}

function backToCal(){                
        document.getElementById('calendarSingle').style.display = "none";
        document.getElementById('calendar').style.display = "block";
        document.getElementById('backToCal').style.display = "none";
        document.getElementById('requestEv').style.display = "none";
        calendar1.destroy();
}

function requestEvent(){
  console.log(eventSingle);
  
  if(eventSingle.extendedProps.appId == currentUser.appId){
    editEvent();
    return;
  }


  console.log("requestEvent");
  var requestedEvent = calendar1.getEvents();
  
  const origStartTime = moment(eventSingle.start);
  const newStartTime = moment(requestedEvent[1].start);
  const origEndTime = moment(eventSingle.end);
  const newEndTime = moment(requestedEvent[1].end);

  //add the event to both auther and me as an invisible event(or red), once it will be confirmed it, will show up.
  
  //send an email to the auther

  allUsersSnapShot.forEach(function(child) { 
    console.log(child.val().appId + " : " + eventSingle.extendedProps.appId);
    
    if(child.val().appId == eventSingle.extendedProps.appId){
      nameTosend = child.val().name;
      emailTosend = child.val().email;
      
      var tempEventsArray = child.val().calArray;
      tempEventsArray = tempEventsArray.filter(function(e){return e}); 
      
      console.log(tempEventsArray);
      //get the specific event for confirmation process
      for (let index = 0; index < tempEventsArray.length; index++) {
        const element = JSON.parse(tempEventsArray[index]);          
          if(element.id == eventSingle.id){

            console.log("event found: ",element.id);
            break;                      
        }        
      }      
    }                                       
  });

//console.log("send to: " + emailTosend +" from: " + currentUser.email + "event id: "+eventId);

let mailBody = "Hello " + nameTosend + ".\n " + currentUser.name + "would like to book you offered session\n"+
"please follow this link to approve it\n"
+ "roiwerner.com/gse5/singleEvent.html?id="+eventSingle.id;
  
// Email.send({
//   Host: "smtp.ipage.com",
//   Username : "roi@roiwerner.com",
//   Password : "Roki868686",
//   To : emailTosend,
//   From : "<roi@roiwerner.com>",
//   Subject : "Session booking",
//   Body : mailBody,
//   }).then(
//     message => alert("mail sent successfully")
//   );  
  
  console.log(requestedEvent[1]);
  
  requestedEvent[1].backgroundColor = color_special;
  myCalendar.addEvent(requestedEvent[1]);        
  // currentUser.calArray.push (JSON.stringify(requestedEvent[1]));
  // console.log(currentUser.calArray);
  selfEvents=selfEvents.concat(requestedEvent[1]);
  console.log(selfEvents);
  
    
  writeEventsP();    
  
  document.getElementById('calendarSingle').style.display = "none";
  document.getElementById('calendar').style.display = "block";
  document.getElementById('backToCal').style.display = "none";
  document.getElementById('requestEv').style.display = "none";
  calendar1.destroy();  
    
  let allevents = myCalendar.getEvents(); 
  allevents.forEach(el => { el.remove(); });
  myCalendar.addEventSource(allevents);
  
  //take the time from the event
  
}

function editEvent(){
  console.log("editevent");
  
  var requestedEvent = calendar1.getEvents();
  const origStartTime = moment(eventSingle.start);
  const newStartTime = moment(requestedEvent[1].start);
  const origEndTime = moment(eventSingle.end);
  const newEndTime = moment(requestedEvent[1].end);

    if(origStartTime != newStartTime || origEndTime != newEndTime){
      let r = confirm ("A CHANGE HAS BEEN MADE, DO YOU WANT TO KEEP IT?");
          if (r == true){
            console.log("change event");
            
            //delete Event
            
            for(e in currentUser.calArray){
              let tempvar = JSON.parse(currentUser.calArray[e]);
              //console.log(tempvar.id);
              if (tempvar.id == eventSingle.id){
                //console.log("event found at indes: " + e);
                currentUser.calArray.splice(e, 1);      
                break;
                
              }
            }
            eventSingle.remove();

            myCalendar.addEvent(requestedEvent[1]);        
            currentUser.calArray.push (JSON.stringify(requestedEvent[1]));
            
            writeEventsP();    
          }
          document.getElementById('calendarSingle').style.display = "none";
          document.getElementById('calendar').style.display = "block";
          document.getElementById('backToCal').style.display = "none";
          document.getElementById('requestEv').style.display = "none";
          calendar1.destroy();  
    }
    let allevents = myCalendar.getEvents(); 
    allevents.forEach(el => { el.remove(); });
    myCalendar.addEventSource(allevents);
}




function test(){
  console.log("test");
  
}