var currentUser = JSON.parse(localStorage.getItem("currentUser"));
allUsersNamesArray = [];
calAllEvents = [];
selectedUsers = [];
fbAllEvents = [];
myCalendar = FullCalendar;
var showFavsOnly = false;

var currentdate = new Date();
var datetime = "Last Sync: " + currentdate.getDay() + "/" + currentdate.getMonth() 
+ "/" + currentdate.getFullYear() + " @ " 
+ currentdate.getHours() + ":" 
+ currentdate.getMinutes() + ":" + currentdate.getSeconds();

color_main = '#4ca8b8';
color_guest = '#18535e';
color_special = '#369890';
color_normal_me = '#6aa059';
color_guest_me = '#285e18'


document.addEventListener('DOMContentLoaded', function() {
    //create tabs according to the user field of interest.
    createTabsNamesByInterest();
    
    isGuestsOnlyActive = document.getElementById('guestOnly');
    // myCalendar = FullCalendar;      
});

function createTabsNamesByInterest (){
  let localFieldsOfInterest = [];
  for (i in currentUser.fieldsOfinterest){
    localFieldsOfInterest.push(currentUser.fieldsOfinterest[i]);
  }
    // var localFieldsOfInterest=[];
    
    // currentUser.fieldsOfinterest.pop();
    
    
    // currentUser.fieldsOfinterest = [];
    localFieldsOfInterest.push("All_as_guest");
    htmlString = '';
    tabsString = '';
    //console.log("create tabs local " + localFieldsOfInterest);
    //console.log("create tabs " + currentUser.fieldsOfinterest);
    for (i in localFieldsOfInterest){
      activeString = '';
      if(i == 0){
        activeString = " active";
      }
      currentField = localFieldsOfInterest[i]
      htmlString += "<button class='tablinks " + activeString + "' onclick='openTab(event, " +currentField + ")'>" + currentField + "</button>"
  
      tabsString += "<div id=" + currentField + " class='tabcontent'><h3>" + currentField + "</h3><div  id='allUsersDisplay'></div></div>"
      
    }
    htmlData = "<div id='tableTabsByInterest' class='tab'>"+htmlString+"</div>"+tabsString;
    document.getElementById("tabsNav").innerHTML = htmlData;
    
}

function openTab(evt, fieldName) {
    //console.log(fieldName.id);
    
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    // document.getElementById(fieldName.id).style.display = "block";
    evt.currentTarget.className += " active";      
    filterByCurrentInterest(fieldName.id)    
  }


//   ------------------- CALENDAR ------------------

firebase.database().ref('/users/').once('value').then(function(snapshot) {
    // var username = (snapshot.val()) || 'Anonymous';
    allUsersSnapShot = snapshot;
    var i =0;
    allUsersSnapShot.forEach(function(child) {
           
        //create a list of all users with out myself!
        let userFullName = child.val().name + " " + child.val().lastName
        if (child.val().appId != currentUser.appId){
        // //console.log("found: "+ child.val().appId);
            allUsersNamesArray.push({
                key:   child.val().appId,
                value: userFullName
            });  
        }
        // check if the user has a calendar including self!
        if (child.val().calArray){
          let tempChildArray = child.val().calArray;
          if(tempChildArray.length == 0){
            // //console.log("empty calArray found");
            
          }

            if(child.val().appId == currentUser.appId){
              // //console.log("STOPPPPP");
                var localSelfCalArray = child.val().calArray;
               // var tempSelfCalArray = localSelfCalArray;
                // //console.log(localSelfCalArray);
                tempEvent = [];
                for(v in localSelfCalArray){
                  tempEvent = JSON.parse(localSelfCalArray[v])
                  if (tempEvent.extendedProps.acceptGuest == true){
                    tempEvent.backgroundColor = color_guest_me;
                    tempEvent.editable = true;
                    tempEvent.droppable = true;
                  }
                  else{
                    tempEvent.backgroundColor = color_normal_me;
                    tempEvent.editable = true;
                    tempEvent.droppable = true;
                  } 

                  //console.log(tempEvent);
                  fbAllEvents = fbAllEvents.concat(tempEvent);
                  
                }
                

                // for (b in localSelfCalArray){
                //     //console.log(localSelfCalArray[b].backgroundColor);
                //     if (localSelfCalArray[b].extendedProps.acceptGuest == true){
                //     localSelfCalArray[b].backgroundColor = "yellow";
                //     }
                //     else{
                //     localSelfCalArray[b].backgroundColor = "orange";
                //     }                    
                // } ;
                // fbAllEvents = fbAllEvents.concat(localSelfCalArray);
            }
            else{
              // //console.log(child.val().calArray);
              
                var fbUserEventsArray = child.val().calArray            
                //insert the user calendar into an array
                fbAllEvents = fbAllEvents.concat(fbUserEventsArray); 
            }                            
        };
      //once finished populate the users table and make the calendar
        i = i+1;
        if (i== allUsersSnapShot.numChildren()){      
          //console.log("STOPPPPP");  
            populateUsersTablePC(allUsersNamesArray);
            makeCal(fbAllEvents);
            filterByCurrentInterest(currentUser.fieldsOfinterest[0]);      
        };
                        
    });
});

var indexxxx=0;
function makeCal(fbAllEvents){
    //console.log("makeCal");
    
    var initView = 'timeGridWeek';
    if (myCalendar.view){
      initView = myCalendar.view.type;
    }
    
    var calendarEl = document.getElementById('calendar');
    //console.log("STOPPPPP");
    myCalendar = new FullCalendar.Calendar(calendarEl, {
      drop: function(arg) {
        //console.log(arg);

      },
      eventResizeStart: function(arg){
        //console.log("eventResizeStart: ========",arg);
        var eventObj = arg.event;

        if (eventObj.extendedProps.appId != currentUser.appId){
          //console.log("Not your event, can't touch this.");
          // arg.revert();
          return;
        }
        
      },
      eventDrop: function(arg) { // called when an event (already on the calendar) is moved
        
        //console.log('eventDrop', arg.event);
        
        var eventObj = arg.event;

        if (eventObj.extendedProps.appId != currentUser.appId){
          //console.log("Not your event, can't touch this.");
          
          arg.revert();
          return;
        }
        else{
        var eventEnding = moment(eventObj.end);
            
          //console.log(eventEnding.format('HH:mm:ss'));
          //console.log(eventEnding.format('YYYY-MM-DD'));
  
  
          //--check if the current time clicked is before the end of event, if so allow to click, else do nothing.
          var timeClickedDate = Date.parse(moment().format('YYYY-MM-DD'));
          let endDate = Date.parse(eventEnding.format('YYYY-MM-DD'));
          if (timeClickedDate>endDate){
            //console.log("event is in the past");
            alert("You can not move an event in the past!");
            arg.revert();
            return;
          }
          else if (timeClickedDate == endDate){
            var timeClickedTime = moment().format('HH:mm:ss');
            let endTime = eventEnding.format('HH:mm:ss');
            
          
            
            str1 =  timeClickedTime.split(':');
            str2 =  endTime.split(':');
  
            //console.log(timeClickedTime + " " + endTime);
  
            totalSecondsTimeClicked = parseInt(str1[0] * 3600 + str1[1] * 60 + str1[0]);
            totalSecondsEndtime = parseInt(str2[0] * 3600 + str2[1] * 60 + str2[0]);
            //console.log(totalSecondsTimeClicked + " " + totalSecondsEndtime);
            if (totalSecondsTimeClicked > totalSecondsEndtime ){
              //console.log("event is in the past");
              alert("You can not move an event in the past!");
              return;
            }
            else{
              //console.log("event is in the future");
            }          
          }        
          writeEventsP();
        }
      },

      eventResize: function(info) {
        //console.log("Resize event: " ,info);

        var eventObj = info.event;
        if (eventObj.extendedProps.appId != currentUser.appId){
          //console.log("Not your event, can't touch this.");
          info.revert();
          return;
        }
        else{

        
        
        var eventEnding = moment(eventObj.end);
            
          //console.log(eventEnding.format('HH:mm:ss'));
          //console.log(eventEnding.format('YYYY-MM-DD'));
  
  
          //--check if the current time clicked is before the end of event, if so allow to click, else do nothing.
          var timeClickedDate = Date.parse(moment().format('YYYY-MM-DD'));
          let endDate = Date.parse(eventEnding.format('YYYY-MM-DD'));
          if (timeClickedDate>endDate){
            //console.log("event is in the past");
            alert("You can not edit an event in the past!");
            info.revert();
            return;
          }
          else if (timeClickedDate == endDate){
            //console.log("same day");
            
            var timeClickedTime = moment().format('HH:mm:ss');
            let endTime = eventEnding.format('HH:mm:ss');
            
          
            
            str1 =  timeClickedTime.split(':');
            str2 =  endTime.split(':');
  
            //console.log(timeClickedTime + " " + endTime);
  
            totalSecondsTimeClicked = parseInt(str1[0] * 3600 + str1[1] * 60 + str1[0]);
            totalSecondsEndtime = parseInt(str2[0] * 3600 + str2[1] * 60 + str2[0]);
            //console.log(totalSecondsTimeClicked + " " + totalSecondsEndtime);
            if (totalSecondsTimeClicked > totalSecondsEndtime ){
              //console.log("event is in the past");
              alert("You can not edit an event in the past!");
              return;
            }
            else{
              //console.log("event is in the future");
            }          
          }
  
  
  
  
        writeEventsP();
        }
      },
      
      select: function(info){
        //console.log("select_______________");
        
        var eventObj = info.event;
        var eventEnding = moment(info.startStr);
            
        //console.log(eventEnding.format('HH:mm:ss'));
        //console.log(eventEnding.format('YYYY-MM-DD'));


        //--check if the current time clicked is before the end of event, if so allow to click, else do nothing.
        var timeClickedDate = Date.parse(moment().format('YYYY-MM-DD'));
        let endDate = Date.parse(eventEnding.format('YYYY-MM-DD'));
        if (timeClickedDate>endDate){
        //console.log("event is in the past");
        alert("You can not create an event in the past!");
        return;
        }
        else if (timeClickedDate == endDate){
            var timeClickedTime = moment().format('HH:mm:ss');
            let endTime = eventEnding.format('HH:mm:ss');
            
            
            
            str1 =  timeClickedTime.split(':');
            str2 =  endTime.split(':');

            //console.log(timeClickedTime + " " + endTime);

            totalSecondsTimeClicked = parseInt(str1[0] * 3600 + str1[1] * 60 + str1[0]);
            totalSecondsEndtime = parseInt(str2[0] * 3600 + str2[1] * 60 + str2[0]);
            //console.log(totalSecondsTimeClicked + " " + totalSecondsEndtime);
            if (totalSecondsTimeClicked > totalSecondsEndtime ){
                //console.log("event is in the past");
                alert("You can not create an event in the past!");
                return;
            }
            else{
                //console.log("event is in the future");
            }          
        }
   
        //console.log(document.getElementById('acceptGuest_default').checked);
        // var currentUser = JSON.parse(localStorage.getItem("currentUser"));
        let r = Math.random().toString(36).substring(2);
        var allowGuest = false;
        var bgColor = color_normal_me;
        if (document.getElementById('acceptGuest_default').checked==true){
          allowGuest = true;
          bgColor = color_guest_me;
        }
        myCalendar.addEvent({
                id: r,
                title: currentUser.name +" " +currentUser.lastName,
                start: info.startStr,
                end: info.endStr,
                allDay: false,
                editable: true,
                droppable: true,
                
                backgroundColor: bgColor,
                appId: currentUser.appId,
                auther: currentUser.name,
                acceptGuest : allowGuest
              });
  
        CurrentEvent = myCalendar.getEventById(r);                        
        
        // currentUser.calArray = [];
        // localStorage.setItem("currentUser", JSON.stringify(currentUser));
        var tempArrayOfAll = [];
        if(typeof(currentUser.calArray)!==undefined){

          if(currentUser.calArray.length>0){
            tempArrayOfAll = currentUser.calArray;
          }                              
          //console.log("tempArrayOfAll defined " + tempArrayOfAll.length);
          
        }
        else{
          //console.log("tempArrayOfAll not defined" + tempArrayOfAll);
        }
         
        
        tempArrayOfAll.push(JSON.stringify(CurrentEvent));
        // //console.log("tempArrayOfAll: " ,tempArrayOfAll);
        
        // var tempArrayOfAll =  tempArrayOfAll.concat(JSON.stringify(CurrentEvent));
        // //console.log("tempArrayOfAll: " ,tempArrayOfAll);
        // //console.log(tempArrayOfAll);
        currentUser.calArray = tempArrayOfAll;

        // //console.log(typeof(tempArrayOfAll));
        

        //save all events to firebase
        // saveAllEvents(myCalendar);
        writeEventsP();

      },

      selectOverlap: function(event) {
        //console.log("selectOverlap");
        
        return event.rendering === 'background';
      },
      eventClick: function(info) {
        
        //console.log(info);
        
        var eventObj = info.event;
        userAppId = eventObj.extendedProps.appId;
        
        if (eventObj.url) {
          alert(
            'Clicked ' + eventObj.title + '.\n' +
            'Will open ' + eventObj.url + ' in a new tab'
          );
          window.open(eventObj.url);
          info.jsEvent.preventDefault(); // prevents browser from following link in current tab.
        } else {

          //--1/ check if the evnt autor is the suer
                    
  
          calendarDiv = document.getElementById('mainFrame');
          // var eventInfoDiv = document.getElementById('singleEvent');
          var eventName = document.getElementById('eventName');
          var eventStart = document.getElementById('eventStart');
          var eventEnd = document.getElementById('eventEnd');
          eventAuther = eventObj.auther;
          // var eventId = eventObj.id;
          eventId = eventObj.id;
  
          // document.getElementById('auther').innerHTML = eventObj.extendedProps.auther;
          document.getElementById('eventName').innerHTML = eventObj.title;
          document.getElementById('eventStart').innerHTML = eventObj.start;
          document.getElementById('eventEnd').innerHTML = eventObj.end ;
          //console.log(eventId);
          CurrentEvent=myCalendar.getEventById(eventId);
  
  
          //check if the date end is before now, don't click!
          // alert(eventObj.start.format('h:mm:ss a'));
          
            var eventEnding = moment(eventObj.end);
            
            //console.log(eventEnding.format('HH:mm:ss'));
            //console.log(eventEnding.format('YYYY-MM-DD'));


            var timeClickedDate = Date.parse(moment().format('YYYY-MM-DD'));
            let endDate = Date.parse(eventEnding.format('YYYY-MM-DD'));
            if (timeClickedDate>endDate){
            //console.log("event is in the past");
            alert("You can not select an event in the past!");
            return;
            }
            else if (timeClickedDate == endDate){
                var timeClickedTime = moment().format('HH:mm:ss');
                let endTime = eventEnding.format('HH:mm:ss');
                
                
                
                str1 =  timeClickedTime.split(':');
                str2 =  endTime.split(':');

                //console.log(timeClickedTime + " " + endTime);

                totalSecondsTimeClicked = parseInt(str1[0] * 3600 + str1[1] * 60 + str1[0]);
                totalSecondsEndtime = parseInt(str2[0] * 3600 + str2[1] * 60 + str2[0]);
                //console.log(totalSecondsTimeClicked + " " + totalSecondsEndtime);
                if (totalSecondsTimeClicked > totalSecondsEndtime ){
                    //console.log("event is in the past");
                    alert("You can not select an event in the past!");
                    return;
                }
                else{
                    //console.log("event is in the future");
                }          
            }              
            
            if (eventObj.extendedProps.appId == currentUser.appId){
              //console.log("this is my own event");
              editEvent(eventObj);
            }else{
              popUpEvent(eventObj);
            }
            
        
            
  
          //toggle divs
          // calendarDiv.style.display = "none";
          // eventInfoDiv.style.display="block";
        }
      },
      dateClick: function(info) {
        //console.log('clicked ' + info.dateStr);
      },
      initialView: initView,
      allDaySlot: false,      
      views: {
        timeGridDay: {
            type: 'timeGrid',
            scrollTime: '09:00:00',
        },
        timeGridWeek: {
            type: 'timeGrid',          
            scrollTime: '09:00:00',
        },
        dayGridMonth: {
            
        }
      },
      dragScroll: false,
      now: currentdate,
      nowIndicator: true,  
      editable: false,
                droppable: false,     
      // editable: true, // enable draggable events
      // droppable: true, // this allows things to be dropped onto the calendar
      selectable: true,
      selectOverlap: true,
      eventOverlap: true,
      aspectRatio: 1.8,
      scrollTime: '09:00', // undo default 6am scrollTime
      headerToolbar: {
        left: 'today prev,next',
        center: 'title',
        right: 'timeGridDay,timeGridWeek,dayGridMonth'
      },
  
      // events: fbAllEvents,    
    });
    console.log("stop?");
    
    myCalendar.render();
    // calAllEvents = myCalendar.getEvents();
    
    
}

function populateUsersTablePC(usersToPopulateTable){
    //console.log(usersToPopulateTable);
    
    //populate the names table as an HTML 
    
    let tempString = '';
    let dataHtml = '';
    var displayedNamesArray = [];
    mainDiv = document.getElementById('external-events');
    mainDiv.innerHTML = "<div id='control' class='control' ><i class='fa fa-eye-slash' id='toggleAllUserSelection' onclick='toggleAllUserSelection()'>control</i><i class='fa fa-star' id='toggleAllFavSelection' onclick='toggleAllFavsSelection()'></i></div>";
    // //console.log("mainDiv: ",mainDiv);
    k=0;
    //check inside all the users if there is a fav
    for (var i in usersToPopulateTable){      

      // check if the user is selected (for filtering) and mark the check box on
      for (var temp in selectedUsers){
        if (selectedUsers[temp] == usersToPopulateTable[i] )
        {
          tempString="checked";
          break;
        }
      }
      k = k+1;

      displayedNamesArray = displayedNamesArray.concat(usersToPopulateTable[i].value);
      //create the HTML code
      let fbUserAppId = JSON.stringify(usersToPopulateTable[i].key);
      
      fbUserAppIdTrimed = fbUserAppId.slice(1, -1);
      dataHtml += "<div id='" + fbUserAppIdTrimed + "'class='user_row' onclick='toggleUserSelection(" + fbUserAppId + ")'>"+
      "<i class='fa fa-eye-slash' id='toggleUserSelection" + fbUserAppIdTrimed + "' onclick='toggleUserSelection(" + fbUserAppId + ")'>"+
      "</i>"+
      "<p onclick='openUser(" + fbUserAppIdTrimed + ")'>" + usersToPopulateTable[i].value + "</p>";      
      myFavArray = currentUser.favoritesArray;
      //check if the user is a favorite and check the box on
      var string = "<i class='favIcon fa fa-star'";
      // //console.log("HELLLLLLLOOOOOOO! "+currentUser.favoritesArray);
        if (typeof myFavArray === 'undefined' || myFavArray === null) {

        }
        else {
          for (i in myFavArray){
            // //console.log(myFavArray[i] + "  " + fbUserAppIdTrimed);
              if (myFavArray[i] == fbUserAppIdTrimed){
              //   document.getElementById("toggleUserSelection",fbUserAppIdTrimed).checked = true;
              string = "<i class='favIcon fa fa-heart'";
              break;
              } 
              // else{
              //   string = "<input type='checkbox' class = 'tavCheckBox' id='toggleFavorite"+ fbUserAppIdTrimed +"' onclick='toggleFavorite(" + fbUserAppId + ")' />";

              // }                                 
          }
        }
      dataHtml += "<i class='chatIcon fa fa-comment'></i>" + string + " id='toggleFavorite1"+ fbUserAppIdTrimed +"' onclick='toggleFavorite1(" + fbUserAppId + ")'></i></div>"; 
            
    };
    if (k == usersToPopulateTable.length){
      mainDiv.innerHTML += dataHtml;
      autocomplete(document.getElementById("myInput"), usersToPopulateTable);
      // //console.log(displayedNamesArray);
      

    };
  }

  function test(){
    //console.log("test work");
    
  }
  function filterByCurrentInterest(currentField){
    //console.log("STOPPPPP");
    if(currentField == "All_as_guest"){
        //console.log("show all as aguest");
        populateUsersTablePC(allUsersNamesArray);
        let allevents = myCalendar.getEvents(); 
        allevents.forEach(el => { el.remove(); })
        myCalendar.addEventSource(fbAllEvents);
        return;
        
    }
  
    if (currentField == 0){
      //console.log("default: "+ currentField);
      makeCal(fbAllEvents);
    }
    else { 
      
      //--filter out the users based on FOI
      var localUsersArray = allUsersSnapShot.toJSON();

      //console.log("currentField: "+ currentField);
      //console.log("allUsersArray: "+ localUsersArray);
      // var newFilteredArray =  calAllEvents;
      var tempUsersByInterestArray = [];
      var tempEventForInterest=[];

      allUsersSnapShot.forEach(function(child) {

        var tempFieldsArray = child.val().fieldsOfinterest;

        if (tempFieldsArray === undefined){

        }        
        else{
          if (Object.values(tempFieldsArray).includes(currentField)) {
              if(child.val().appId != currentUser.appId){
                //console.log(child.val().name);
                tempUsersByInterestArray.push({
                    key:   child.val().appId,
                    value: child.val().name + " " + child.val().lastName
                }); 
              }
                        
            let tempArray = child.val().calArray;
            if (typeof(tempArray)=== undefined){
              //console.log("no array found ");
            }
            else{
              if(tempArray === undefined){
                //console.log("emptry bastered");
                
              }
            else {
                if(child.val().appId == currentUser.appId){
                    var localSelfCalArray = child.val().calArray;

                    tempEvent = [];
                for(v in localSelfCalArray){
                  tempEvent = JSON.parse(localSelfCalArray[v])
                  if (tempEvent.extendedProps.acceptGuest == true){
                    tempEvent.backgroundColor = color_guest_me;
                    tempEvent.editable = true;
                    tempEvent.droppable = true;
                  }
                  else{
                    tempEvent.backgroundColor = color_normal_me;
                    tempEvent.editable = true;
                    tempEvent.droppable = true;
                  } 

                  // //console.log(tempEvent);
                  tempEventForInterest = tempEventForInterest.concat(tempEvent);
                  
                }

                    // //console.log(localSelfCalArray);
                    for (let index = 0; index < localSelfCalArray.length; index++) {
                      // //console.log(localSelfCalArray[index]);
                      let tempArray = localSelfCalArray[index];                  
                      // //console.log(tempArray.includes('acceptGuest":false'));
                      // for (let index1 = 0; index1 < tempArray.length; index1++) {
                      //   //console.log(tempArray[index1]);
                        
                      // }
                      
                    }

                    // for (i in localSelfCalArray){
                    //     // //console.log(localSelfCalArray[i].backgroundColor);
                    //     // if (localSelfCalArray[i].extendedProps.acceptGuest == true){
                    //     // localSelfCalArray[i].backgroundColor = "yellow";
                    //     // }
                    //     // else{
                    //     // localSelfCalArray[i].backgroundColor = "orange";
                    //     // }                    
                    // } 
                    // tempEventForInterest = tempEventForInterest.concat(localSelfCalArray);
                }
                else{
                    var localSelfCalArray = child.val().calArray;
                    //console.log(typeof(localSelfCalArray));
                    //console.log(localSelfCalArray);
                    //console.log("STOPPPPP");
                    
                    for (i in localSelfCalArray){
                      let tempVar = JSON.parse(localSelfCalArray[i]);
                        //console.log(tempVar.backgroundColor);
                        if (tempVar.extendedProps.acceptGuest == true){
                          tempVar.backgroundColor = color_guest;
                        }
                        else{
                          tempVar.backgroundColor = color_main;
                        } 
                        tempEventForInterest = tempEventForInterest.concat(tempVar);                   
                    } 
                    
                    // //console.log(typeof(child.val().calArray) + " " + child.val().calArray);
                    // tempEventForInterest = tempEventForInterest.concat(JSON.parse(child.val().calArray));
                }                
            } 

            }
                                         
          }  
        }
      });
    
      //console.log(tempEventForInterest);
      populateUsersTablePC(tempUsersByInterestArray);

    }
      
    //refresh the calendar!
    //console.log("tempEventForInterest:____",tempEventForInterest);
    
    let allevents = myCalendar.getEvents(); 
    allevents.forEach(el => { el.remove(); })
    myCalendar.addEventSource(tempEventForInterest);
    
}

function returnTable(){
    //console.log(JSON.stringify(CurrentEvent));
    // CurrentEvent.remove();
    calendarDiv.style.display = "block";
    document.getElementById('singleEvent').style.display = "none";  
    myCalendar.render();
}

function writeEventsP(){
    //TODO - fix the write events to have only the user's
    array = currentUser.calArray;
    //console.log(array);    
    firebase.database().ref('users/' + currentUser.luid).update(
      {
        calArray: array
        // test: "passed"
      });
      localStorage.setItem("currentUser", JSON.stringify(currentUser));


      // for(v in array){
    //   let tempEvent = JSON.parse(array[v])

    //   //console.log(tempEvent.extendedProps.acceptGuest);
      
    // }

    // jasonArray = JSON.stringify(array);
    // //console.log(jasonArray);
    // currentUser.calArray = jasonArray;
  
  }



function openUser(passedUserAppId){

  let url="../gse5/singleUser.html?id="+passedUserAppId.id;
  popupWindow = window.open(url,'popUpWindow','height=500,width=500,left=100,top=100,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no, status=yes');

}
function editEvent(eventObj){
  //console.log("edit Event");
  var modal = document.getElementById("myModal");  
  var span = document.getElementsByClassName("close")[0];
  document.getElementById("sendOrdelete").innerHTML = "Delete Event";
  document.getElementById("sendOrdelete").onclick = function(){
    deleteEvent(eventObj);
  }
  modal.style.display = "block";

  // When the user clicks on <span> (x), close the modal
  span.onclick = function() {
    modal.style.display = "none";
  }

  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    if (event.target == modal) {
      modal.style.display = "none";
    }
  }

}


function popUpEvent(eventObj){
  //console.log("Pop Event");
  
  var modal = document.getElementById("myModal");  
  var span = document.getElementsByClassName("close")[0];
  document.getElementById("sendOrdelete").innerHTML = "Request Event";
  document.getElementById("sendOrdelete").onclick = function(){
    sendEmail();
  }
  
  
  modal.style.display = "block";
  // When the user clicks on the button, open the modal
  // btn.onclick = function() {
  //   modal.style.display = "block";
  // }

  // When the user clicks on <span> (x), close the modal
  span.onclick = function() {
    modal.style.display = "none";
  }

  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    if (event.target == modal) {
      modal.style.display = "none";
    }
  }
  // let url="../gse5/singleEvent.html";
  // popupWindow = window.open(url,'popUpWindow','height=500,width=500,left=100,top=100,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no, status=yes');
  
}


function sendEmail(){

  //console.log(eventId + " " + userAppId);
  return;
    var i =0;
    //-- find the relevant calendar by user and then find the relevant event!
    //-- find item in JSON example !!!!
    allUsersSnapShot.forEach(function(child) { 
      // //console.log(child.val().appId);
      
      if(child.val().appId == userAppId){
        nameTosend = child.val().name;
        emailTosend = child.val().email;
        if (child.val().calArray){
          var fbUserEventsArray = child.val().calArray;
          
          let obj = JSON.parse(fbUserEventsArray);
          for (i in obj){
            if (obj[i].id == eventId){
              //console.log(obj[i]);
            }            
          }             
        };
      }                                       
    });
  
  //console.log("send to: " + emailTosend +" from: " + currentUser.email + "event id: "+eventId);

  let mailBody = "Hello " + nameTosend + ".\n " + currentUser.name + "would like to book you offered session\n"+
  "please follow this link to approve it\n"
  + "roiwerner.com/gse5/personalCalendar.html?id="+eventId;
    
  Email.send({
    Host: "smtp.ipage.com",
    Username : "roi@roiwerner.com",
    Password : "Roki868686",
    To : '<roiwerner@gmail.com>',
    From : "<roi@roiwerner.com>",
    Subject : "Session booking",
    Body : mailBody,
    }).then(
      message => alert("mail sent successfully")
    );    
}


function deleteEvent(eventObj){
  let answer= confirm("Are you sure you want to delete this event?")
  if (answer ==true){
    //console.log("delet Event: " + eventObj.id);
    var eventTodelete = myCalendar.getEventById(eventObj.id);
    eventTodelete.remove();

    var modal = document.getElementById("myModal");
    modal.style.display = "none";

    for(e in currentUser.calArray){
      let tempvar = JSON.parse(currentUser.calArray[e]);
      //console.log(tempvar.id);
      if (tempvar.id == eventObj.id){
        //console.log("event found at indes: " + e);
        currentUser.calArray.splice(e, 1);      
        break;
        
      }
    }
  
    writeEventsP();
  
  }
  //remove from currentUser.calArray
  
  
  
  
  //remove from calendar
  //remove from firebase
  
}

var tempFilteredEvents = [];
//------------- TOGGLE USER SELECTION ------------------//
function filterOne(appId){
  if (calAllEvents.length==0){
    calAllEvents = myCalendar.getEvents();
  }
   
    console.log(calAllEvents);

    console.log("filter one:" ,appId);
    console.log(calAllEvents);
    
  var newFilteredArray =  calAllEvents.filter(function(filter) {
  return filter.extendedProps.appId == appId;
  });
  //console.log(newFilteredArray);
  
  if (selectedUsers.length>1){
    //console.log("more then 1 user");    
    sortedEventsArray = sortedEventsArray.concat(newFilteredArray);
    // //console.log(sortedEventsArray);
    //console.log("filter call 1");
    tempFilteredEvents = sortedEventsArray;
    filterCal(sortedEventsArray);
  }
  else{
      sortedEventsArray = newFilteredArray;
      tempFilteredEvents = sortedEventsArray;
      //console.log("sorted array: ",sortedEventsArray);
      //console.log("filter call 2");
      filterCal(sortedEventsArray);
      
  }

}
sortedEventsArray = [];
function unfilterOne(appId){
console.log("unfilterOne");

    
  var newFilteredArray =  sortedEventsArray.filter(function(filter) {
  return filter.extendedProps.appId == appId;
  });
  // //console.log(newFilteredArray);
  for(tempIndex in newFilteredArray){
    var tempFilteredEvent = newFilteredArray[tempIndex];
    sortedEventsArray.splice( sortedEventsArray.indexOf(tempFilteredEvent), 1 );
      // sortedEventsArray = sortedEventsArray.concat(JSON.parse(tempFilteredEvent));
  }
    // //console.log(sortedEventsArray);
    //console.log("filter call 3");
  filterCal(sortedEventsArray);
}

function toggleAllUserSelection(){
  //TODO: clear all users selction eyes and color
  filterCal(calAllEvents)
  tempDiv = document.getElementsByClassName("user_row");
  for (let l = 0; l < tempDiv.length; l++) {    
    let element = tempDiv[l];
    // console.log(element);
    
    element.style.backgroundColor = "";
    var tempButton = document.getElementById('toggleUserSelection'+element.id);        
    tempButton.className = "fa fa-eye-slash";

  }
  selectedUsers = [];
}

function toggleUserSelection(number){
  
  console.log("toggleUserSelection" + number);
  tempDiv = document.getElementById(number);
  // //console.log(tempDiv);
  // //console.log("selectedUsers: ",selectedUsers);
  if (tempDiv.style.backgroundColor != ""){
    tempDiv.style.backgroundColor = "";
    var tempButton = document.getElementById('toggleUserSelection'+number);        
    tempButton.className = "fa fa-eye-slash";
    selectedUsers.splice( selectedUsers.indexOf(number), 1 );
    //console.log(selectedUsers);
    if (selectedUsers === undefined || selectedUsers.length == 0){        
      filterCal(calAllEvents)              
    }
    else{
      unfilterOne(number);
    }
  }
  else{
    //console.log("filter only user: ",number);
    
    selectedUsers = selectedUsers.concat(number);
    //console.log("selectedUsers: " + selectedUsers);
    tempDiv.style.backgroundColor = "lightGrey";
    var tempButton = document.getElementById('toggleUserSelection'+number);        
    tempButton.className = "fa fa-eye";
    // "<button class='btn' id='toggleUserSelection" + fbUserAppIdTrimed + "' onclick='toggleUserSelection(" + fbUserAppId + ")'>"+
    //   "<i class='far fa-eye' aria-hidden='true'></i></button>"+


    filterOne(number);
  }

}


function toggleFavorite1(userAppid){
  event.stopPropagation();
  tempFavIcon = document.getElementById("toggleFavorite1"+userAppid);
  //console.log("Toggle favs from Icon " + userAppid +"with value: "+ tempFavIcon.className);
  
  if (showFavsOnly === true){
    tempDiv = document.getElementById(userAppid);
    //console.log(tempDiv);
    tempDiv.style.display = "none";
    const index = myFavArray.indexOf(userAppid);
      if (index > -1) {
        myFavArray.splice(index, 1);
      }
  }
  else{
    //--check if user is a fav already
    if (tempFavIcon.className == "favIcon fa fa-star"){ //not a fav yet
      tempFavIcon.className = "favIcon fa fa-heart";
      if (typeof myFavArray === 'undefined' || myFavArray === null) {
        myFavArray = [];
      }
      myFavArray = myFavArray.concat(userAppid); 
    }
    else{ //already a fav
      tempFavIcon.className = "favIcon fa fa-star";
      const index = myFavArray.indexOf(userAppid);
      if (index > -1) {
        myFavArray.splice(index, 1);
      }
    }
    //console.log("favoritesArray: " + myFavArray);
    writeFavsToFB();
    
  }
}

function writeFavsToFB(){
  // array = myCalendar.getEvents();
  // jasonArray = JSON.stringify(array);
  // //console.log(currentUser.luid + " " + favoritesArray);
  currentUser.favoritesArray = myFavArray;
  firebase.database().ref('users/' + currentUser.luid).update(
    {
      favoritesArray: myFavArray
      // test: "passed"
    });
    localStorage.setItem("currentUser", JSON.stringify(currentUser));

}

function filterCal(eventsToBuildArray){
  //console.log("eventsToBuildArray: ",eventsToBuildArray);
  
  let allevents = myCalendar.getEvents(); 
        allevents.forEach(el => { el.remove(); })
        myCalendar.addEventSource(eventsToBuildArray)
        myCalendar.refetchEvents();
  // //console.log("________filter cal!!!");
  // //console.log(eventsToBuildArray);
  // return;
  
  // if (isGuestsOnlyActive.checked == true){
  //   eventsToBuildArray =  eventsToBuildArray.filter(function(filter) {
  //   return filter.extendedProps.acceptGuest == true;
  //   });
  // }
  

  // var initView = 'timeGridWeek';
  // // //console.log("makeCal");
  // if (myCalendar.view){
  //   allView = myCalendar.view;
  //   // //console.log(myCalendar.view.type);
  //   initView = myCalendar.view.type;
  //   // startTime = myCalendar.view.currentStart._d;
  //   calStartTime = myCalendar.view.currentStart;
  //   //format time in case of neeed!!!!
  //   var str = myCalendar.formatDate(calStartTime, {
  //     year: 'numeric',
  //     month: '2-digit',
  //     day: '2-digit'
  //   });
  //   // //console.log(str);
  // }

  // var calendarEl = document.getElementById('calendar');
  // myCalendar = new FullCalendar.Calendar(calendarEl, {
    
    
    
  //   eventClick: function(info) {
  //     var eventObj = info.event;
  //     if (eventObj.url) {
  //       alert(
  //         'Clicked ' + eventObj.title + '.\n' +
  //         'Will open ' + eventObj.url + ' in a new tab'
  //       );
  //       window.open(eventObj.url);
  //       info.jsEvent.preventDefault(); // prevents browser from following link in current tab.
  //     } else {
  //       // //console.log(eventObj.start);
  //       // //console.log(eventObj.end);
  //       //open an even window
  //       calendarDiv = document.getElementById('calendar');
  //       var eventInfoDiv = document.getElementById('singleEvent');
  //       var eventName = document.getElementById('eventName');
  //       var eventStart = document.getElementById('eventStart');
  //       var eventEnd = document.getElementById('eventEnd');
  //       eventId = eventObj.id;

  //       document.getElementById('auther').innerHTML = eventObj.extendedProps.auther;
  //       document.getElementById('eventName').innerHTML = eventObj.title;
  //       document.getElementById('eventStart').innerHTML = eventObj.start;
  //       document.getElementById('eventEnd').innerHTML = eventObj.end;
  //       // //console.log(eventId);
  //       CurrentEvent=myCalendar.getEventById(eventId);
  //       // //console.log(JSON.stringify(CurrentEvent));

  //       //toggle divs
  //       calendarDiv.style.display = "none";
  //       eventInfoDiv.style.display="block";
  //     }
  //   },
  //   // defaultView: allView,
  //   initialDate: calStartTime,
  //   nowIndicator: true,
  //   now: currentdate,
  //   editable: false, // enable draggable events
  //   droppable: false, // this allows things to be dropped onto the calendar
  //   selectable: false,
  //   // aspectRatio: 1.8,
  //   scrollTime: '09:00:00', // undo default 6am scrollTime
  //   headerToolbar: {
  //     left: 'today prev,next',
  //     center: 'title',
  //     right: 'timeGridDay,timeGridWeek,dayGridMonth'
  //   },
  //   dateClick: function(info) {
  //     //console.log('clicked ' + info.dateStr);
  //   },
  //   initialView: initView,
  //   allDaySlot: false,
  //   // 'listDay'
  //   views: {
  //     timeGridDay: {
  //         type: 'timeGrid',
  //         scrollTime: '07:00:00',
  //     },
  //     timeGridWeek: {
  //         type: 'timeGrid',          
  //         scrollTime: '10:00:00',
  //     },
  //     dayGridMonth: {
          
  //     }
  // },
  //   events: eventsToBuildArray,
  // });
  // //console.log("now is:",today);
  
  // myCalendar.render();
}
var tempAllEvents=[];
var tempAllFavEvents=[];
function toggleAllFavsSelection(){

  //console.log("toggle All Favs");
  if (tempAllEvents.length == 0){
    tempAllEvents = myCalendar.getEvents();
  }
  

  var toggleAllFavB = document.getElementById("toggleFavsOnly");
  var allCheckFavBox = document.getElementById('external-events').getElementsByClassName("favIcon");
  // //console.log(allCheckFavBox);
  
  if (showFavsOnly == false){ //show only favorites    
    // localStorage.setItem("tempAllEvents",JSON.stringify(tempAllEvents));
    // //console.log(tempFavEvents);
    
    for(ev in tempAllEvents){
      //console.log(tempAllEvents[ev].extendedProps.appId);
        for (j in currentUser.favoritesArray){
          // //console.log(currentUser.favoritesArray[j]);
          
          if (currentUser.favoritesArray[j] == tempAllEvents[ev].extendedProps.appId || currentUser.appId ==  tempAllEvents[ev].extendedProps.appId){
            // //console.log("there is a match");
            tempAllFavEvents.push(tempAllEvents[ev]);
            break;
            
          }
        }
      
    }
    //console.log(tempAllFavEvents);
    let allevents = myCalendar.getEvents(); 
    allevents.forEach(el => { el.remove(); })
    myCalendar.addEventSource(tempAllFavEvents);


    toggleFavsOnly.innerHTML = "show all users"
    //console.log("ToggleFavsOnly false");
    showFavsOnly = true; 
    for (i = 0; i < allCheckFavBox.length; i++){
      allCheckFavBox[i].parentElement.style.display = "none";
      // //console.log("allCheckFavBox: " + i +" "+allCheckFavBox[i].checked);      
      if(allCheckFavBox[i].className == "favIcon fa fa-heart"){
        allCheckFavBox[i].parentElement.style.display = "block";
      }         
    }

  }
  else{
    if (tempAllFavEvents.length>0){

    }
    // let tempAllEvents = myCalendar.getEvents()
    //console.log(tempAllFavEvents);
    // var tempAllEvents = JSON.parse(localStorage.getItem("tempAllEvents"));
    // //console.log(tempAllEvents);
    
    //console.log("ToggleFavsOnly true");
    let allevents = myCalendar.getEvents(); 
    allevents.forEach(el => { el.remove(); })
    myCalendar.addEventSource(tempAllEvents);
    tempAllEvents=[];
    tempAllFavEvents=[];
    //console.log(tempAllEvents);
    


    toggleFavsOnly.innerHTML = "show only favs"
    showFavsOnly = false;  
    
      
    i = 0;
    var tempFavPeople = [];
    for (i = 0; i < allCheckFavBox.length; i++){
      // //console.log("tempElement: " + i +" "+tempElement);
      // //console.log("allCheckFavBox: " + i +" "+allCheckFavBox[i].checked);            
        allCheckFavBox[i].parentElement.style.display = "block"; 


    }

  }

}