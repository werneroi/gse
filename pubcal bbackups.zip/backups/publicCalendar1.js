var database = firebase.database();
var db = firebase.firestore();

var currentUser = JSON.parse(localStorage.getItem("currentUser"));
var favoritesArray = [];
var showFavsOnly = false;
let today = new Date().toISOString().slice(0, 10);
var currentdate = new Date();
var datetime = "Last Sync: " + currentdate.getDay() + "/" + currentdate.getMonth() 
+ "/" + currentdate.getFullYear() + " @ " 
+ currentdate.getHours() + ":" 
+ currentdate.getMinutes() + ":" + currentdate.getSeconds();
allUsersArray = [];
allUsersNamesArray = [];
selectedUsers = [];
sortedEventsArray = [];
sortedGuestEventsArray = [];
fbAllEvents = [];
var selfColorNoGuest = 'orange';
var selfColorWithGuest = 'yellow';



// AIzaSyB5Xq7jILt0heL6SpsW1NYLf6uv2MoE1S0
//
// 979111628840-bikkhb8kcpjv2oi954510e5c26k1hjhr.apps.googleusercontent.com
// BA-vBBQggTAPhKvNCIkY2nME


document.addEventListener('DOMContentLoaded', function() {
  
  console.log("public calendar");

  //create tabs according to the user field of interest.
  createTabsNamesByInterest();
  
  isGuestsOnlyActive = document.getElementById('guestOnly');
  myCalendar = FullCalendar;

  // get all calendars from firebase.
  // firebase.database().ref('/posts').on('value', function(snapshot) {
  //   console.log(snapshotToArray(snapshot));
});

  allUsers_fb = localStorage.getItem("allUsersSnapShot");
  // console.log(allUsers_fb);
  for (i in allUsers_fb){
    // console.log(allUsers_fb.key);
    
  }

  firebase.database().ref('/users/').once('value').then(function(snapshot) {
    // var username = (snapshot.val()) || 'Anonymous';
    allUsersSnapShot = snapshot;
    var i =0;
    allUsersSnapShot.forEach(function(child) {
      // console.log(i);
      
      //create a list of all users
      let userFullName = child.val().name + " " + child.val().lastName
      if (child.val().appId != currentUser.appId){
        // console.log("found: "+ child.val().appId);
        allUsersNamesArray.push({
          key:   child.val().appId,
          value: userFullName
        });

        // check if the user has a calendar
        if (child.val().calArray){
          var fbUserEventsArray = child.val().calArray
          // console.log(JSON.parse(fbUserEventsArray));
          //insert the user calendar into an array
          fbAllEvents = fbAllEvents.concat(JSON.parse(fbUserEventsArray));
          
          // console.log(i +" " + snapshot.numChildren());      
        };
      }
      //once finished populate the users table and make the calendar
      i = i+1;
      if (i== allUsersSnapShot.numChildren()){
        // console.log(JSON.stringify(fbAllEvents));
        populateUsersTablePC();
        makeCal(fbAllEvents);
        filterByCurrentInterest(currentUser.fieldsOfinterest[0]);
      };
      // console.log(allUsersNamesArray);                  
    });
  });







function reloadAllCal(){
  console.log(selectedUsers);
  i=0;
  for (v in selectedUsers){
    // console.log("v -",v);
    i+=1;
    // console.log(selectedUsers[v]);
    tempDiv = document.getElementById(selectedUsers[v]);
    tempDiv.style.backgroundColor = "";
    checkBox = document.getElementById("toggleUserSelection"+selectedUsers[v]);
    checkBox.checked = false;
    // selectedUsers.splice( selectedUsers.indexOf(v), 1 );
  }
  // document.querySelectorAll('[id=toggleUserSelection]').checked = false;
  // console.log(selectedUsers);
  selectedUsers=[];

  // if (isGuestsOnlyActive.checked == true){
  //   var calGuestsFilteredArray =  calAllEvents.filter(function(filter) {
  //   return filter.extendedProps.acceptGuest == true;
  //   });
  //   makeCal(calGuestsFilteredArray);

  // }else{
    // makeCal(fbAllEvents);
    filterCal(calAllEvents);
  // }
}






function sendEmail(){

  console.log(eventId + " " + userAppId);


    var i =0;
    //-- find the relevant calendar by user and then find the relevant event!
    //-- find item in JSON example !!!!
    allUsersSnapShot.forEach(function(child) { 
      // console.log(child.val().appId);
      
      if(child.val().appId == userAppId){
        nameTosend = child.val().name;
        emailTosend = child.val().email;
        if (child.val().calArray){
          var fbUserEventsArray = child.val().calArray;
          
          let obj = JSON.parse(fbUserEventsArray);
          for (i in obj){
            if (obj[i].id == eventId){
              console.log(obj[i]);
            }            
          }             
        };
      }                                       
    });
  
  console.log("send to: " + emailTosend +" from: " + currentUser.email + "event id: "+eventId);

  let mailBody = "Hello " + nameTosend + ".\n " + currentUser.name + "would like to book you offered session\n"+
  "please follow this link to approve it\n"
  + "roiwerner.com/gse5/personalCalendar.html?id="+eventId;
  
  // var eventInfoDiv = document.getElementById('singleEvent');
  //       var eventName = document.getElementById('eventName');
  //       console.log(eventInfoDiv);
  //       console.log(eventName);
        
        

  

//get the info for the mail
//-event - date and time
//- the user info
//- what to do now?



  // Roki8686$@
  // Email.send({
  //   Host: "smtp.gmail.com",
  //   Username : "roiwerner@gmail.com",
  //   Password : "Roki8686&<nxF",
  //   To : '<roiwerner@gmail.com>',
  //   From : "<roiwerner@gmail.com>",
  //   Subject : "<THIS IS A TEST>",
  //   Body : "<BODY TEST>",
  //   }).then(
  //     message => alert("mail sent successfully")
  //   );

  Email.send({
    Host: "smtp.ipage.com",
    Username : "roi@roiwerner.com",
    Password : "Roki868686",
    To : '<roiwerner@gmail.com>',
    From : "<roi@roiwerner.com>",
    Subject : "Session booking",
    Body : mailBody,
    }).then(
      message => alert("mail sent successfully")
    );

    // Email.send({
    //   Host: "smtp.elasticemail.com",
    //   Username : "roiwerner@gmail.com",
    //   Password : "1B6A024DC805F8BCB99B706B3A297CBB7C88",
    //   To : '<roiwerner@gmail.com>',
    //   From : "<roi@roiwerner.com>",
    //   Subject : "<THIS IS A TEST 4>",
    //   Body : "<BODY TEST 4>",
    //   }).then(
    //     message => alert("mail sent successfully")
    //   );
    // port:2525

//   db.collection("mails").add({
//     to: ['roiwerner@gmail.com'],
// message: {
//   subject: 'Hello from Firebase!',
//   text: 'This is the plaintext section of the email body.',
//   html: 'This is the <code>HTML</code> section of the email body.',
// }
// })
// .then(function(docRef) {
//     console.log("Document written with ID: ", docRef.id);
// })
// .catch(function(error) {
//     console.error("Error adding document: ", error);
// });

  
}




function saveData(){
  firebase.database().ref('users/' + currentUser.luid).update(
    {

      jasonArray: jasonArray
  //     email: currentUser.email,
  //     name: currentUser.name,
  //     lastName: currentUser.lastName,
  //     mainLanguage: currentUser.mainLanguage,
  //     secLanguage: currentUser.secLanguage,
  //     address: currentUser.address,
  //     city: currentUser.city,
  //     country: currentUser.country,
  //     luid: currentUser.luid,
  // //   //   username: name,
  //     calender: {
  //                       name: propValue.name,
  //                       start: propValue.start,
  //                       end: propValue.end,
  //                       id: propValue.id
  //                   }
    });
    // localStorage.setItem("currentUser", JSON.stringify(currentUser));
    console.log("written please check");

}

// function readEvents(){
//   // var userId = firebase.auth().currentUser.uid;
//   return firebase.database().ref('/users/' + currentUser.luid).once('value').then(function(snapshot) {
//   // var username = (snapshot.val() && snapshot.val().about) || 'Anonymous';
//   // alert(username);
//   console.log(snapshot.val().calArray);
//   calArrayNew = JSON.parse(snapshot.val().calArray);
//   console.log(calArrayNew);
//   // ...
//   });
// }
function makeCal(fbAllEvents){
  var initView = 'timeGridWeek';
  console.log("makeCal");
  if (myCalendar.view){
    initView = myCalendar.view.type;
  }

  var calendarEl = document.getElementById('calendar');
  myCalendar = new FullCalendar.Calendar(calendarEl, {
    
    eventClick: function(info) {
      
      console.log(info);
      
      var eventObj = info.event;
      userAppId = eventObj.extendedProps.appId;
      
      if (eventObj.url) {
        alert(
          'Clicked ' + eventObj.title + '.\n' +
          'Will open ' + eventObj.url + ' in a new tab'
        );
        window.open(eventObj.url);
        info.jsEvent.preventDefault(); // prevents browser from following link in current tab.
      } else {
        

        calendarDiv = document.getElementById('mainFrame');
        var eventInfoDiv = document.getElementById('singleEvent');
        var eventName = document.getElementById('eventName');
        var eventStart = document.getElementById('eventStart');
        var eventEnd = document.getElementById('eventEnd');
        eventAuther = eventObj.auther;
        // var eventId = eventObj.id;
        eventId = eventObj.id;

        document.getElementById('auther').innerHTML = eventObj.extendedProps.auther;
        document.getElementById('eventName').innerHTML = eventObj.title;
        document.getElementById('eventStart').innerHTML = eventObj.start;
        document.getElementById('eventEnd').innerHTML = eventObj.end ;
        console.log(eventId);
        CurrentEvent=myCalendar.getEventById(eventId);


        //check if the date end is before now, don't click!
        // alert(eventObj.start.format('h:mm:ss a'));
        
          var eventEnding = moment(eventObj.end);
          
          console.log(eventEnding.format('HH:mm:ss'));
          console.log(eventEnding.format('YYYY-MM-DD'));


          //--check if the current time clicked is before the end of event, if so allow to click, else do nothing.
          var timeClickedDate = Date.parse(moment().format('YYYY-MM-DD'));
          let endDate = Date.parse(eventEnding.format('YYYY-MM-DD'));
          if (timeClickedDate>endDate){
            console.log("event is in the past");
            return;
          }
          else {
            var timeClickedTime = moment().format('HH:mm:ss');
            let endTime = eventEnding.format('HH:mm:ss');
            str1 =  timeClickedTime.split(':');
            str2 =  endTime.split(':');

            totalSecondsTimeClicked = parseInt(str1[0] * 3600 + str1[1] * 60 + str1[0]);
            totalSecondsEndtime = parseInt(str2[0] * 3600 + str2[1] * 60 + str2[0]);
            console.log(totalSecondsTimeClicked + " " + totalSecondsEndtime);
            if (totalSecondsTimeClicked > totalSecondsEndtime ){
              console.log("event is in the past");
              return;
            }
            else{
              console.log("event is in the future");
            }          
          }

          // alert(CurrentEvent.end.format('d:m:y'));
          // alert(eventEnding.format('DD/MM/yy HH:mm:ss'));

          
          
          
          // var NOW = date();
          // var nowtime = myCalendar.moment();
          // console.log(NOW.formatDate());
          
          
          
          
      
       

        //toggle divs
        calendarDiv.style.display = "none";
        eventInfoDiv.style.display="block";
      }
    },
    dateClick: function(info) {
      console.log('clicked ' + info.dateStr);
    },
    initialView: initView,
    allDaySlot: false,
    // 'listDay'
    views: {
      timeGridDay: {
          type: 'timeGrid',
          scrollTime: '07:00:00',
      },
      timeGridWeek: {
          type: 'timeGrid',          
          scrollTime: '09:00:00',
      },
      dayGridMonth: {
          
      }
    },
    now: currentdate,
    nowIndicator: true,       
    editable: false, // enable draggable events
    droppable: true, // this allows things to be dropped onto the calendar
    selectable: false,
    aspectRatio: 1.8,
    scrollTime: '09:00', // undo default 6am scrollTime
    headerToolbar: {
      left: 'today prev,next',
      center: 'title',
      right: 'timeGridDay,timeGridWeek,dayGridMonth'
    },

    events: fbAllEvents,    
  });

  myCalendar.render();
  calAllEvents = myCalendar.getEvents();


}


function filterCal(eventsToBuildArray){
  myCalendar.r
  // console.log("________filter cal!!!");
  // console.log(eventsToBuildArray);
  // return;
  
  // if (isGuestsOnlyActive.checked == true){
  //   eventsToBuildArray =  eventsToBuildArray.filter(function(filter) {
  //   return filter.extendedProps.acceptGuest == true;
  //   });
  // }
  

  // var initView = 'timeGridWeek';
  // // console.log("makeCal");
  // if (myCalendar.view){
  //   allView = myCalendar.view;
  //   // console.log(myCalendar.view.type);
  //   initView = myCalendar.view.type;
  //   // startTime = myCalendar.view.currentStart._d;
  //   calStartTime = myCalendar.view.currentStart;
  //   //format time in case of neeed!!!!
  //   var str = myCalendar.formatDate(calStartTime, {
  //     year: 'numeric',
  //     month: '2-digit',
  //     day: '2-digit'
  //   });
  //   // console.log(str);
  // }

  // var calendarEl = document.getElementById('calendar');
  // myCalendar = new FullCalendar.Calendar(calendarEl, {
    
    
    
  //   eventClick: function(info) {
  //     var eventObj = info.event;
  //     if (eventObj.url) {
  //       alert(
  //         'Clicked ' + eventObj.title + '.\n' +
  //         'Will open ' + eventObj.url + ' in a new tab'
  //       );
  //       window.open(eventObj.url);
  //       info.jsEvent.preventDefault(); // prevents browser from following link in current tab.
  //     } else {
  //       // console.log(eventObj.start);
  //       // console.log(eventObj.end);
  //       //open an even window
  //       calendarDiv = document.getElementById('calendar');
  //       var eventInfoDiv = document.getElementById('singleEvent');
  //       var eventName = document.getElementById('eventName');
  //       var eventStart = document.getElementById('eventStart');
  //       var eventEnd = document.getElementById('eventEnd');
  //       eventId = eventObj.id;

  //       document.getElementById('auther').innerHTML = eventObj.extendedProps.auther;
  //       document.getElementById('eventName').innerHTML = eventObj.title;
  //       document.getElementById('eventStart').innerHTML = eventObj.start;
  //       document.getElementById('eventEnd').innerHTML = eventObj.end;
  //       // console.log(eventId);
  //       CurrentEvent=myCalendar.getEventById(eventId);
  //       // console.log(JSON.stringify(CurrentEvent));

  //       //toggle divs
  //       calendarDiv.style.display = "none";
  //       eventInfoDiv.style.display="block";
  //     }
  //   },
  //   // defaultView: allView,
  //   initialDate: calStartTime,
  //   nowIndicator: true,
  //   now: currentdate,
  //   editable: false, // enable draggable events
  //   droppable: false, // this allows things to be dropped onto the calendar
  //   selectable: false,
  //   // aspectRatio: 1.8,
  //   scrollTime: '09:00:00', // undo default 6am scrollTime
  //   headerToolbar: {
  //     left: 'today prev,next',
  //     center: 'title',
  //     right: 'timeGridDay,timeGridWeek,dayGridMonth'
  //   },
  //   dateClick: function(info) {
  //     console.log('clicked ' + info.dateStr);
  //   },
  //   initialView: initView,
  //   allDaySlot: false,
  //   // 'listDay'
  //   views: {
  //     timeGridDay: {
  //         type: 'timeGrid',
  //         scrollTime: '07:00:00',
  //     },
  //     timeGridWeek: {
  //         type: 'timeGrid',          
  //         scrollTime: '10:00:00',
  //     },
  //     dayGridMonth: {
          
  //     }
  // },
  //   events: eventsToBuildArray,
  // });
  // console.log("now is:",today);
  
  // myCalendar.render();
}

function filterOneOld(appId){
    console.log("filterOne");
    
  var newFilteredArray =  calAllEvents.filter(function(filter) {
  return filter.extendedProps.appId == appId;
  });
  if (selectedUsers.length>1){
    console.log("more then 1 user");    
    sortedEventsArray = sortedEventsArray.concat(newFilteredArray);
    
    
    filterCal(sortedEventsArray);
    console.log(sortedEventsArray);
    console.log("filter call 1");

  }
  else{
      sortedEventsArray = newFilteredArray;
      
      console.log("sorted array: ",sortedEventsArray);
      console.log("filter call 2");
      filterCal(sortedEventsArray);
  }

}

function unfilterOneold(appId){

    
  var newFilteredArray =  sortedEventsArray.filter(function(filter) {
  return filter.extendedProps.appId == appId;
  });
  // console.log(newFilteredArray);
  for(tempIndex in newFilteredArray){
    var tempFilteredEvent = newFilteredArray[tempIndex];
    sortedEventsArray.splice( sortedEventsArray.indexOf(tempFilteredEvent), 1 );
      // sortedEventsArray = sortedEventsArray.concat(JSON.parse(tempFilteredEvent));
  }
    // console.log(sortedEventsArray);
    console.log("filter call 3");
  filterCal(sortedEventsArray);
}

function toggleUserSelection(number){

  console.log(number);
  tempDiv = document.getElementById(number);
  console.log(tempDiv);
  console.log(selectedUsers);
  if (tempDiv.style.backgroundColor == "red"){
    tempDiv.style.backgroundColor = "";
    var tempButton = document.getElementById('toggleUserSelection'+number);        
    tempButton.className = "fa fa-eye-slash";
    selectedUsers.splice( selectedUsers.indexOf(number), 1 );
    console.log(selectedUsers);
    if (selectedUsers === undefined || selectedUsers.length == 0){        
        reloadAllCal();                
    }
    else{
      unfilterOne(number);
    }
  }
  else{
    selectedUsers = selectedUsers.concat(number);
    console.log("selectedUsers: " + selectedUsers);
    tempDiv.style.backgroundColor = "red";
    var tempButton = document.getElementById('toggleUserSelection'+number);        
    tempButton.className = "fa fa-eye";
    // "<button class='btn' id='toggleUserSelection" + fbUserAppIdTrimed + "' onclick='toggleUserSelection(" + fbUserAppId + ")'>"+
    //   "<i class='far fa-eye' aria-hidden='true'></i></button>"+


    filterOne(number);
  }

}



function toggleGuestsOnly(){
  console.log(selectedUsers.length + " toggleGuestsOnly ",isGuestsOnlyActive.checked );
  if (selectedUsers.length>0){
      console.log("few users")
      console.log("filter call 4");
      filterCal(sortedEventsArray);
  }
  else{  
    console.log('no users')  
    console.log("filter call 5");    
      filterCal(calAllEvents); 
      // console.log(calAllEvents)       
    }
}


function returnTable(){
  console.log(JSON.stringify(CurrentEvent));
  // CurrentEvent.remove();
  calendarDiv.style.display = "block";
  document.getElementById('singleEvent').style.display = "none";  
  myCalendar.render();
}

// function writeEvents(){
//   array = myCalendar.getEvents();
//   jasonArray = JSON.stringify(array);
//   console.log(currentUser.luid + " " + jasonArray);
//   currentUser.calArray = jasonArray;
//   firebase.database().ref('users/' + currentUser.luid).update(
//     {
//       calArray: jasonArray
//       // test: "passed"
//     });
//     localStorage.setItem("currentUser", JSON.stringify(currentUser));

// }


function addevent(){
  console.log(JSON.stringify(CurrentEvent));
}

function toggleFavorite1(userAppid){
  tempFavIcon = document.getElementById("toggleFavorite1"+userAppid);
  console.log("Toggle favs from Icon " + userAppid +"with value: "+ tempFavIcon.className);
  
  if (showFavsOnly === true){
    tempDiv = document.getElementById(userAppid);
    console.log(tempDiv);
    tempDiv.style.display = "none";
    const index = myFavArray.indexOf(userAppid);
      if (index > -1) {
        myFavArray.splice(index, 1);
      }
  }
  else{
    //--check if user is a fav already
    if (tempFavIcon.className == "favIcon fa fa-star"){ //not a fav yet
      tempFavIcon.className = "favIcon fa fa-heart";
      if (typeof myFavArray === 'undefined' || myFavArray === null) {
        myFavArray = [];
      }
      myFavArray = myFavArray.concat(userAppid); 
    }
    else{ //already a fav
      tempFavIcon.className = "favIcon fa fa-star";
      const index = myFavArray.indexOf(userAppid);
      if (index > -1) {
        myFavArray.splice(index, 1);
      }
    }
    console.log("favoritesArray: " + myFavArray);
    writeFavsToFB();
    
  }
}
// function toggleFavorite(userAppid){
//   console.log(userAppid + "  " + showFavsOnly);
//   if (showFavsOnly === true){
//     // var selectedDiv = document.getElementById(userAppid).parentElement.nodeName;
//     // console.log(selectedDiv);
//     tempDiv = document.getElementById(userAppid);
//     console.log(tempDiv);
//     tempDiv.style.display = "none";
//     const index = myFavArray.indexOf(userAppid);
//       if (index > -1) {
//         myFavArray.splice(index, 1);
//       }
    
//   }
//   else{
//     checkBox = document.getElementById("toggleFavorite"+userAppid);
//   console.log(userAppid + " " + checkBox + " " + checkBox.checked);
//     if(checkBox.checked == true){
//       if (typeof myFavArray === 'undefined' || myFavArray === null) {
//         myFavArray = [];
//       }
//       myFavArray = myFavArray.concat(userAppid);      
//     }
//     else{
//       // favoritesArray = favoritesArray.concat(userAppid); 
//       const index = myFavArray.indexOf(userAppid);
//       if (index > -1) {
//         myFavArray.splice(index, 1);
//       }
//     }
//   }
//   //write to my array of favs and then write it into fb
  
//     console.log("favoritesArray: " + myFavArray);
//     writeFavsToFB();
// }

function writeFavsToFB(){
  // array = myCalendar.getEvents();
  // jasonArray = JSON.stringify(array);
  // console.log(currentUser.luid + " " + favoritesArray);
  currentUser.favoritesArray = myFavArray;
  firebase.database().ref('users/' + currentUser.luid).update(
    {
      favoritesArray: myFavArray
      // test: "passed"
    });
    localStorage.setItem("currentUser", JSON.stringify(currentUser));

}

function ToggleFavsOnly1(){

  console.log("toggle All Favs");
  
  var toggleAllFavB = document.getElementById("toggleFavsOnly");
  var allCheckFavBox = document.getElementById('external-events').getElementsByClassName("favIcon");
  console.log(allCheckFavBox);
  
  if (showFavsOnly == false){ //show only favorites
    toggleFavsOnly.innerHTML = "show all users"
    console.log("ToggleFavsOnly false");
    showFavsOnly = true; 
    for (i = 0; i < allCheckFavBox.length; i++){
      allCheckFavBox[i].parentElement.style.display = "none";
      // console.log("allCheckFavBox: " + i +" "+allCheckFavBox[i].checked);      
      if(allCheckFavBox[i].className == "favIcon fa fa-heart"){
        allCheckFavBox[i].parentElement.style.display = "block";
      }         
    }

  }
  else{
    console.log("ToggleFavsOnly true");
    toggleFavsOnly.innerHTML = "show only favs"
    showFavsOnly = false;    
    i = 0;
    for (i = 0; i < allCheckFavBox.length; i++){
      // console.log("tempElement: " + i +" "+tempElement);
      // console.log("allCheckFavBox: " + i +" "+allCheckFavBox[i].checked);            
        allCheckFavBox[i].parentElement.style.display = "block";            
    }

  }

}
// function ToggleFavsOnly(){
//   var allCheckFavBox = document.getElementById('external-events').getElementsByClassName("tavCheckBox");
//   // console.log("allCheckFavBox.length: " + allCheckFavBox.length);
//   if (showFavsOnly == false){
//     console.log("ToggleFavsOnly false");
    
//     showFavsOnly = true;    
//     i = 0;
//     for (i = 0; i < allCheckFavBox.length; i++){
//       // console.log("allCheckFavBox: " + i +" "+allCheckFavBox[i].checked);      
//       if(allCheckFavBox[i].checked == true){
//         allCheckFavBox[i].parentElement.style.display = "block";
//       }
//       else{
//         allCheckFavBox[i].parentElement.style.display = "none";
//       }      
//     }        
//   }
//   else{
//     console.log("ToggleFavsOnly true");
//     showFavsOnly = false;    
//     i = 0;
//     for (i = 0; i < allCheckFavBox.length; i++){
//       // console.log("tempElement: " + i +" "+tempElement);
//       console.log("allCheckFavBox: " + i +" "+allCheckFavBox[i].checked);            
//         allCheckFavBox[i].parentElement.style.display = "block";            
//     }
//   }
// }


  function populateUsersTablePC(){
    //populate the names table as an HTML 
    // console.log("populateUsersTablePC - favoritesArray: " + myFavArray);
    let tempString = '';
    let dataHtml = '';
    var displayedNamesArray = [];
    mainDiv = document.getElementById('external-events');
    // console.log("mainDiv: ",mainDiv);
    k=0;
    //check inside all the users if there is a fav
    for (var i in allUsersNamesArray){
      // console.log("selectedUsers: ", selectedUsers);
      // console.log("favoritesArray: ",favoritesArray);

      // check if the user is selected (for filtering) and mark the check box on
      for (var temp in selectedUsers){
        if (selectedUsers[temp] == allUsersNamesArray[i] )
        {
          tempString="checked";
          break;
        }
      }
      k = k+1;

      displayedNamesArray = displayedNamesArray.concat(allUsersNamesArray[i].value);
      //create the HTML code
      let fbUserAppId = JSON.stringify(allUsersNamesArray[i].key);
      
      fbUserAppIdTrimed = fbUserAppId.slice(1, -1);
      dataHtml += "<div id='" + fbUserAppIdTrimed + "'class='user_row' onclick=''>"+
      "<i class='fa fa-eye-slash' id='toggleUserSelection" + fbUserAppIdTrimed + "' onclick='toggleUserSelection(" + fbUserAppId + ")'>"+
      "</i>"+
      "<p onclick='openUser(" + fbUserAppIdTrimed + ")'>" + allUsersNamesArray[i].value + "</p>";      
      myFavArray = currentUser.favoritesArray;
      //check if the user is a favorite and check the box on
      var string = "<i class='favIcon fa fa-star'";
      // console.log("HELLLLLLLOOOOOOO! "+currentUser.favoritesArray);
        if (typeof myFavArray === 'undefined' || myFavArray === null) {

        }
        else {
          for (i in myFavArray){
            console.log(myFavArray[i] + "  " + fbUserAppIdTrimed);
              if (myFavArray[i] == fbUserAppIdTrimed){
              //   document.getElementById("toggleUserSelection",fbUserAppIdTrimed).checked = true;
              string = "<i class='favIcon fa fa-heart'";
              break;
              } 
              // else{
              //   string = "<input type='checkbox' class = 'tavCheckBox' id='toggleFavorite"+ fbUserAppIdTrimed +"' onclick='toggleFavorite(" + fbUserAppId + ")' />";

              // }                                 
          }
        }
      dataHtml += "<i class='chatIcon fa fa-comment'></i>" + string + " id='toggleFavorite1"+ fbUserAppIdTrimed +"' onclick='toggleFavorite1(" + fbUserAppId + ")'></i></div>"; 
            
    };
    if (k == allUsersNamesArray.length){
      mainDiv.innerHTML = dataHtml;
      autocomplete(document.getElementById("myInput"), displayedNamesArray);
      // console.log(displayedNamesArray);
      

    };
  }
  //--version break!!!!!!
  function openUser(passedUserAppId){
    // console.log("open ",passedUserAppId.id);
    //hide all grid
    let url="../gse5/singleUser.html?id="+passedUserAppId.id;
    popupWindow = window.open(url,'popUpWindow','height=500,width=500,left=100,top=100,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no, status=yes');
	

    // let currentView = document.getElementById("calendar");
    // console.log(currentView);
    
    // currentView.style.display = "none";
    
  }

  function createTabsNamesByInterest (){
    console.log("create tabs " + currentUser.fieldsOfinterest);
    // currentUser.fieldsOfinterest.pop();
    var localFieldsOfInterest = currentUser.fieldsOfinterest;
    // currentUser.fieldsOfinterest = [];
    localFieldsOfInterest.push("All_as_guest");
    htmlString = '';
    tabsString = '';
    
    
    for (i in localFieldsOfInterest){
      activeString = '';
      if(i == 0){
        activeString = " active";
      }
      currentField = localFieldsOfInterest[i]
      htmlString += "<button class='tablinks " + activeString + "' onclick='openTab(event, " +currentField + ")'>" + currentField + "</button>"
  
      tabsString += "<div id=" + currentField + " class='tabcontent'><h3>" + currentField + "</h3><div  id='allUsersDisplay'></div></div>"
      
    }
    htmlData = "<div id='tableTabsByInterest' class='tab'>"+htmlString+"</div>"+tabsString;
    document.getElementById("tabsNav").innerHTML = htmlData;
    
  }

  function openTab(evt, fieldName) {
    console.log(fieldName.id);
    
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    // document.getElementById(fieldName.id).style.display = "block";
    evt.currentTarget.className += " active";
  
    if(fieldName.id == "All_as_guest"){
      isGuestsOnlyActive.checked = true;
      makeCal(fbAllEvents);
      toggleGuestsOnly();
      var allNameTableRows = document.getElementsByClassName("user_row");
      for (i = 0; i < allNameTableRows.length; i++){      
        // console.log(allNameTableRows[i]);
        allNameTableRows[i].style.display = "";
      }
    }
    else{
      isGuestsOnlyActive.checked = false;
      filterByCurrentInterest(fieldName.id)
    }
    
  }

  function filterByCurrentInterest(currentField){
    if(currentField == "All_as_guest"){
      console.log("show all as aguest");
      
    }
  
    if (currentField == 0){
      console.log("default: "+ currentField);
      makeCal(fbAllEvents);
    }
    else { 
      
      //--filter out the users based on FOI
      var localUsersArray = allUsersSnapShot.toJSON();

      console.log("currentField: "+ currentField);
      console.log("allUsersArray: "+ localUsersArray);
      // var newFilteredArray =  calAllEvents;
      var tempUsersByInterestArray = [];
      for (i in localUsersArray){
        var tempFieldsArray = localUsersArray[i].fieldsOfinterest;
        // console.log(localUsersArray[i].fieldsOfinterest);
        if (tempFieldsArray === undefined){

        }
        else{
          if (Object.values(tempFieldsArray).includes(currentField)) {
            // console.log("found here: "+currentField+ " at " + localUsersArray[i].name);
            tempUsersByInterestArray = tempUsersByInterestArray.concat(localUsersArray[i]);       
          }  
        }
            
      }

      // console.log(tempUsersByInterestArray);
      //TODO: pass from here the events and the names to the tables
      //-- filter the users table rows based on the FOI result
      var allEventsinCalDisplayed = document.getElementsByClassName("fc-event");
      // console.log(allEventsinCalDisplayed);
      var tempEventForInterest=[];
      var allNameTableRows = document.getElementsByClassName("user_row");
      i = 0;
      for (i = 0; i < allNameTableRows.length; i++){      
        // console.log(allNameTableRows[i]);
        allNameTableRows[i].style.display = "none";

        if (tempUsersByInterestArray.length>0){
          for (k = 0; k < tempUsersByInterestArray.length; k++){          
            // console.log(tempUsersByInterestArray[k].calArray);
            if (allNameTableRows[i].id == tempUsersByInterestArray[k].appId){
              allNameTableRows[i].style.display = "block";

              var newFilteredArray =  calAllEvents.filter(function(filter) {
                return filter.extendedProps.appId == tempUsersByInterestArray[k].appId;
              });
                 
                tempEventForInterest = tempEventForInterest.concat(newFilteredArray);                  
              

              // tempEventForInterest = tempEventForInterest.concat(JSON.parse(tempUsersByInterestArray[k].calArray));
              // console.log("found match");
              break;
            }
          }
          console.log("filter call 8");
          
        }else{
          //table is empty yet self is still in array! so I dont see this message
          console.log("NO USERS FOR THIS FIELD FOUND - EMPTY TABLE");
          

        }
        
      }  
      if(i == allNameTableRows.length){
        filterCal(tempEventForInterest); 
      }
         
    }
    //get current selected tab
    
  }


  var showMySelfCheck = false;
  var eventsWithMyself = [];
  
  function showMyself1(){
    console.log(currentUser.appId);
    
    //Show or hide myself in calendar
    var showSelfButton = document.getElementById("showSelf");
    if (showMySelfCheck == false){
      showMySelfCheck = true;
      // allUsersNamesArray.push({
      //   key:   currentUser.appId,
      //   value: currentUser.name + " " + currentUser.lastName
      // }); 
      showSelfButton.innerText="Hide myself";
      
      //--change my own color
      var localSelfCalArray = JSON.parse(currentUser.calArray);
      console.log(localSelfCalArray);

      for (i in localSelfCalArray){
        console.log(localSelfCalArray[i].backgroundColor);
        if (localSelfCalArray[i].extendedProps.acceptGuest == true){
          localSelfCalArray[i].backgroundColor = "yellow";
        }
        else{
          localSelfCalArray[i].backgroundColor = "orange";
        }
        
      }            

      eventsWithMyself = fbAllEvents.concat(localSelfCalArray);
      console.log("filter call 9");
      filterCal(eventsWithMyself);
      // makeCal(eventsWithMyself);
    }
    else{
      showMySelfCheck = false;
      allUsersNamesArray.splice( allUsersNamesArray.indexOf(currentUser.appId), 1 );
      showSelfButton.innerText="Show myself";
      filterCal(fbAllEvents);
    }
    
    //get my appid and remove it from cal
    //give it a different color
         
    populateUsersTablePC();
        
  }



  function search(){
    console.log("search");
  
    var searchForm = document.getElementById("searchForm");
    
    //clear the search bar
  
    //find the user and display him
    var searchResult = document.getElementById("myInput").value;
    // const index = usersNamesArray.indexOf(searchResult);
    // console.log(index);
  
    var allDisplayedEvents = document.getElementsByClassName("user_row");
    for (i = 0; i < allDisplayedEvents.length; i++){
      console.log(allDisplayedEvents[i].id);
      console.log((allDisplayedEvents[i].textContent).replace('filterFavorite',''));
      let tempResult = (allDisplayedEvents[i].textContent).replace('filterFavorite','');
      allDisplayedEvents[i].style.display="none";
      if (searchResult == tempResult)
      {
        allDisplayedEvents[i].style.display="block";
        
        filterOne(allDisplayedEvents[i].id)
        searchForm.action = "javascript:cancelSearch("+allDisplayedEvents[i].id+")";
        
      }
      //--change looking glass to x and make into a cancel search function
      var searchB = document.getElementById("searchB");
      var cancelS = document.getElementById("cancelS");
      // searchB.classList.add("fa-ban");
      // searchB.onclick = "cancelSearch()";
      searchB.style.display = "none";
      cancelS.style.display = "";
      
      
    }
    // action="javascript:search()"
  }

  function cancelSearch(appId){
    console.log(appId.id);
    
    var searchB = document.getElementById("searchB");
    var cancelS = document.getElementById("cancelS");
    var searchForm = document.getElementById("searchForm");
    searchForm.action = "javascript:search()";
    
    console.log("cancael search");
    searchB.style.display = "";
    cancelS.style.display = "none";
  
    
  
    var allDisplayedEvents = document.getElementsByClassName("user_row");
    for (i = 0; i < allDisplayedEvents.length; i++){
      allDisplayedEvents[i].style.display="";
    }
    reloadAllCal();
    // unfilterOne(appId.id);
  }